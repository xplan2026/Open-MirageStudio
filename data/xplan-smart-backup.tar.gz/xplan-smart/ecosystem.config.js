/**
 * PM2 配置文件 - 主入口文件
 *
 * 功能：
 * - 启动所有核心监控进程
 * - 代币监控 (scanner-8a89, scanner-9111, scanner-8e16)
 * - BNB 监控 (scanner-bnb) - 监控 BNB 余额
 * - USDT 监控 (scanner-usdt) - 监控 USDT 余额
 * - Gas 费补充 (gas-alert)
 * - 日志管理 (log-cleaner)
 *
 * 内存需求估算（实际占用约为 max_memory_restart 的 30%）：
 * - scanner-8a89: 500M -> ~150 MB
 * - scanner-9111: 500M -> ~150 MB
 * - scanner-8e16: 500M -> ~150 MB
 * - scanner-bnb: 500M -> ~150 MB
 * - scanner-usdt: 500M -> ~150 MB
 * - gas-alert: 300M -> ~90 MB
 * - log-cleaner: 100M -> ~30 MB
 * - 核心进程总计: ~870 MB
 * @updated 2026-04-03T20:20:00.000Z
 * - 系统预留: ~300 MB
 * - 总需求: ~1,170 MB
 *
 * 架构更新（2026-03-27）：
 * - scanner-basecoin 已废弃，拆分为 scanner-bnb + scanner-usdt
 * - BScanner: 专门监控 BNB 余额（阈值：0.006 BNB）
 * - USDTScanner: 专门监控 USDT 余额（阈值可配置）
 *
 * 修复说明（2026-03-28）：
 * - P0-1: Promise Rejection 处理 - 防止频繁重启
 * - P0-2: TransactionQueue 交易队列 - 交易管理优化
 * - P1-1: Nonce 管理机制 - 防止并发冲突
 * - P1-2: 定时检查跨月问题 - 时间戳计算修复
 * - P2-1: start() 方法逻辑 - 启动停止一致性
 * - P2-2: Logger 循环缓冲区 - 性能优化 90%
 *
 * 测试验证：
 * - 功能测试: 18/18 通过 (100%)
 * - 代码验证: 21/21 通过 (100%)
 * - 总计: 39/39 通过 (100%)
 *
 * @updated 2026-03-28T12:30:00.000Z
 */

module.exports = {
  apps: [
    // ============================================
    // 核心监控进程
    // ============================================
    {
      name: 'scanner-8a89',
      script: './src/processes/scanner-8a89.js',
      cwd: './',
      instances: 1,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
        DOTENV_CONFIG_PATH: './.env.production',
      },
      error_file: './logs/scanner-8a89-error.log',
      out_file: './logs/scanner-8a89-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      autorestart: true,
      watch: false,
      // 日志轮换配置：当日志达到 10M 时自动轮换
      log_file_size: '10M',
    },
    {
      name: 'scanner-9111',
      script: './src/processes/scanner-9111.js',
      cwd: './',
      instances: 1,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
        DOTENV_CONFIG_PATH: './.env.production',
      },
      error_file: './logs/scanner-9111-error.log',
      out_file: './logs/scanner-9111-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      autorestart: true,
      watch: false,
      log_file_size: '10M',
    },
    {
      name: 'scanner-8e16',
      script: './src/processes/scanner-8e16.js',
      cwd: './',
      instances: 1,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
        DOTENV_CONFIG_PATH: './.env.production',
      },
      error_file: './logs/scanner-8e16-error.log',
      out_file: './logs/scanner-8e16-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      autorestart: true,
      watch: false,
      log_file_size: '10M',
    },

    // ============================================
    // BNB 监控进程（替代 scanner-basecoin）
    // ============================================
    {
      name: 'scanner-bnb',
      script: './src/processes/scanner-bnb.js',
      cwd: './',
      instances: 1,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
        DOTENV_CONFIG_PATH: './.env.production',
      },
      error_file: './logs/scanner-bnb-error.log',
      out_file: './logs/scanner-bnb-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      autorestart: true,
      watch: false,
      log_file_size: '10M',
    },
    // {
    //   name: 'scanner-usdt',
    //   script: './src/processes/scanner-usdt.js',
    //   cwd: './',
    //   instances: 1,
    //   max_memory_restart: '500M',
    //   env: {
    //     NODE_ENV: 'production',
    //     DOTENV_CONFIG_PATH: './.env.production',
    //   },
    //   error_file: './logs/scanner-usdt-error.log',
    //   out_file: './logs/scanner-usdt-out.log',
    //   log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    //   merge_logs: true,
    //   autorestart: true,
    //   watch: false,
    //   log_file_size: '10M',
    // },

    // ============================================
    // Gas 报警进程（必需 - 转账依赖）
    // ============================================
    {
      name: 'gas-alert',
      script: './src/processes/gas-alert.js',
      cwd: './',
      instances: 1,
      exec_mode: 'fork',
      max_memory_restart: '300M',
      env: {
        NODE_ENV: 'production',
        DOTENV_CONFIG_PATH: './.env.production',
      },
      error_file: './logs/gas-alert-error.log',
      out_file: './logs/gas-alert-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      autorestart: true,
      watch: false,
      log_file_size: '10M',
    },

    // ============================================
    // 日志清理进程
    // ============================================
    {
      name: 'log-cleaner',
      script: './src/processes/log-cleaner.js',
      cwd: './',
      instances: 1,
      max_memory_restart: '100M',
      env: {
        NODE_ENV: 'production',
        DOTENV_CONFIG_PATH: './.env.production',
      },
      error_file: './logs/log-cleaner-error.log',
      out_file: './logs/log-cleaner-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      autorestart: true,
      watch: false,
      log_file_size: '10M',
      // 每天凌晨 2:00 清理日志
      cron_restart: '0 2 * * *',
    },
  ],
};
