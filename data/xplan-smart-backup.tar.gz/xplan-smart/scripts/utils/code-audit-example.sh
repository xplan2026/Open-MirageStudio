#!/bin/bash

# 代码审计示例脚本
# 基于 code-audit.mdc 规范的实现示例

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}         X-Plan Smart 代码审计          ${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# 审计配置
AUDIT_DIR="/workspace"
REPORT_FILE="${AUDIT_DIR}/audit-report-$(date +%Y%m%d-%H%M%S).txt"
HIGH_RISK_COUNT=0
MEDIUM_RISK_COUNT=0
LOW_RISK_COUNT=0

# 创建审计报告
create_report() {
    echo "=== X-Plan Smart 代码审计报告 ===" > "$REPORT_FILE"
    echo "审计时间: $(date)" >> "$REPORT_FILE"
    echo "项目版本: $(git describe --tags 2>/dev/null || echo '未标记')" >> "$REPORT_FILE"
    echo "审计范围: ${AUDIT_DIR}" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
}

# 添加审计结果到报告
add_to_report() {
    local level="$1"
    local message="$2"
    local file="$3"
    local line="${4:-N/A}"
    
    echo "[${level}] ${message}" >> "$REPORT_FILE"
    echo "  位置: ${file}:${line}" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    
    case $level in
        "高危") HIGH_RISK_COUNT=$((HIGH_RISK_COUNT + 1)) ;;
        "中危") MEDIUM_RISK_COUNT=$((MEDIUM_RISK_COUNT + 1)) ;;
        "低危") LOW_RISK_COUNT=$((LOW_RISK_COUNT + 1)) ;;
    esac
}

# 审计函数：检查未处理的错误
audit_unhandled_errors() {
    echo -e "${YELLOW}[1/6] 检查未处理的错误...${NC}"
    
    # 检查缺少 try-catch 的异步操作
    local files=$(find "$AUDIT_DIR/src" -name "*.js" -type f)
    
    for file in $files; do
        # 检查 async 函数中缺少 try-catch
        local lines=$(grep -n "async.*function\|async.*=>" "$file" | cut -d: -f1)
        
        for line in $lines; do
            # 获取函数体范围
            local func_end=$(awk -v start="$line" 'NR > start && /^[[:space:]]*}/ {print NR; exit}' "$file")
            
            if [ -n "$func_end" ]; then
                # 检查函数体内是否有 try-catch
                local has_try=$(sed -n "${line},${func_end}p" "$file" | grep -c "try\|catch")
                
                if [ "$has_try" -eq 0 ]; then
                    # 检查是否有 await 调用
                    local has_await=$(sed -n "${line},${func_end}p" "$file" | grep -c "await")
                    
                    if [ "$has_await" -gt 0 ]; then
                        add_to_report "中危" "异步函数缺少错误处理" "$file" "$line"
                    fi
                fi
            fi
        done
    done
}

# 审计函数：检查无限循环
audit_infinite_loops() {
    echo -e "${YELLOW}[2/6] 检查潜在的无限循环...${NC}"
    
    local files=$(find "$AUDIT_DIR/src" -name "*.js" -type f)
    
    for file in $files; do
        # 检查 while(true) 或 while(1)
        local lines=$(grep -n "while\s*(true\|1)" "$file" | cut -d: -f1)
        
        for line in $lines; do
            # 检查是否有退出条件
            local next_lines=$(sed -n "${line},$((line+10))p" "$file")
            local has_break=$(echo "$next_lines" | grep -c "break\|return")
            
            if [ "$has_break" -eq 0 ]; then
                add_to_report "高危" "潜在的无限循环缺少退出条件" "$file" "$line"
            fi
        done
    done
}

# 审计函数：检查资源泄漏
audit_resource_leaks() {
    echo -e "${YELLOW}[3/6] 检查资源泄漏...${NC}"
    
    local files=$(find "$AUDIT_DIR/src" -name "*.js" -type f)
    
    for file in $files; do
        # 检查 setInterval 没有 clearInterval
        local interval_lines=$(grep -n "setInterval" "$file" | cut -d: -f1)
        
        for line in $interval_lines; do
            # 在文件后面查找对应的 clearInterval
            local after_line=$(sed -n "$((line+1)),$p" "$file")
            local has_clear=$(echo "$after_line" | grep -c "clearInterval")
            
            if [ "$has_clear" -eq 0 ]; then
                add_to_report "中危" "setInterval 可能缺少清理" "$file" "$line"
            fi
        done
        
        # 检查 setTimeout 没有清理
        local timeout_lines=$(grep -n "setTimeout" "$file" | cut -d: -f1)
        
        for line in $timeout_lines; do
            local after_line=$(sed -n "$((line+1)),$p" "$file")
            local has_clear=$(echo "$after_line" | grep -c "clearTimeout")
            
            if [ "$has_clear" -eq 0 ]; then
                add_to_report "低危" "setTimeout 可能缺少清理" "$file" "$line"
            fi
        done
    done
}

# 审计函数：检查安全验证
audit_security_validation() {
    echo -e "${YELLOW}[4/6] 检查安全验证...${NC}"
    
    local files=$(find "$AUDIT_DIR/src" -name "*.js" -type f)
    
    for file in $files; do
        # 检查转账函数是否有余额验证
        if grep -q "transfer\|Transfer" "$file"; then
            local transfer_lines=$(grep -n "transfer\|Transfer" "$file" | cut -d: -f1)
            
            for line in $transfer_lines; do
                # 检查前后几行是否有余额检查
                local context=$(sed -n "$((line-5)),$((line+5))p" "$file")
                local has_balance_check=$(echo "$context" | grep -ci "balance\|余额")
                local has_amount_check=$(echo "$context" | grep -ci "amount\s*>\s*0\|金额.*大于")
                
                if [ "$has_balance_check" -eq 0 ] || [ "$has_amount_check" -eq 0 ]; then
                    add_to_report "高危" "转账操作缺少余额或金额验证" "$file" "$line"
                fi
            done
        fi
    done
}

# 审计函数：检查环境变量使用
audit_env_variables() {
    echo -e "${YELLOW}[5/6] 检查环境变量使用...${NC}"
    
    local files=$(find "$AUDIT_DIR/src" -name "*.js" -type f)
    
    for file in $files; do
        # 检查硬编码的敏感信息
        local sensitive_lines=$(grep -n "0x[0-9a-fA-F]\{40\}\|sk_\|pk_\|private\|secret" "$file" | cut -d: -f1)
        
        for line in $lines; do
            local context=$(sed -n "${line}p" "$file")
            
            # 排除注释和字符串常量
            if ! echo "$context" | grep -q "^[[:space:]]*//\|^[[:space:]]*/\*\|['\"]0x"; then
                add_to_report "高危" "代码中可能包含硬编码的敏感信息" "$file" "$line"
            fi
        done
        
        # 检查是否使用 process.env
        local has_env=$(grep -c "process\.env\|require.*dotenv" "$file")
        
        if [ "$has_env" -eq 0 ] && grep -q "PRIVATE_KEY\|API_KEY\|DATABASE_URL" "$file"; then
            add_to_report "高危" "可能缺少环境变量配置" "$file" "N/A"
        fi
    done
}

# 审计函数：检查性能问题
audit_performance_issues() {
    echo -e "${YELLOW}[6/6] 检查性能问题...${NC}"
    
    local files=$(find "$AUDIT_DIR/src" -name "*.js" -type f)
    
    for file in $files; do
        # 检查同步阻塞操作
        local sync_ops=$(grep -n "Sync\|sync" "$file" | grep -v "async\|Async" | cut -d: -f1)
        
        for line in $sync_ops; do
            local context=$(sed -n "${line}p" "$file")
            
            if echo "$context" | grep -q "readFileSync\|writeFileSync\|execSync"; then
                add_to_report "中危" "使用同步文件/系统操作可能阻塞事件循环" "$file" "$line"
            fi
        done
        
        # 检查循环中的 RPC 调用模式
        local loop_lines=$(grep -n "for.*of\|for.*in\|while\|forEach" "$file" | cut -d: -f1)
        
        for line in $loop_lines; do
            # 获取循环体
            local loop_end=$(awk -v start="$line" 'NR > start && /^[[:space:]]*}/ {print NR; exit}' "$file")
            
            if [ -n "$loop_end" ]; then
                local loop_body=$(sed -n "${line},${loop_end}p" "$file")
                local has_rpc=$(echo "$loop_body" | grep -c "getBalance\|call\|send")
                
                if [ "$has_rpc" -gt 0 ]; then
                    add_to_report "中危" "循环中可能有独立的 RPC 调用，建议批量处理" "$file" "$line"
                fi
            fi
        done
    done
}

# 生成审计报告总结
generate_summary() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}          审计结果总结                ${NC}"
    echo -e "${BLUE}========================================${NC}"
    
    echo "审计报告已保存至: $REPORT_FILE"
    echo ""
    
    if [ "$HIGH_RISK_COUNT" -gt 0 ]; then
        echo -e "${RED}高危问题: $HIGH_RISK_COUNT 个${NC}"
    else
        echo -e "${GREEN}高危问题: $HIGH_RISK_COUNT 个${NC}"
    fi
    
    if [ "$MEDIUM_RISK_COUNT" -gt 0 ]; then
        echo -e "${YELLOW}中危问题: $MEDIUM_RISK_COUNT 个${NC}"
    else
        echo -e "${GREEN}中危问题: $MEDIUM_RISK_COUNT 个${NC}"
    fi
    
    if [ "$LOW_RISK_COUNT" -gt 0 ]; then
        echo -e "${YELLOW}低危问题: $LOW_RISK_COUNT 个${NC}"
    else
        echo -e "${GREEN}低危问题: $LOW_RISK_COUNT 个${NC}"
    fi
    
    # 计算总体评分 (100 - 高危*10 - 中危*5 - 低危*2)
    local score=$((100 - HIGH_RISK_COUNT*10 - MEDIUM_RISK_COUNT*5 - LOW_RISK_COUNT*2))
    if [ "$score" -lt 0 ]; then
        score=0
    fi
    
    echo ""
    echo -e "总体评分: ${BLUE}$score/100${NC}"
    
    # 安全等级
    if [ "$score" -ge 90 ]; then
        echo -e "安全等级: ${GREEN}A (优秀)${NC}"
    elif [ "$score" -ge 75 ]; then
        echo -e "安全等级: ${GREEN}B (良好)${NC}"
    elif [ "$score" -ge 60 ]; then
        echo -e "安全等级: ${YELLOW}C (一般)${NC}"
    else
        echo -e "安全等级: ${RED}D (需要改进)${NC}"
    fi
    
    # 添加到报告
    echo "" >> "$REPORT_FILE"
    echo "=== 审计总结 ===" >> "$REPORT_FILE"
    echo "高危问题: $HIGH_RISK_COUNT 个" >> "$REPORT_FILE"
    echo "中危问题: $MEDIUM_RISK_COUNT 个" >> "$REPORT_FILE"
    echo "低危问题: $LOW_RISK_COUNT 个" >> "$REPORT_FILE"
    echo "总体评分: $score/100" >> "$REPORT_FILE"
    
    if [ "$score" -ge 90 ]; then
        echo "安全等级: A (优秀)" >> "$REPORT_FILE"
    elif [ "$score" -ge 75 ]; then
        echo "安全等级: B (良好)" >> "$REPORT_FILE"
    elif [ "$score" -ge 60 ]; then
        echo "安全等级: C (一般)" >> "$REPORT_FILE"
    else
        echo "安全等级: D (需要改进)" >> "$REPORT_FILE"
    fi
    
    echo "" >> "$REPORT_FILE"
    echo "=== 建议 ===" >> "$REPORT_FILE"
    
    if [ "$HIGH_RISK_COUNT" -gt 0 ]; then
        echo "1. 优先修复所有高危问题" >> "$REPORT_FILE"
    fi
    
    if [ "$MEDIUM_RISK_COUNT" -gt 0 ]; then
        echo "2. 修复中危问题以提升代码质量" >> "$REPORT_FILE"
    fi
    
    if [ "$LOW_RISK_COUNT" -gt 0 ]; then
        echo "3. 考虑修复低危问题作为代码优化" >> "$REPORT_FILE"
    fi
    
    if [ "$score" -lt 60 ]; then
        echo "4. 建议进行全面代码重构和测试" >> "$REPORT_FILE"
    fi
}

# 主函数
main() {
    echo "开始代码审计..."
    echo ""
    
    # 创建审计报告
    create_report
    
    # 执行各项审计
    audit_unhandled_errors
    audit_infinite_loops
    audit_resource_leaks
    audit_security_validation
    audit_env_variables
    audit_performance_issues
    
    # 生成总结
    generate_summary
    
    echo ""
    echo -e "${GREEN}审计完成！${NC}"
}

# 运行主函数
main "$@"