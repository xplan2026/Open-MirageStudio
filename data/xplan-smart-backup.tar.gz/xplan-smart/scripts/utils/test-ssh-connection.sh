#!/bin/bash

# SSH连接测试脚本

echo "=========================================="
echo "  SSH连接测试"
echo "=========================================="
echo ""

SERVER_IP="47.116.48.233"
USERNAME="root"
PASSWORD="898gkgroupadmin!"

echo "服务器信息:"
echo "  IP: $SERVER_IP"
echo "  用户名: $USERNAME"
echo "  端口: 22"
echo ""

# 检查sshpass是否安装
if ! command -v sshpass &> /dev/null; then
    echo "安装sshpass..."
    sudo apt-get update -qq && sudo apt-get install -y sshpass
fi

echo "测试连接..."
echo "------------------------------------------"

# 测试连接
timeout 10 sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 -o BatchMode=yes $USERNAME@$SERVER_IP "echo '✅ SSH连接成功！' && echo '' && echo '服务器信息：' && uname -a && echo '' && echo 'Node.js版本：' && node --version 2>/dev/null || echo 'Node.js未安装'"

EXIT_CODE=$?

echo ""
echo "------------------------------------------"
echo "测试结果:"

if [ $EXIT_CODE -eq 0 ]; then
    echo "✅ SSH连接成功！"
    echo ""
    echo "服务器已准备好，可以执行："
    echo "  1. bash scripts/deploy-to-server.sh"
    echo "  2. bash scripts/start-services.sh"
    echo "  3. bash scripts/check-status.sh"
elif [ $EXIT_CODE -eq 124 ]; then
    echo "⏱️  连接超时"
    echo ""
    echo "可能的原因："
    echo "  1. 服务器未运行"
    echo "  2. 防火墙阻止连接"
    echo "  3. 安全组未开放22端口"
    echo ""
    echo "请参考：/workspace/aliyun-fix-guide.md"
else
    echo "❌ 连接失败 (错误码: $EXIT_CODE)"
    echo ""
    echo "可能的原因："
    echo "  1. 密码错误"
    echo "  2. 服务器配置问题"
    echo "  3. 网络问题"
    echo ""
    echo "请参考：/workspace/aliyun-fix-guide.md"
fi

echo ""
echo "手动连接命令："
echo "  ssh $USERNAME@$SERVER_IP"
echo "  密码: $PASSWORD"