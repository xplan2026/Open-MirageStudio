#!/usr/bin/env node
/**
 * @fileoverview 统一密钥管理工具
 * 提供钱包私钥和 Supabase 密钥的加密、解密、验证功能
 * @updated 2026-04-13T14:35:00.000Z
 * @lifecycle 开发
 */

require('dotenv').config();
const Encryption = require('../../src/utils/encryption');
const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');

// 颜色输出
const GREEN = '\x1b[32m';
const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const CYAN = '\x1b[36m';
const NC = '\x1b[0m';

const log = {
  info: (msg) => console.log(`${CYAN}[INFO]${NC} ${msg}`),
  success: (msg) => console.log(`${GREEN}[SUCCESS]${NC} ${msg}`),
  error: (msg) => console.error(`${RED}[ERROR]${NC} ${msg}`),
  warn: (msg) => console.warn(`${YELLOW}[WARNING]${NC} ${msg}`),
  section: (title) => console.log(`\n${CYAN}========================================${NC}\n${CYAN}${title}${NC}\n${CYAN}========================================${NC}\n`)
};

/**
 * 密钥管理器类
 */
class KeyManager {
  constructor() {
    this.encryption = new Encryption();
  }

  /**
   * 加密 Supabase 匿名密钥
   */
  encryptSupabaseKey() {
    log.section('Supabase 匿名密钥加密');

    const currentSupabaseKey = process.env.SUPABASE_ANON_KEY;

    if (!currentSupabaseKey) {
      log.error('.env 文件中未找到 SUPABASE_ANON_KEY');
      return null;
    }

    log.info(`当前密钥: ${currentSupabaseKey.substring(0, 20)}...${currentSupabaseKey.substring(currentSupabaseKey.length - 20)}`);

    try {
      const encrypted = this.encryption.encrypt(currentSupabaseKey);
      const encryptedKey = Buffer.from(JSON.stringify(encrypted)).toString('base64');

      log.success('加密成功');
      log.info(`加密后密钥: ${encryptedKey.substring(0, 40)}...`);

      // 验证解密
      const decrypted = this.decryptSupabaseKey(encryptedKey);
      if (decrypted === currentSupabaseKey) {
        log.success('加密验证通过: 解密后与原密钥一致');
      } else {
        log.error('加密验证失败');
        return null;
      }

      return encryptedKey;
    } catch (error) {
      log.error(`加密失败: ${error.message}`);
      return null;
    }
  }

  /**
   * 解密 Supabase 密钥
   */
  decryptSupabaseKey(encryptedKey) {
    const key = encryptedKey || process.env.SUPABASE_ANON_KEY_ENCRYPTED;
    if (!key) {
      throw new Error('未找到加密的 Supabase 密钥');
    }

    const jsonStr = Buffer.from(key, 'base64').toString('utf8');
    const encryptedData = JSON.parse(jsonStr);
    return this.encryption.decrypt(encryptedData);
  }

  /**
   * 验证 Supabase 密钥
   */
  verifySupabaseKey() {
    log.section('Supabase 密钥验证');

    const encryptedKey = process.env.SUPABASE_ANON_KEY_ENCRYPTED || process.env.SUPABASE_ANON_KEY;

    if (!encryptedKey) {
      log.error('未找到 SUPABASE_ANON_KEY_ENCRYPTED 或 SUPABASE_ANON_KEY');
      return false;
    }

    try {
      const decryptedKey = this.decryptSupabaseKey(encryptedKey);
      log.success('解密成功');
      log.info(`解密后密钥: ${decryptedKey.substring(0, 20)}...`);

      // 验证 JWT 格式
      if (decryptedKey.startsWith('eyJ') && decryptedKey.includes('.')) {
        log.success('密钥格式验证通过: 符合 JWT 格式');
      } else {
        log.warn('密钥格式不符合预期 JWT 格式');
      }

      return true;
    } catch (error) {
      log.error(`解密失败: ${error.message}`);
      return false;
    }
  }

  /**
   * 验证钱包私钥与地址匹配
   */
  verifyWalletKey(address, encryptedPrivateKey, walletName = 'Wallet') {
    log.section(`${walletName} 私钥验证`);

    log.info(`配置地址: ${address}`);

    if (!encryptedPrivateKey) {
      log.error('未找到加密私钥');
      return false;
    }

    try {
      const privateKey = this.encryption.decryptPrivateKey(encryptedPrivateKey);
      log.success('私钥解密成功');

      // 验证私钥格式
      if (!privateKey.startsWith('0x')) {
        log.error('私钥格式不正确，应该以 "0x" 开头');
        return false;
      }
      log.success('私钥格式验证通过');

      // 从私钥推导地址
      const wallet = new ethers.Wallet(privateKey);
      const derivedAddress = wallet.address;

      log.info(`推导地址: ${derivedAddress}`);

      if (derivedAddress.toLowerCase() === address.toLowerCase()) {
        log.success(`验证通过: ${walletName} 地址与私钥匹配`);
        return true;
      } else {
        log.error('验证失败: 地址与私钥不匹配');
        return false;
      }
    } catch (error) {
      log.error(`验证失败: ${error.message}`);
      return false;
    }
  }

  /**
   * 批量验证被保护钱包
   */
  verifyProtectedWallets() {
    log.section('被保护钱包批量验证');

    const wallets = [
      { address: process.env.PROTECTED_WALLET_1, encryptedKey: process.env.PROTECTED_WALLET_1_ENCRYPTED_KEY, name: 'Wallet 1' },
      { address: process.env.PROTECTED_WALLET_2, encryptedKey: process.env.PROTECTED_WALLET_2_ENCRYPTED_KEY, name: 'Wallet 2' },
      { address: process.env.PROTECTED_WALLET_3, encryptedKey: process.env.PROTECTED_WALLET_3_ENCRYPTED_KEY, name: 'Wallet 3' },
    ].filter(w => w.address && w.encryptedKey);

    if (wallets.length === 0) {
      log.warn('未配置被保护钱包或缺少加密密钥');
      return false;
    }

    let allPassed = true;
    for (const wallet of wallets) {
      const passed = this.verifyWalletKey(wallet.address, wallet.encryptedKey, wallet.name);
      if (!passed) allPassed = false;
    }

    return allPassed;
  }

  /**
   * 测试加密解密功能
   */
  testEncryption() {
    log.section('加密解密功能测试');

    log.info(`ENCRYPTION_KEY: ${process.env.ENCRYPTION_KEY ? '(已配置)' : '(未配置)'}`);

    try {
      const testData = 'test123';
      const encrypted = this.encryption.encrypt(testData);
      log.success(`加密成功: ${JSON.stringify(encrypted)}`);

      const decrypted = this.encryption.decrypt(encrypted);
      log.success(`解密成功: ${decrypted}`);

      if (decrypted === testData) {
        log.success('加密解密验证通过');
        return true;
      } else {
        log.error('加密解密验证失败');
        return false;
      }
    } catch (error) {
      log.error(`测试失败: ${error.message}`);
      return false;
    }
  }

  /**
   * 初始化钱包密钥
   */
  initWallet() {
    log.section('钱包密钥初始化');

    const safeWalletAddress = process.env.SAFE_WALLET;
    const safeWalletPrivateKey = process.env.SAFE_WALLET_PRIVATE_KEY;

    if (!safeWalletAddress || !safeWalletPrivateKey) {
      log.error('未配置安全钱包地址或私钥');
      return false;
    }

    log.info(`钱包地址: ${safeWalletAddress}`);

    try {
      const encryptedKey = this.encryption.encryptPrivateKey(safeWalletPrivateKey);
      log.success('私钥加密成功');
      log.info(`加密后: ${encryptedKey.substring(0, 30)}...`);

      // 写入文件
      const walletKeysFile = path.join(__dirname, '../storage/wallet-keys.json');
      const walletKeysData = {
        safe_wallet: {
          address: safeWalletAddress,
          encryptedPrivateKey: encryptedKey
        }
      };

      fs.writeFileSync(walletKeysFile, JSON.stringify(walletKeysData, null, 2));
      log.success(`wallet-keys.json 已写入: ${walletKeysFile}`);

      return true;
    } catch (error) {
      log.error(`初始化失败: ${error.message}`);
      return false;
    }
  }

  /**
   * 初始化被保护钱包
   */
  initProtectedWallets() {
    log.section('被保护钱包初始化');

    const protectedWalletsStr = process.env.PROTECTED_WALLETS;
    if (!protectedWalletsStr) {
      log.error('未配置被保护钱包列表 (PROTECTED_WALLETS)');
      return false;
    }

    const walletAddresses = protectedWalletsStr.split(',').map(addr => addr.trim().toLowerCase());
    log.info(`发现 ${walletAddresses.length} 个被保护钱包`);

    const walletKeysFile = path.join(__dirname, '../storage/wallet-keys.json');
    let walletKeysData = {};

    try {
      if (fs.existsSync(walletKeysFile)) {
        walletKeysData = JSON.parse(fs.readFileSync(walletKeysFile, 'utf8'));
        log.info('读取现有 wallet-keys.json');
      }
    } catch (error) {
      log.info('创建新的 wallet-keys.json');
    }

    if (!walletKeysData.protected_wallets) {
      walletKeysData.protected_wallets = {};
    }

    let successCount = 0;
    let failCount = 0;

    for (const address of walletAddresses) {
      const privateKeyEnvKey = `WALLET_PRIVATE_KEY_${address.replace(/0x/g, '').toUpperCase()}`;
      const privateKey = process.env[privateKeyEnvKey];

      if (!privateKey) {
        log.error(`未配置私钥: ${privateKeyEnvKey}`);
        failCount++;
        continue;
      }

      try {
        const encryptedKey = this.encryption.encryptPrivateKey(privateKey);
        walletKeysData.protected_wallets[address] = {
          address: address,
          encryptedPrivateKey: encryptedKey
        };
        log.success(`钱包 ${address} 私钥加密成功`);
        successCount++;
      } catch (error) {
        log.error(`钱包 ${address} 加密失败: ${error.message}`);
        failCount++;
      }
    }

    fs.writeFileSync(walletKeysFile, JSON.stringify(walletKeysData, null, 2));
    log.success(`wallet-keys.json 已更新 (成功: ${successCount}, 失败: ${failCount})`);

    return failCount === 0;
  }
}

// CLI 入口
function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'help';

  const keyManager = new KeyManager();

  const commands = {
    // 测试命令
    'test': () => keyManager.testEncryption() ? process.exit(0) : process.exit(1),

    // Supabase 密钥命令
    'encrypt:supabase': () => {
      const result = keyManager.encryptSupabaseKey();
      if (result) {
        console.log('\n建议更新 .env 文件:');
        console.log(`SUPABASE_ANON_KEY_ENCRYPTED=${result}`);
      }
      process.exit(result ? 0 : 1);
    },
    'verify:supabase': () => keyManager.verifySupabaseKey() ? process.exit(0) : process.exit(1),

    // 钱包密钥命令
    'verify:wallet': () => {
      const address = args[1] || process.env.SAFE_WALLET;
      const encryptedKey = args[2] || process.env.SAFE_WALLET_ENCRYPTED_PRIVATE_KEY;
      keyManager.verifyWalletKey(address, encryptedKey, 'Safe Wallet');
      process.exit(0);
    },
    'verify:protected': () => keyManager.verifyProtectedWallets() ? process.exit(0) : process.exit(1),

    // 初始化命令
    'init:wallet': () => keyManager.initWallet() ? process.exit(0) : process.exit(1),
    'init:protected': () => keyManager.initProtectedWallets() ? process.exit(0) : process.exit(1),

    // 帮助
    'help': () => {
      console.log(`
统一密钥管理工具

用法:
  node key-manager.js <命令> [参数]

命令:
  test                  测试加密解密功能
  encrypt:supabase      加密 Supabase 匿名密钥
  verify:supabase       验证 Supabase 密钥
  verify:wallet [地址] [加密私钥]  验证钱包私钥与地址匹配
  verify:protected      批量验证被保护钱包
  init:wallet           初始化安全钱包密钥到 wallet-keys.json
  init:protected        初始化被保护钱包密钥到 wallet-keys.json
  help                  显示帮助信息

示例:
  node key-manager.js test
  node key-manager.js encrypt:supabase
  node key-manager.js verify:supabase
  node key-manager.js verify:protected
  node key-manager.js init:wallet
`);
      process.exit(0);
    }
  };

  if (commands[command]) {
    commands[command]();
  } else {
    log.error(`未知命令: ${command}`);
    commands['help']();
  }
}

// 导出类供其他模块使用
module.exports = KeyManager;

// 如果直接运行此脚本
if (require.main === module) {
  main();
}
