/**
 * @fileoverview RPC 节点连接测试工具
 * @lifecycle 开发周期
 * @updated 2026-04-03T21:30:00.000Z
 * @author alexiadai
 */

const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');

/**
 * 从 .env.production 文件读取 RPC 节点列表
 * @returns {Array<string>} RPC 节点列表
 */
function getRpcNodesFromEnv() {
  const envPath = path.join(__dirname, '../../.env.production');
  
  if (!fs.existsSync(envPath)) {
    console.error('错误: 找不到 .env.production 文件');
    process.exit(1);
  }

  const envContent = fs.readFileSync(envPath, 'utf-8');
  const match = envContent.match(/^BSC_RPC_URLS=(.+)$/m);
  
  if (!match) {
    console.log('提示: .env.production 中未找到 BSC_RPC_URLS 配置，使用默认节点');
    return null;
  }

  const nodes = match[1].split(',').map(url => url.trim()).filter(url => url);
  
  if (nodes.length === 0) {
    console.log('提示: BSC_RPC_URLS 配置为空，使用默认节点');
    return null;
  }

  return nodes;
}

/**
 * 获取默认的 RPC 节点列表（与 rpc-pool.js 保持一致）
 * @returns {Array<string>} RPC 节点列表
 */
function getDefaultRpcNodes() {
  return [
    'https://bsc-rpc.publicnode.com',     // 最稳定（长期实践验证）
    'https://bsc-dataseed3.defibit.io',  // 100%成功率, 平均243ms
    'https://bsc-dataseed3.ninicoin.io',  // 100%成功率, 平均253ms
    'https://bsc-dataseed2.defibit.io',  // 100%成功率, 平均283ms
    'https://bsc-dataseed4.ninicoin.io'   // 100%成功率, 平均303ms
  ];
}

/**
 * 测试单个 RPC 节点的连接性
 * @param {string} rpcUrl - RPC 节点 URL
 * @param {number} timeout - 超时时间（毫秒）
 * @returns {Promise<Object>} 测试结果
 */
async function testRpcNode(rpcUrl, timeout = 7000) {
  const startTime = Date.now();
  
  try {
    const provider = new ethers.providers.JsonRpcProvider(rpcUrl);
    
    const blockNumber = await Promise.race([
      provider.getBlockNumber(),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Timeout')), timeout)
      )
    ]);
    
    const latency = Date.now() - startTime;
    const network = await provider.getNetwork();
    
    return {
      url: rpcUrl,
      status: 'success',
      latency,
      blockNumber: blockNumber.toString(),
      chainId: network.chainId.toString()
    };
  } catch (error) {
    const latency = Date.now() - startTime;
    
    return {
      url: rpcUrl,
      status: 'failed',
      latency,
      error: error.message
    };
  }
}

/**
 * 主函数
 */
async function main() {
  const args = process.argv.slice(2);
  const concurrency = args[0] ? parseInt(args[0]) : 3;
  
  if (isNaN(concurrency) || concurrency < 1) {
    console.error('错误: 并发数量必须是正整数');
    console.log('用法: node test-rpc-connection.js [并发数量]');
    console.log('示例: node test-rpc-connection.js 3');
    process.exit(1);
  }

  const customNodes = getRpcNodesFromEnv();
  const RPC_NODES = customNodes || getDefaultRpcNodes();
  
  if (customNodes) {
    console.log('使用自定义 RPC 节点池（.env.production）');
  } else {
    console.log('使用默认 RPC 节点池（代码内置）');
  }
  
  console.log('='.repeat(80));
  console.log('RPC 节点连接测试');
  console.log('='.repeat(80));
  console.log(`配置文件: .env.production`);
  console.log(`节点数量: ${RPC_NODES.length}`);
  console.log(`并发数量: ${concurrency}`);
  console.log(`测试时间: ${new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' })}`);
  console.log('='.repeat(80));
  console.log();

  const results = [];
  let successCount = 0;
  let failedCount = 0;

  for (let i = 0; i < RPC_NODES.length; i += concurrency) {
    const batch = RPC_NODES.slice(i, i + concurrency);
    
    console.log(`正在测试第 ${i + 1}-${Math.min(i + concurrency, RPC_NODES.length)} 个节点...`);
    
    const batchResults = await Promise.all(
      batch.map(rpcUrl => testRpcNode(rpcUrl))
    );
    
    results.push(...batchResults);
  }

  console.log();
  console.log('='.repeat(80));
  console.log('测试结果');
  console.log('='.repeat(80));
  console.log();

  results.forEach((result, index) => {
    const statusIcon = result.status === 'success' ? '✅' : '❌';
    
    console.log(`${statusIcon} 节点 ${index + 1}: ${result.url}`);
    console.log(`   状态: ${result.status === 'success' ? '成功' : '失败'}`);
    console.log(`   延迟: ${result.latency}ms`);
    
    if (result.status === 'success') {
      console.log(`   区块号: ${result.blockNumber}`);
      console.log(`   Chain ID: ${result.chainId}`);
      successCount++;
    } else {
      console.log(`   错误: ${result.error}`);
      failedCount++;
    }
    console.log();
  });

  console.log('='.repeat(80));
  console.log('统计信息');
  console.log('='.repeat(80));
  console.log(`总节点数: ${RPC_NODES.length}`);
  console.log(`成功: ${successCount} (${((successCount / RPC_NODES.length) * 100).toFixed(1)}%)`);
  console.log(`失败: ${failedCount} (${((failedCount / RPC_NODES.length) * 100).toFixed(1)}%)`);
  
  const successfulNodes = results.filter(r => r.status === 'success');
  if (successfulNodes.length > 0) {
    const avgLatency = successfulNodes.reduce((sum, r) => sum + r.latency, 0) / successfulNodes.length;
    console.log(`平均延迟: ${avgLatency.toFixed(0)}ms`);
    
    const blockNumbers = successfulNodes.map(n => parseInt(n.blockNumber));
    const maxBlock = Math.max(...blockNumbers);
    const minBlock = Math.min(...blockNumbers);
    const blockDiff = maxBlock - minBlock;
    console.log(`区块差异: ${blockDiff} 个区块`);
  }
  
  console.log('='.repeat(80));

  // 检查是否达标
  const successRate = (successCount / RPC_NODES.length) * 100;
  if (successRate >= 80 && successfulNodes.length > 0) {
    console.log('✅ 测试通过: RPC 节点连接正常');
    process.exit(0);
  } else {
    console.log('❌ 测试失败: RPC 节点连接异常');
    process.exit(1);
  }
}

if (require.main === module) {
  main().catch(error => {
    console.error('错误:', error);
    process.exit(1);
  });
}
