#!/usr/bin/env node
/**
 * @fileoverview 钱包余额查询工具
 * 支持查询 wkeyDAO2 代币和 BNB 余额
 * @updated 2026-04-13T14:50:00.000Z
 */

require('dotenv').config();
const { ethers } = require('ethers');

const WKEYDAO2_ADDRESS = '0xe0a281deff5c9d8d67af09d39340e134ac81b82e';
const RPC_URL = process.env.BSC_RPC_URL || 'https://bsc.publicnode.com';

const GREEN = '\x1b[32m';
const RED = '\x1b[31m';
const CYAN = '\x1b[36m';
const NC = '\x1b[0m';

const log = {
  info: (msg) => console.log(`${CYAN}[INFO]${NC} ${msg}`),
  success: (msg) => console.log(`${GREEN}[OK]${NC} ${msg}`),
  error: (msg) => console.error(`${RED}[ERROR]${NC} ${msg}`),
};

// 被保护钱包列表
const PROTECTED_WALLETS = [
  { address: '0x886b739ba73c1ccae826cb11c8d28e4750c68a89', name: 'scanner-8a89' },
  { address: '0x3D3914960567b3A253C429d5Ab81DA1F386F9111', name: 'scanner-9111' },
  { address: '0x9f4fb2e9f0bb920efcee6ca21ebf1b6a2f8d8e16', name: 'scanner-8e16' }
];

// ERC20 ABI
const ERC20_ABI = [
  'function balanceOf(address owner) view returns (uint256)'
];

async function checkBNBBalance(provider, wallet) {
  try {
    const balance = await provider.getBalance(wallet.address);
    const balanceInBNB = ethers.utils.formatEther(balance);
    console.log(`${wallet.name} (${wallet.address}):`);
    console.log(`  BNB: ${parseFloat(balanceInBNB).toFixed(6)}`);
    return { name: wallet.name, bnb: balanceInBNB };
  } catch (error) {
    console.log(`${wallet.name}: 查询失败 - ${error.message}`);
    return null;
  }
}

async function checkTokenBalance(provider, tokenAddress, wallet) {
  try {
    const contract = new ethers.Contract(tokenAddress, ERC20_ABI, provider);
    const balance = await contract.balanceOf(wallet.address);
    const formatted = ethers.utils.formatUnits(balance, 18);
    console.log(`${wallet.name} (${wallet.address}):`);
    console.log(`  ${formatted}`);
    return { name: wallet.name, balance: formatted };
  } catch (error) {
    console.log(`${wallet.name}: 查询失败 - ${error.message}`);
    return null;
  }
}

async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'all';

  log.info(`RPC: ${RPC_URL}`);
  console.log('');

  const provider = new ethers.providers.JsonRpcProvider(RPC_URL);

  switch (command) {
    case 'bnb':
      console.log('=== BNB 余额 ===\n');
      for (const wallet of PROTECTED_WALLETS) {
        await checkBNBBalance(provider, wallet);
        console.log('');
      }
      break;

    case 'wkeydao2':
    case 'token':
      console.log('=== wkeyDAO2 代币余额 ===\n');
      for (const wallet of PROTECTED_WALLETS) {
        await checkTokenBalance(provider, WKEYDAO2_ADDRESS, wallet);
        console.log('');
      }
      break;

    case 'all':
    default:
      console.log('=== BNB 余额 ===\n');
      for (const wallet of PROTECTED_WALLETS) {
        await checkBNBBalance(provider, wallet);
        console.log('');
      }

      console.log('=== wkeyDAO2 代币余额 ===\n');
      for (const wallet of PROTECTED_WALLETS) {
        await checkTokenBalance(provider, WKEYDAO2_ADDRESS, wallet);
        console.log('');
      }
      break;

    case 'help':
      console.log(`
钱包余额查询工具

用法:
  node check-balances.js [选项]

选项:
  bnb       只查询 BNB 余额
  token     只查询 wkeyDAO2 代币余额
  all       查询所有余额（默认）
  help      显示帮助信息

示例:
  node check-balances.js
  node check-balances.js bnb
  node check-balances.js token
`);
      process.exit(0);
  }
}

main().catch(console.error);
