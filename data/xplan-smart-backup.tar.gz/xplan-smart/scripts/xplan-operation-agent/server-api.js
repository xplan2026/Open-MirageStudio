/**
 * Xplan-Operation-Agent 服务器端 API
 * 
 * 提供健康检查接口供 Cloudflare Worker 调用
 * 
 * 接口:
 *   GET /health          - 基础健康检查
 *   GET /pm2-status      - PM2 进程状态
 *   GET /transactions    - 最新5笔交易记录
 *   GET /errors          - 最新错误日志
 * 
 * 启动: node xplan-operation-agent.js
 * 端口: 3000 (可通过 PORT 环境变量修改)
 */

const http = require('http');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const PROJECT_DIR = '/opt/xplan-smart';

/**
 * 执行命令并返回结果
 */
function execCommand(cmd) {
  try {
    return execSync(cmd, { encoding: 'utf-8', timeout: 30000 }).trim();
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * 获取 PM2 进程状态
 */
function getPM2Status() {
  try {
    const output = execCommand('cd ' + PROJECT_DIR + ' && ./node_modules/.bin/pm2 jlist');
    const processes = JSON.parse(output);
    
    const status = processes.map(proc => ({
      name: proc.name,
      status: proc.pm2_env?.status || 'unknown',
      uptime: proc.pm2_env?.pm_uptime ? 
        Math.floor((Date.now() - proc.pm2_env.pm_uptime) / 1000) : 0,
      restart_count: proc.pm2_env?.restart_time || 0,
      memory: proc.monit?.memory || 0,
      cpu: proc.monit?.cpu || 0
    }));
    
    // 检查是否有异常进程
    const hasError = status.some(p => 
      p.status !== 'online' || p.restart_count > 0
    );
    
    return { ok: !hasError, processes: status };
  } catch (error) {
    return { ok: false, error: error.message };
  }
}

/**
 * 获取最新错误日志
 */
function getRecentErrors() {
  const logsDir = path.join(PROJECT_DIR, 'logs');
  const errors = [];
  
  try {
    // 检查各个服务的错误日志
    const errorFiles = [
      'scanner-9111-error.log',
      'scanner-8a89-error.log',
      'scanner-8e16-error.log',
      'scanner-bnb-error.log',
      'gas-alert-error.log',
      'log-cleaner-error.log'
    ];
    
    for (const file of errorFiles) {
      const filePath = path.join(logsDir, file);
      if (fs.existsSync(filePath)) {
        const content = fs.readFileSync(filePath, 'utf-8');
        if (content && content.trim()) {
          const lines = content.trim().split('\n').slice(-5);
          errors.push({
            service: file.replace('-error.log', ''),
            errors: lines.filter(l => l.toLowerCase().includes('error') || l.toLowerCase().includes('warn'))
          });
        }
      }
    }
    
    return errors.filter(e => e.errors.length > 0);
  } catch (error) {
    return [{ error: error.message }];
  }
}

/**
 * 获取最新交易记录
 */
function getTransactions() {
  try {
    const txFile = path.join(PROJECT_DIR, 'cache/transactions.json');
    
    if (!fs.existsSync(txFile)) {
      return [];
    }
    
    const content = fs.readFileSync(txFile, 'utf-8');
    const transactions = JSON.parse(content);
    
    // 返回最后5笔交易
    return transactions.slice(-5);
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * HTTP 请求处理
 */
function handleRequest(req, res) {
  // CORS 头
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }
  
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const pathname = url.pathname;
  
  // 设置 JSON 响应头
  res.setHeader('Content-Type', 'application/json');
  
  try {
    switch (pathname) {
      case '/health':
        res.writeHead(200);
        res.end(JSON.stringify({ 
          status: 'ok', 
          timestamp: new Date().toISOString(),
          uptime: process.uptime()
        }));
        break;
        
      case '/pm2-status':
        const pm2Status = getPM2Status();
        res.writeHead(pm2Status.ok ? 200 : 503);
        res.end(JSON.stringify(pm2Status));
        break;
        
      case '/transactions':
        const transactions = getTransactions();
        res.writeHead(200);
        res.end(JSON.stringify({ transactions }));
        break;
        
      case '/errors':
        const errors = getRecentErrors();
        res.writeHead(200);
        res.end(JSON.stringify({ 
          hasErrors: errors.length > 0,
          errors 
        }));
        break;
        
      case '/status':
        // 综合状态检查
        const pm2 = getPM2Status();
        const errs = getRecentErrors();
        const txs = getTransactions();
        
        res.writeHead((pm2.ok && errors.length === 0) ? 200 : 503);
        res.end(JSON.stringify({
          status: (pm2.ok && errors.length === 0) ? 'ok' : 'error',
          pm2,
          errors: errs,
          latestTransactions: txs.slice(-5),
          timestamp: new Date().toISOString()
        }));
        break;
        
      default:
        res.writeHead(404);
        res.end(JSON.stringify({ error: 'Not Found' }));
    }
  } catch (error) {
    res.writeHead(500);
    res.end(JSON.stringify({ error: error.message }));
  }
}

// 启动服务器
const server = http.createServer(handleRequest);

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[Xplan-Operation-Agent API] 启动成功`);
  console.log(`[Xplan-Operation-Agent API] 监听端口: ${PORT}`);
  console.log(`[Xplan-Operation-Agent API] 接口:`);
  console.log(`  - GET /health         基础健康检查`);
  console.log(`  - GET /pm2-status     PM2 进程状态`);
  console.log(`  - GET /transactions   最新交易记录`);
  console.log(`  - GET /errors         最新错误日志`);
  console.log(`  - GET /status         综合状态检查`);
});

// 优雅关闭
process.on('SIGTERM', () => {
  console.log('[Xplan-Operation-Agent API] 收到关闭信号...');
  server.close(() => {
    console.log('[Xplan-Operation-Agent API] 已关闭');
    process.exit(0);
  });
});
