#!/bin/bash

# 动态输出 scanner-9111 日志脚本
# 用法: bash scripts/watch-logs.sh
# 生命周期: 已部署
# 更新时间: 2026-03-28T15:00:00.000Z

echo "========================================"
echo "  监控 scanner-9111 日志"
echo "  按 Ctrl+C 停止监控"
echo "========================================"
echo ""

# 检查 PM2 进程是否存在
if ! pm2 list | grep -q "scanner-9111"; then
    echo "❌ scanner-9111 进程不存在"
    echo ""
    echo "当前 PM2 进程列表:"
    pm2 list
    exit 1
fi

# 检查进程状态
PROCESS_STATUS=$(pm2 jlist scanner-9111 | jq -r '.[0].pm2_env.status' 2>/dev/null || echo "unknown")

if [ "$PROCESS_STATUS" != "online" ]; then
    echo "⚠️  scanner-9111 进程状态: $PROCESS_STATUS"
    echo ""
    echo "进程详细信息:"
    pm2 show scanner-9111
    echo ""
    echo "最新错误日志:"
    pm2 logs scanner-9111 --err --lines 20 --nostream
    echo ""
    exit 1
fi

echo "✅ scanner-9111 进程状态: $PROCESS_STATUS"
echo ""

# 获取日志文件路径
OUT_LOG_PATH=$(pm2 show scanner-9111 | grep "out log path" | awk '{print $NF}')
ERR_LOG_PATH=$(pm2 show scanner-9111 | grep "error log path" | awk '{print $NF}')

echo "日志文件路径:"
echo "  输出: $OUT_LOG_PATH"
echo "  错误: $ERR_LOG_PATH"
echo ""
echo "========================================"
echo "  实时日志 (动态刷新)"
echo "========================================"
echo ""

# 使用 tail -f 动态监控日志文件
if [ -f "$OUT_LOG_PATH" ]; then
    tail -f "$OUT_LOG_PATH" 2>/dev/null &
    TAIL_PID=$!
    
    # 捕获 Ctrl+C 信号
    trap "kill $TAIL_PID 2>/dev/null; echo ''; echo ''; echo '✅ 监控已停止'; exit 0" INT TERM
    
    # 等待后台进程
    wait $TAIL_PID
else
    echo "⚠️  日志文件不存在: $OUT_LOG_PATH"
    echo ""
    echo "尝试使用 PM2 logs 命令查看最新日志:"
    pm2 logs scanner-9111 --lines 50 --nostream
fi
