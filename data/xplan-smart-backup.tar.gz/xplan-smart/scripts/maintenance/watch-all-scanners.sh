#!/bin/bash

# 监控所有 scanner 日志脚本
# 用法: bash scripts/watch-all-scanners.sh
# 生命周期: 已部署
# 更新时间: 2026-03-28T15:00:00.000Z

echo "========================================"
echo "  监控所有 Scanner 日志"
echo "  按 Ctrl+C 停止监控"
echo "========================================"
echo ""

# 获取所有 scanner 进程
SCANNERS=$(pm2 list | grep "scanner-" | awk '{print $12}')

if [ -z "$SCANNERS" ]; then
    echo "❌ 没有找到任何 scanner 进程"
    echo ""
    echo "当前 PM2 进程列表:"
    pm2 list
    exit 1
fi

echo "找到以下 scanner 进程:"
echo "$SCANNERS" | nl
echo ""
echo "========================================"
echo "  实时日志 (动态刷新)"
echo "========================================"
echo ""

# 使用 PM2 logs 监控所有 scanner
pm2 logs scanner-8a89 scanner-8e16 scanner-9111 --lines 0
