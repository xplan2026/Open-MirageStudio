#!/bin/bash

# 动态输出 scanner 日志脚本
# 用法: bash scripts/watch-scanner-logs.sh [scanner名称]
# 生命周期: 已部署
# 更新时间: 2026-03-28T15:00:00.000Z

# 默认监控 scanner-9111
SCANNER_NAME=${1:-"scanner-9111"}

echo "========================================"
echo "  监控 $SCANNER_NAME 日志"
echo "  按 Ctrl+C 停止监控"
echo "========================================"
echo ""

# 检查 PM2 进程是否存在
if ! pm2 list | grep -q "$SCANNER_NAME"; then
    echo "❌ $SCANNER_NAME 进程不存在"
    echo ""
    echo "当前 PM2 进程列表:"
    pm2 list
    echo ""
    echo "可用的 scanner 进程:"
    pm2 list | grep scanner
    exit 1
fi

# 检查进程状态
PROCESS_ID=$(pm2 list | grep "$SCANNER_NAME" | awk '{print $2}' | sed 's/|//g')
PROCESS_STATUS=$(pm2 jlist | jq -r ".[] | select(.name == \"$SCANNER_NAME\") | .pm2_env.status" 2>/dev/null || echo "unknown")

if [ "$PROCESS_STATUS" != "online" ]; then
    echo "⚠️  $SCANNER_NAME 进程状态: $PROCESS_STATUS"
    echo ""
    echo "进程详细信息:"
    pm2 show "$SCANNER_NAME"
    echo ""
    echo "最新错误日志:"
    pm2 logs "$SCANNER_NAME" --err --lines 20 --nostream
    exit 1
fi

echo "✅ $SCANNER_NAME 进程状态: $PROCESS_STATUS"
echo "========================================"
echo "  实时日志 (动态刷新)"
echo "========================================"
echo ""

# 使用 PM2 logs 实时监控
# --lines 0: 只显示新日志，不显示历史日志
pm2 logs "$SCANNER_NAME" --lines 0
