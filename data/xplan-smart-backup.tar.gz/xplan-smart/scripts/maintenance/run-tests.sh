#!/bin/bash

# P0-P2 修复测试脚本
# 用于运行所有修复相关的测试
# 生命周期: 已部署
# 更新时间: 2026-03-28T15:00:00.000Z

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
TEST_DIR="$PROJECT_ROOT/test"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}   P0-P2 修复结果测试脚本${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# 检查是否在正确的目录
if [ ! -f "$PROJECT_ROOT/package.json" ]; then
    echo -e "${RED}错误：未找到 package.json 文件${NC}"
    echo "请确保在项目根目录运行此脚本"
    exit 1
fi

# 显示选项
echo -e "${YELLOW}请选择要运行的测试：${NC}"
echo "1. P0 级别测试（Promise Rejection 和 TransactionQueue）"
echo "2. P1 级别测试（Nonce 管理和定时检查）"
echo "3. P2 级别测试（Start 逻辑和 Logger 性能）"
echo "4. 所有测试（P0 + P1 + P2）"
echo "5. 运行测试并生成覆盖率报告"
echo "0. 退出"
echo ""
read -p "请输入选项 (0-5): " choice

case $choice in
    1)
        echo -e "\n${GREEN}运行 P0 级别测试...${NC}"
        cd "$TEST_DIR"
        npm test -- fix-p0-promise-rejection.test.js fix-p0-transaction-queue.test.js
        ;;
    2)
        echo -e "\n${GREEN}运行 P1 级别测试...${NC}"
        cd "$TEST_DIR"
        npm test -- fix-p1-nonce-management.test.js fix-p1-schedule-check.test.js
        ;;
    3)
        echo -e "\n${GREEN}运行 P2 级别测试...${NC}"
        cd "$TEST_DIR"
        npm test -- fix-p2-start-logic.test.js fix-p2-logger-performance.test.js
        ;;
    4)
        echo -e "\n${GREEN}运行所有测试...${NC}"
        cd "$TEST_DIR"
        npm test -- fix-p0-promise-rejection.test.js \
                     fix-p0-transaction-queue.test.js \
                     fix-p1-nonce-management.test.js \
                     fix-p1-schedule-check.test.js \
                     fix-p2-start-logic.test.js \
                     fix-p2-logger-performance.test.js
        ;;
    5)
        echo -e "\n${GREEN}运行测试并生成覆盖率报告...${NC}"
        cd "$PROJECT_ROOT"
        npm test -- --coverage \
            test/fix-p0-promise-rejection.test.js \
            test/fix-p0-transaction-queue.test.js \
            test/fix-p1-nonce-management.test.js \
            test/fix-p1-schedule-check.test.js \
            test/fix-p2-start-logic.test.js \
            test/fix-p2-logger-performance.test.js
        ;;
    0)
        echo -e "${BLUE}退出测试${NC}"
        exit 0
        ;;
    *)
        echo -e "${RED}无效选项${NC}"
        exit 1
        ;;
esac

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}   测试完成！${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "测试报告位于：${YELLOW}$TEST_DIR/${NC}"
