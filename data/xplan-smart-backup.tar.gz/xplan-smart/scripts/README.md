/**
 * @fileoverview 脚本文件索引 - 项目公共脚本目录
 * @updated 2026-04-13T13:54:00.000Z
 */

# 脚本文件索引

> **更新时间**: 2026-04-13T13:54:00.000Z

## 目录结构

```
scripts/
├── README.md              # 本文件
├── agents/               # Agent 相关脚本（服务器管理）
├── maintenance/          # 维护脚本（日常运维）
└── utils/                # 工具类脚本
```

---

## agents/ - Agent 相关脚本

> 用于 Agent 执行特定任务时调用，配合 `.codebuddy/Agents/server-manager-agent/` 使用

| 文件名 | 描述 | 类型 |
|:---|:---|:---|
| `deployment-workflow-test.js` | 部署后项目工作流测试脚本 | JavaScript |

> **注意**: 服务器操作脚本已迁移到 `.codebuddy/Agents/server-manager-agent/skills/` 目录

### 使用方式

```bash
# 部署后测试（模拟）
node scripts/agents/deployment-workflow-test.js

# 部署后测试（真实）
node scripts/agents/deployment-workflow-test.js --real
```

### 脚本说明

#### deployment-workflow-test.js
- **用途**: 测试部署后 wkeyDAO2 转账工作流
- **功能**:
  - 检查安全钱包中的 wkeyDAO2 余额
  - 根据余额确定转账金额
  - 轮流向被保护钱包转账
  - 生成 Markdown 测试报告
- **服务器管理请使用**:
  ```bash
  bash /workspace/.codebuddy/Agents/server-manager-agent/tools/main.sh <command>
  ```

---

## maintenance/ - 维护脚本

> 用于日常运维操作，包括钱包初始化、测试、监控等

| 文件名 | 描述 | 类型 |
|:---|:---|:---|
| `run-tests.sh` | 运行所有测试 | Bash |
| `watch-all-scanners.sh` | 监控所有 scanner 日志 | Bash |
| `watch-logs.sh` | 监控 scanner-9111 日志 | Bash |
| `watch-scanner-logs.sh` | 动态输出 scanner 日志 | Bash |

### 使用方式

```bash
# 运行测试
bash scripts/maintenance/run-tests.sh

# 监控日志
bash scripts/maintenance/watch-all-scanners.sh
bash scripts/maintenance/watch-logs.sh
bash scripts/maintenance/watch-scanner-logs.sh [scanner名称]
```

### 脚本说明

#### run-tests.sh
- **用途**: 运行所有修复相关的测试

#### watch-all-scanners.sh
- **用途**: 监控所有 scanner 日志
- **停止**: 按 Ctrl+C

#### watch-logs.sh
- **用途**: 监控 scanner-9111 日志
- **停止**: 按 Ctrl+C

#### watch-scanner-logs.sh
- **用途**: 动态输出指定 scanner 的日志
- **参数**: `[scanner名称]` - 默认 scanner-9111
- **停止**: 按 Ctrl+C

---

## utils/ - 工具类脚本

> 通用工具脚本，用于检查、验证、初始化、测试等辅助功能

### 统一密钥管理

> **推荐**: 使用 `key-manager.js` 统一管理所有密钥相关操作

| 命令 | 描述 |
|:---|:---|
| `node key-manager.js test` | 测试加密解密功能 |
| `node key-manager.js encrypt:supabase` | 加密 Supabase 密钥 |
| `node key-manager.js verify:supabase` | 验证 Supabase 密钥 |
| `node key-manager.js verify:wallet [地址] [加密私钥]` | 验证钱包私钥 |
| `node key-manager.js verify:protected` | 批量验证被保护钱包 |
| `node key-manager.js init:wallet` | 初始化安全钱包 |
| `node key-manager.js init:protected` | 初始化被保护钱包 |

### 其他工具

| 文件名 | 描述 | 类型 |
|:---|:---|:---|
| `check-balances.js` | 查询钱包余额（BNB/代币） | JavaScript |
| `code-audit-example.sh` | 代码审计示例脚本 | Bash |
| `key-manager.js` | 统一密钥管理工具 | JavaScript |
| `test-rpc-connection.js` | 测试 RPC 节点连接 | JavaScript |
| `test-ssh-connection.sh` | 测试 SSH 连接 | Bash |

### 使用方式

```bash
# 统一密钥管理（推荐）
node scripts/utils/key-manager.js test
node scripts/utils/key-manager.js encrypt:supabase
node scripts/utils/key-manager.js verify:supabase
node scripts/utils/key-manager.js verify:protected
node scripts/utils/key-manager.js init:wallet
node scripts/utils/key-manager.js init:protected

# 余额查询
node scripts/utils/check-balances.js        # 查询所有
node scripts/utils/check-balances.js bnb   # 只查 BNB
node scripts/utils/check-balances.js token # 只查 wkeyDAO2

# RPC 连接测试
node scripts/utils/test-rpc-connection.js

# SSH 连接测试
bash scripts/utils/test-ssh-connection.sh
```

### 脚本说明

#### key-manager.js（统一密钥管理）
- **用途**: 统一管理钱包私钥和 Supabase 密钥的加密、解密、验证
- **功能**:
  - 加密/解密 Supabase 密钥
  - 验证钱包私钥与地址匹配
  - 批量验证被保护钱包
  - 初始化钱包密钥到 wallet-keys.json
- **依赖**: `src/utils/encryption.js`, `ethers`

#### init-protected-wallets.js
- **用途**: 从环境变量读取被保护钱包私钥，加密后写入 `wallet-keys.json`
- **依赖**: `process.env.PROTECTED_WALLETS`

#### init-wallet.js
- **用途**: 加密安全钱包私钥并写入 `wallet-keys.json`
- **依赖**: `process.env.SAFE_WALLET`, `process.env.SAFE_WALLET_PRIVATE_KEY`

---

## 注意事项

1. **agents/ 脚本**需要配置 `.codebuddy/.env.codebuddy` 中的服务器信息
2. **钱包初始化脚本**需要配置相应的环境变量
3. **监控脚本**需要 PM2 进程管理器
4. **utils/ 工具脚本**主要用于诊断和验证
