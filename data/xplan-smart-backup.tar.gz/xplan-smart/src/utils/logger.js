/**
 * 日志缓存池工具
 * 用于监控进程动态转发日志到前端
 * @updated 2026-03-25T14:30:00.000Z
 * @lifecycle 已部署
 */

class Logger {
  constructor() {
    this.logBuffer = [];
    this.maxBufferSize = parseInt(process.env.REALTIME_LOG_BUFFER_SIZE) || 1000;
    this.isEnabled = false;
    this.startTime = null;
    this.lastActivityTime = null;
    this.inactivityTimeout = 5 * 60 * 1000; // 5 分钟无操作自动停止
    this.inactivityCheckInterval = null;
    
    // P2修复：使用循环缓冲区，避免高频场景下 shift() 的 O(n) 复杂度
    this.bufferHead = 0; // 写入位置
    this.bufferCount = 0; // 当前日志数量
    this.circularBuffer = new Array(this.maxBufferSize); // 预分配固定大小数组
  }

  /**
   * 启动日志缓存池
   */
  start() {
    this.isEnabled = true;
    this.startTime = Date.now();
    this.lastActivityTime = Date.now();
    this.logBuffer = [];

    // 启动无操作检测定时器
    this.inactivityCheckInterval = setInterval(() => {
      const now = Date.now();
      if (now - this.lastActivityTime > this.inactivityTimeout) {
        this.stop();
        console.log('监控进程因5分钟无操作自动停止');
      }
    }, 60000); // 每分钟检查一次

    console.log('日志缓存池已启动');
  }

  /**
   * 停止日志缓存池
   */
  stop() {
    this.isEnabled = false;
    this.startTime = null;

    // 清除无操作检测定时器
    if (this.inactivityCheckInterval) {
      clearInterval(this.inactivityCheckInterval);
      this.inactivityCheckInterval = null;
    }

    console.log('日志缓存池已停止');
  }

  /**
   * 添加日志到缓存池
   * @param {string} level - 日志级别 (info, warn, error)
   * @param {string} message - 日志消息
   * @param {Object} data - 附加数据（可选）
   */
  log(level, message, data = null) {
    if (!this.isEnabled) {
      return;
    }

    // 更新最后活动时间
    this.lastActivityTime = Date.now();

    // 脱敏处理
    const sanitizedData = data ? this.sanitizeData(data) : null;

    const logEntry = {
      timestamp: new Date().toISOString(),
      level: level.toUpperCase(),
      message,
      ...(sanitizedData && { data: sanitizedData })
    };

    // P2修复：使用循环缓冲区，避免 O(n) 的 shift() 操作
    // 如果缓冲区满，覆盖最旧的日志（循环覆盖）
    if (this.bufferCount < this.maxBufferSize) {
      // 缓冲区未满，直接写入
      this.circularBuffer[(this.bufferHead + this.bufferCount) % this.maxBufferSize] = logEntry;
      this.bufferCount++;
    } else {
      // 缓冲区已满，覆盖最旧的日志
      this.circularBuffer[this.bufferHead] = logEntry;
      this.bufferHead = (this.bufferHead + 1) % this.maxBufferSize;
    }

    // 兼容性：同时更新 logBuffer（保留旧代码，逐步迁移）
    this.logBuffer = this.getLogs();
  }

  /**
   * 脱敏处理数据
   * @param {Object} data - 原始数据
   * @returns {Object} 脱敏后的数据
   */
  sanitizeData(data) {
    const sanitized = { ...data };

    // 钱包地址脱敏：只显示前 4 位和后 4 位
    if (sanitized.wallet) {
      sanitized.wallet = this.formatAddress(sanitized.wallet);
    }
    if (sanitized.from || sanitized.fromAddress) {
      const addr = sanitized.from || sanitized.fromAddress;
      sanitized.from = this.formatAddress(addr);
      if (sanitized.fromAddress) {
        sanitized.fromAddress = this.formatAddress(sanitized.fromAddress);
      }
    }
    if (sanitized.to || sanitized.toAddress) {
      const addr = sanitized.to || sanitized.toAddress;
      sanitized.to = this.formatAddress(addr);
      if (sanitized.toAddress) {
        sanitized.toAddress = this.formatAddress(sanitized.toAddress);
      }
    }

    // 交易哈希可以保留（公开信息）

    // 错误信息只保留 message，不保留 stack
    if (sanitized.error && typeof sanitized.error === 'object') {
      sanitized.error = sanitized.error.message || String(sanitized.error);
    }

    return sanitized;
  }

  /**
   * 格式化地址（脱敏）
   * @param {string} address - 完整地址
   * @returns {string} 脱敏后的地址
   */
  formatAddress(address) {
    if (!address || address.length < 8) return address;
    return `${address.slice(0, 4)}...${address.slice(-4)}`;
  }

  /**
   * 获取所有缓存的日志
   * @returns {Array} 日志数组
   */
  getLogs() {
    // P2修复：从循环缓冲区读取日志
    const logs = [];
    for (let i = 0; i < this.bufferCount; i++) {
      const index = (this.bufferHead + i) % this.maxBufferSize;
      logs.push(this.circularBuffer[index]);
    }
    return logs;
  }

  /**
   * 获取最新的 N 条日志
   * @param {number} count - 日志数量
   * @returns {Array} 日志数组
   */
  getLatestLogs(count = 100) {
    // P2修复：从循环缓冲区读取最新的 N 条日志
    const logs = this.getLogs();
    const startIndex = Math.max(0, logs.length - count);
    return logs.slice(startIndex);
  }

  /**
   * 清空日志缓存池
   */
  clearLogs() {
    // P2修复：清空循环缓冲区
    this.bufferHead = 0;
    this.bufferCount = 0;
    this.logBuffer = [];
    this.lastActivityTime = Date.now();
    console.log('日志缓存池已清空');
  }

  /**
   * 刷新日志（从最新一条开始）
   */
  refreshLogs() {
    this.lastActivityTime = Date.now();
    return this.getLogs();
  }

  /**
   * 获取工作时长（秒）
   * @returns {number} 工作时长
   */
  getDuration() {
    if (!this.startTime) {
      return 0;
    }
    return Math.floor((Date.now() - this.startTime) / 1000);
  }

  /**
   * 检查是否启用
   * @returns {boolean} 是否启用
   */
  isActive() {
    return this.isEnabled;
  }

  /**
   * 获取缓存池状态
   * @returns {Object} 状态信息
   */
  getStatus() {
    return {
      isEnabled: this.isEnabled,
      startTime: this.startTime,
      duration: this.getDuration(),
      bufferLength: this.logBuffer.length,
      maxBufferSize: this.maxBufferSize,
      lastActivityTime: this.lastActivityTime
    };
  }

  /**
   * 便捷方法：info 级别日志
   */
  info(message, data = null) {
    this.log('info', message, data);
  }

  /**
   * 便捷方法：warn 级别日志
   */
  warn(message, data = null) {
    this.log('warn', message, data);
  }

  /**
   * 便捷方法：error 级别日志
   */
  error(message, data = null) {
    this.log('error', message, data);
  }
}

// 导出单例
module.exports = new Logger();
