/**
 * RPC 节点池工具
 * 提供多个 BSC RPC 节点的随机选择和重试机制
 *
 * 支持从环境变量 BSC_RPC_URLS 自定义节点池
 * 如未配置，则使用默认的高质量 RPC 节点
 *
 * RPC 节点排序说明（基于稳定性测试 2026-04-03）:
 * 1. bsc-dataseed3.defibit.io (100%成功率, 243ms)
 * 2. bsc-dataseed3.ninicoin.io (100%成功率, 253ms)
 * 3. bsc-dataseed2.defibit.io (100%成功率, 283ms)
 * 4. bsc-dataseed4.ninicoin.io (100%成功率, 303ms)
 * 5. bsc.drpc.org (100%成功率, 314ms)
 *
 * @updated 2026-04-03T10:00:00.000Z
 * @lifecycle 已部署
 */

class RPCPool {
  constructor() {
    // 从环境变量读取自定义 RPC 节点池
    const customRPCs = process.env.BSC_RPC_URLS
      ? process.env.BSC_RPC_URLS.split(',').map(url => url.trim()).filter(url => url.length > 0)
      : [];

    // 默认的高质量 BSC RPC 节点（基于稳定性测试排序）
    // 注：bsc-rpc.publicnode.com 是长期实践验证最稳定的节点，优先使用
    const defaultRPCs = [
      'https://bsc-dataseed3.defibit.io',  // 100%成功率, 平均243ms
      'https://bsc-dataseed3.ninicoin.io',  // 100%成功率, 平均253ms
      'https://bsc-dataseed2.defibit.io',  // 100%成功率, 平均283ms
      'https://bsc-dataseed4.ninicoin.io',  // 100%成功率, 平均303ms
      'https://bsc-rpc.publicnode.com'      // 2026-06起稳定性下降，降为末位备选
    ];

    // 使用自定义节点池（如果配置了）或默认节点池
    this.rpcList = customRPCs.length > 0 ? customRPCs : defaultRPCs;

    console.log(`[RPCPool] 初始化 RPC 节点池，节点数量: ${this.rpcList.length}`);
    if (customRPCs.length > 0) {
      console.log('[RPCPool] 使用自定义 RPC 节点池');
    } else {
      console.log('[RPCPool] 使用默认 RPC 节点池');
    }
  }

  /**
   * 随机获取一个 RPC 节点 URL
   * @returns {string} RPC 节点 URL
   */
  getRandomRPC() {
    const randomIndex = Math.floor(Math.random() * this.rpcList.length);
    return this.rpcList[randomIndex];
  }

  /**
   * 使用 RPC 节点执行调用（带重试）
   * @param {Function} callFn - 调用函数，接收 RPC URL 作为参数
   * @param {number} maxRetries - 最大重试次数，默认为 RPC 节点数量
   * @param {number} timeout - 超时时间（毫秒），默认 7 秒
   * @returns {Promise<any>} 调用结果
   * @throws {Error} 所有重试失败后抛出错误
   */
  async callWithRetry(callFn, maxRetries = this.rpcList.length, timeout = 7000) {
    const errors = [];

    for (let i = 0; i < maxRetries; i++) {
      try {
        const rpcUrl = this.getRandomRPC();

        // 添加超时控制（7秒）
        const resultPromise = callFn(rpcUrl);
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error(`RPC timeout after ${timeout}ms`)), timeout)
        );

        const result = await Promise.race([resultPromise, timeoutPromise]);
        return result;
      } catch (error) {
        errors.push({
          rpcUrl: this.getRandomRPC(),
          error: error.message
        });
        // timeout 直接换下一个 RPC
        continue;
      }
    }

    // 所有重试都失败
    throw new Error(`RPC 调用失败，已尝试 ${maxRetries} 次。错误信息: ${JSON.stringify(errors)}`);
  }

  /**
   * 获取所有 RPC 节点列表
   * @returns {string[]} RPC 节点列表
   */
  getAllRPCs() {
    return [...this.rpcList];
  }

  /**
   * 添加自定义 RPC 节点
   * @param {string} rpcUrl - RPC 节点 URL
   */
  addRPC(rpcUrl) {
    if (rpcUrl && !this.rpcList.includes(rpcUrl)) {
      this.rpcList.push(rpcUrl);
    }
  }

  /**
   * 删除指定的 RPC 节点
   * @param {string} rpcUrl - 要删除的 RPC 节点 URL
   */
  removeRPC(rpcUrl) {
    const index = this.rpcList.indexOf(rpcUrl);
    if (index > -1) {
      this.rpcList.splice(index, 1);
    }
  }
}

// 导出单例
module.exports = new RPCPool();
