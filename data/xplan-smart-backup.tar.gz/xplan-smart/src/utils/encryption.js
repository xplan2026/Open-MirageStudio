/**
 * 加密/解密工具
 * 使用 AES-256-CBC 算法加密敏感信息（如私钥）
 * @updated 2026-04-03T20:20:00.000Z
 * @lifecycle 已部署
 */

const crypto = require('crypto');

class Encryption {
  constructor() {
    // 从环境变量获取加密密钥（延迟验证）
    this.algorithm = 'aes-256-cbc';
    this.key = process.env.ENCRYPTION_KEY;
    this.keyBuffer = null;
    this._initialized = false;
  }

  /**
   * 初始化密钥（延迟初始化，确保 dotenv 已加载）
   * @private
   */
  _initialize() {
    if (this._initialized) {
      return;
    }

    if (!this.key) {
      throw new Error('未设置 ENCRYPTION_KEY 环境变量');
    }

    // 密钥必须是 32 字节
    if (this.key.length !== 64) {
      throw new Error('ENCRYPTION_KEY 必须是 32 字节的十六进制字符串（64 个字符）');
    }

    // 将十六进制字符串转换为 Buffer
    this.keyBuffer = Buffer.from(this.key, 'hex');

    this._initialized = true;
  }

  /**
   * 确保密钥已初始化
   * @private
   */
  _ensureInitialized() {
    if (!this._initialized) {
      this._initialize();
    }
  }

  /**
   * 加密文本
   * @param {string} text - 要加密的文本
   * @returns {Object} 加密结果，包含 iv 和 encryptedData
   */
  encrypt(text) {
    this._ensureInitialized();

    if (!text) {
      throw new Error('加密内容不能为空');
    }

    // 生成随机初始化向量
    const iv = crypto.randomBytes(16);

    // 创建加密器
    const cipher = crypto.createCipheriv(this.algorithm, this.keyBuffer, iv);

    // 加密数据
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');

    // 返回 iv 和加密数据
    return {
      iv: iv.toString('hex'),
      encryptedData: encrypted
    };
  }

  /**
   * 解密文本
   * @param {Object} encryptedData - 加密数据对象，包含 iv 和 encryptedData
   * @returns {string} 解密后的文本
   */
  decrypt(encryptedData) {
    this._ensureInitialized();

    if (!encryptedData || !encryptedData.iv || !encryptedData.encryptedData) {
      throw new Error('加密数据格式不正确');
    }

    // 将 iv 和加密数据转换为 Buffer
    const iv = Buffer.from(encryptedData.iv, 'hex');
    const encrypted = encryptedData.encryptedData;

    // 创建解密器
    const decipher = crypto.createDecipheriv(this.algorithm, this.keyBuffer, iv);

    // 解密数据
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');

    return decrypted;
  }

  /**
   * 加密私钥
   * @param {string} privateKey - 私钥
   * @returns {string} 加密后的私钥（Base64 编码）
   */
  encryptPrivateKey(privateKey) {
    this._ensureInitialized();

    if (!privateKey || !privateKey.startsWith('0x')) {
      throw new Error('私钥格式不正确');
    }

    const encrypted = this.encrypt(privateKey);
    // 将加密对象转换为 JSON 字符串，然后 Base64 编码
    return Buffer.from(JSON.stringify(encrypted)).toString('base64');
  }

  /**
   * 解密私钥
   * @param {string} encryptedPrivateKey - 加密后的私钥（Base64 编码）
   * @returns {string} 解密后的私钥
   */
  decryptPrivateKey(encryptedPrivateKey) {
    this._ensureInitialized();

    if (!encryptedPrivateKey) {
      throw new Error('加密的私钥不能为空');
    }

    try {
      // Base64 解码
      const jsonStr = Buffer.from(encryptedPrivateKey, 'base64').toString('utf8');
      const encryptedData = JSON.parse(jsonStr);

      // 解密
      return this.decrypt(encryptedData);
    } catch (error) {
      throw new Error(`私钥解密失败: ${error.message}`);
    }
  }

  /**
   * 验证加密密钥是否正确
   * @param {string} testData - 测试数据
   * @returns {boolean} 是否验证成功
   */
  validateKey(testData = 'test') {
    try {
      // 直接使用已初始化的 keyBuffer，不通过 _ensureInitialized
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv(this.algorithm, this.keyBuffer, iv);
      let encrypted = cipher.update(testData, 'utf8', 'hex');
      encrypted += cipher.final('hex');

      const decipher = crypto.createDecipheriv(this.algorithm, this.keyBuffer, iv);
      let decrypted = decipher.update(encrypted, 'hex', 'utf8');
      decrypted += decipher.final('utf8');

      return decrypted === testData;
    } catch (error) {
      return false;
    }
  }
}

// 导出类，让调用者在需要时才实例化
module.exports = Encryption;
