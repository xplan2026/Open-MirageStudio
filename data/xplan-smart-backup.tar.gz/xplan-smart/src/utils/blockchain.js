/**
 * 区块链操作工具
 * 使用 ethers.js v5 进行 BSC 链操作
 * @updated 2026-04-03T20:20:00.000Z
 * @lifecycle 已部署
 */

const { ethers } = require('ethers');
const rpcPool = require('./rpc-pool');

class Blockchain {
  constructor() {
    // ERC20 代币 ABI（仅包含需要的函数）
    this.erc20ABI = [
      'function balanceOf(address) view returns (uint256)',
      'function transfer(address to, uint256 amount) returns (bool)',
      'function decimals() view returns (uint8)',
      'function symbol() view returns (string)',
      'function name() view returns (string)'
    ];

    // BSC 主网配置
    this.chainId = 56; // BSC 主网 Chain ID

    // 默认配置
    this.gasMultiplier = parseFloat(process.env.MONITOR_GAS_PRICE_MULTIPLIER) || 1.1;
    this.maxRetries = parseInt(process.env.MONITOR_MAX_RETRIES) || 3;

    // 代币地址配置
    this.tokenAddresses = {
      USDT: process.env.USDT_ADDRESS,
      WKEYDAO: process.env.WKEYDAO_ADDRESSES
    };

    // P1修复：本地 nonce 管理，防止快速连续转账时 nonce 冲突
    // nonceMap: key=钱包地址, value=当前 nonce
    this.nonceMap = new Map();
    this.nonceLockMap = new Map(); // 防止并发修改 nonce

    // 延迟加载加密密钥（避免 env-loader 未加载时出错）
    this.encryption = null;
  }

  /**
   * 获取 Encryption 实例（延迟加载）
   * @returns {Encryption} Encryption 实例
   */
  _getEncryption() {
    if (!this.encryption) {
      const Encryption = require('./encryption');
      this.encryption = new Encryption();
    }
    return this.encryption;
  }

  /**
   * 获取 Provider
   * @param {string} rpcUrl - RPC URL（可选）
   * @returns {ethers.JsonRpcProvider} Provider 实例
   */
  async getProvider(rpcUrl = null) {
    if (!rpcUrl) {
      rpcUrl = rpcPool.getRandomRPC();
    }
    // ethers.js v5 使用 JsonRpcProvider
    return new ethers.providers.JsonRpcProvider(rpcUrl, this.chainId);
  }

  /**
   * 获取 Wallet
   * @param {string} privateKey - 私钥
   * @param {string} rpcUrl - RPC URL（可选）
   * @returns {ethers.Wallet} Wallet 实例
   */
  async getWallet(privateKey, rpcUrl = null) {
    const provider = await this.getProvider(rpcUrl);
    return new ethers.Wallet(privateKey, provider);
  }

  /**
   * 查询 BNB 余额
   * @param {string} address - 钱包地址
   * @returns {Promise<string>} 余额（wei 格式）
   */
  async getBNBBalance(address) {
    return await rpcPool.callWithRetry(async (rpcUrl) => {
      const provider = await this.getProvider(rpcUrl);
      const balance = await provider.getBalance(address);
      return balance.toString();
    });
  }

  /**
   * 查询 ERC20 代币余额
   * @param {string} address - 钱包地址
   * @param {string} tokenAddress - 代币合约地址
   * @returns {Promise<string>} 余额（wei 格式）
   */
  async getTokenBalance(address, tokenAddress) {
    return await rpcPool.callWithRetry(async (rpcUrl) => {
      const provider = await this.getProvider(rpcUrl);
      const contract = new ethers.Contract(tokenAddress, this.erc20ABI, provider);
      const balance = await contract.balanceOf(address);
      return balance.toString();
    });
  }

  /**
   * 获取代币信息
   * @param {string} tokenAddress - 代币合约地址
   * @returns {Promise<Object>} 代币信息（name, symbol, decimals）
   */
  async getTokenInfo(tokenAddress) {
    return await rpcPool.callWithRetry(async (rpcUrl) => {
      const provider = await this.getProvider(rpcUrl);
      const contract = new ethers.Contract(tokenAddress, this.erc20ABI, provider);

      const [name, symbol, decimals] = await Promise.all([
        contract.name().catch(() => 'Unknown'),
        contract.symbol().catch(() => 'UNKNOWN'),
        contract.decimals().catch(() => 18)
      ]);

      return { name, symbol, decimals };
    });
  }

  /**
   * 估算 Gas 价格
   * @returns {Promise<bigint>} Gas 价格（wei）
   */
  async getGasPrice() {
    return await rpcPool.callWithRetry(async (rpcUrl) => {
      const provider = await this.getProvider(rpcUrl);
      const feeData = await provider.getFeeData();
      const gasPrice = feeData.gasPrice;
      return BigInt(Math.floor(Number(gasPrice) * this.gasMultiplier));
    });
  }

  /**
   * 发送 BNB
   * @param {string} privateKey - 发送方私钥
   * @param {string} toAddress - 接收方地址
   * @param {string} amount - 金额（wei 格式）
   * @param {Object} options - 选项（可选）
   * @returns {Promise<string>} 交易哈希
   */
  async sendBNB(privateKey, toAddress, amount, options = {}) {
    const wallet = await this.getWallet(privateKey);
    const provider = wallet.provider;
    const gasPrice = await this.getGasPrice();
    
    // P1修复：手动管理 nonce，防止快速连续转账时使用相同的 nonce
    const currentNonce = await provider.getTransactionCount(wallet.address, 'pending');
    
    const tx = await wallet.sendTransaction({
      to: toAddress,
      value: amount,
      gasPrice,
      gasLimit: options.gasLimit || 21000,
      nonce: options.nonce || currentNonce // 使用传入的 nonce 或当前 nonce
    });

    return tx.hash;
  }

  /**
   * 发送 ERC20 代币
   * @param {string} privateKey - 发送方私钥
   * @param {string} tokenAddress - 代币合约地址
   * @param {string} toAddress - 接收方地址
   * @param {string} amount - 金额（wei 格式）
   * @param {Object} options - 选项（可选）
   * @returns {Promise<string>} 交易哈希
   */
  async sendToken(privateKey, tokenAddress, toAddress, amount, options = {}) {
    const wallet = await this.getWallet(privateKey);
    const contract = new ethers.Contract(tokenAddress, this.erc20ABI, wallet);
    const gasPrice = await this.getGasPrice();

    // P1修复：动态估算 gas limit
    let gasLimit = options.gasLimit;
    if (!gasLimit) {
      try {
        const estimatedGas = await contract.transfer.estimateGas(toAddress, amount);
        gasLimit = estimatedGas * BigInt(120) / BigInt(100); // 增加 20% 缓冲
      } catch (error) {
        gasLimit = 60000; // 估算失败时使用默认值
      }
    }

    const tx = await contract.transfer(toAddress, amount, {
      gasPrice,
      gasLimit
    });

    return tx.hash;
  }

  /**
   * 等待交易确认
   * @param {string} txHash - 交易哈希
   * @param {number} confirmations - 确认数（默认 1）
   * @param {number} timeout - 超时时间（毫秒），默认 90 秒
   * @returns {Promise<Object>} 交易收据
   */
  async waitForTransaction(txHash, confirmations = 1, timeout = 90000) {
    return await rpcPool.callWithRetry(async (rpcUrl) => {
      const provider = await this.getProvider(rpcUrl);

      // 添加超时控制（90秒）
      const receiptPromise = provider.waitForTransaction(txHash, confirmations);
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Transaction timeout after ${timeout}ms`)), timeout)
      );

      return await Promise.race([receiptPromise, timeoutPromise]);
    });
  }

  /**
   * 补充 Gas 费
   * @param {string} fromPrivateKey - 发送方私钥（安全钱包）
   * @param {string} toAddress - 接收方地址（被保护钱包）
   * @param {string} amount - BNB 金额（wei 格式，默认 0.0005 BNB）
   * @returns {Promise<string>} 交易哈希
   */
  async refillGas(fromPrivateKey, toAddress, amount = '500000000000000') {
    // 默认 0.0005 BNB = 500000000000000 wei
    return await this.sendBNB(fromPrivateKey, toAddress, amount);
  }

  /**
   * 格式化余额（显示用）
   * @param {string} balanceWei - 余额（wei 格式）
   * @param {number} decimals - 小数位数（默认 18）
   * @param {number} precision - 精度（默认 6）
   * @returns {string} 格式化后的余额
   */
  formatBalance(balanceWei, decimals = 18, precision = 6) {
    const balance = Number(ethers.utils.formatUnits(balanceWei, decimals));
    return balance.toFixed(precision);
  }

  /**
   * 解析金额为 wei
   * @param {string|number} amount - 金额
   * @param {number} decimals - 小数位数（默认 18）
   * @returns {string} wei 格式的金额
   */
  parseAmount(amount, decimals = 18) {
    return ethers.utils.parseUnits(String(amount), decimals).toString();
  }
}

// 导出单例
module.exports = new Blockchain();
