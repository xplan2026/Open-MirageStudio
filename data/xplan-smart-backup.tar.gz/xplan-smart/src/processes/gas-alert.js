/**
 * Gas Alert Process
 * 独立扩展，实现两个独立的报警逻辑：
 * 1. 定时检查安全钱包 BNB 余额（每天 12:00）
 * 2. 监听 Gas 补充失败（失败 3 次触发警报）
 * PM2 独立启动进程
 * @updated 2026-04-03T20:20:00.000Z
 * @lifecycle 已部署
 */

// 加载环境变量
require('../config/env-loader');

const GasAlert = require('../core/GasAlert');
const logger = require('../utils/logger');

// 创建 Gas Alert 实例（单例模式）
const gasAlert = GasAlert;

// 启动 Gas Alert
try {
  gasAlert.start().then(result => {
    logger.info('Gas Alert 启动成功', result);
    console.log('Gas Alert 启动成功,保持进程运行...');
  }).catch(error => {
    logger.error('Gas Alert 启动失败', {
      error: error.message,
      stack: error.stack
    });
    console.error('Gas Alert 启动失败:', error);
    process.exit(1);
  });
} catch (error) {
  console.error('Gas Alert 启动时发生同步错误:', error);
  process.exit(1);
}

// 保持进程运行
setInterval(() => {
  // 空定时器，仅用于保持进程运行
}, 60000); // 每分钟执行一次

// 监听退出信号
process.on('SIGINT', async () => {
  logger.info('Gas Alert 收到停止信号...');
  await gasAlert.stop();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  logger.info('Gas Alert 收到终止信号...');
  await gasAlert.stop();
  process.exit(0);
});

// 全局错误处理
process.on('unhandledRejection', (reason) => {
  logger.error('Gas Alert 未处理的 Promise rejection', {
    reason: reason?.message || reason
  });
});

process.on('uncaughtException', (error) => {
  logger.error('Gas Alert 未捕获的异常', {
    error: error.message,
    stack: error.stack
  });
});
