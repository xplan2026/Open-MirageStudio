/**
 * BScanner Process - 监控被保护钱包的 BNB 余额
 * 当余额超过阈值（固定为 0.0006 BNB）时触发转账到安全钱包
 * @updated 2026-04-03T20:20:00.000Z
 * @lifecycle 已部署
 */

// 加载环境变量
require('../config/env-loader');

const BScanner = require('../core/BScanner');
const logger = require('../utils/logger');

// P1修复：直接使用 env-loader 单例
const env = require('../config/env-loader');
const PROTECTED_WALLETS = env.getArray('PROTECTED_WALLETS');

if (!PROTECTED_WALLETS || PROTECTED_WALLETS.length === 0) {
  throw new Error('环境变量 PROTECTED_WALLETS 未配置或为空');
}

console.log(`BScanner 启动中... 监控 ${PROTECTED_WALLETS.length} 个被保护钱包`);

// 创建多个 BScanner 实例
const scanners = [];

for (const wallet of PROTECTED_WALLETS) {
  const bscanner = new BScanner(
    wallet,
    `PROTECTED_WALLET_${wallet.replace('0x', '').toUpperCase()}_ENCRYPTED_PRIVATE_KEY`
  );
  scanners.push({
    wallet,
    scanner: bscanner
  });
}

// 优雅退出处理
async function gracefulShutdown() {
  console.log('\nBScanner 收到停止信号，正在关闭...');
  await Promise.all(scanners.map(s => s.scanner.stop()));
  console.log('BScanner 已停止');
  process.exit(0);
}

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);

// 启动所有 BScanner
const startPromises = scanners.map(({ wallet, scanner }) => {
  console.log(`启动 BScanner for wallet: ${wallet}`);
  return scanner.start()
    .then(() => {
      console.log(`BScanner 启动成功 (${wallet})`);
      return wallet;
    })
    .catch(error => {
      console.error(`BScanner 启动失败 (${wallet}):`, error);
      logger.error('BScanner 启动失败', {
        error: error.message,
        wallet
      });
      throw error;
    });
});

Promise.all(startPromises)
  .then(() => {
    console.log(`所有 BScanner 启动成功，共监控 ${PROTECTED_WALLETS.length} 个钱包`);
    
    // 保持进程运行（永不解析的 Promise）
    console.log('BScanner 主进程保持运行...');
    return new Promise(() => {});
  })
  .catch(error => {
    console.error('部分或全部 BScanner 启动失败:', error);
    process.exit(1);
  });

// 全局错误处理
process.on('unhandledRejection', (reason, promise) => {
  console.error('BScanner 未处理的 Promise rejection:', reason);
  logger.error('BScanner 未处理的 Promise rejection', {
    reason: reason?.message || reason,
    wallets: PROTECTED_WALLETS
  });
});

process.on('uncaughtException', (error) => {
  console.error('BScanner 未捕获的异常:', error);
  logger.error('BScanner 未捕获的异常', {
    error: error.message,
    stack: error.stack,
    wallets: PROTECTED_WALLETS
  });
  process.exit(1);
});
