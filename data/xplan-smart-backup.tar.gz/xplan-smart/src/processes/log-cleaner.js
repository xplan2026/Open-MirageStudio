/**
 * Log Cleaner Process
 * 定期清理过期的交易记录、通知历史、报警记录和日志文件
 * PM2 独立启动进程
 * @updated 2026-03-25T14:30:00.000Z
 * @lifecycle 已部署
 */

// 加载环境变量
require('../config/env-loader');

const LogCleaner = require('../core/LogCleaner');
const logger = require('../utils/logger');

// 创建 Log Cleaner 实例
const logCleaner = new LogCleaner();

// 启动 Log Cleaner
logCleaner.start();

// 监听退出信号
process.on('SIGINT', async () => {
  logger.info('Log Cleaner 收到停止信号...');
  process.exit(0);
});

process.on('SIGTERM', async () => {
  logger.info('Log Cleaner 收到终止信号...');
  process.exit(0);
});

// 全局错误处理
process.on('unhandledRejection', (reason) => {
  logger.error('Log Cleaner 未处理的 Promise rejection', {
    reason: reason?.message || reason
  });
});

process.on('uncaughtException', (error) => {
  logger.error('Log Cleaner 未捕获的异常', {
    error: error.message,
    stack: error.stack
  });
});
