/**
 * Scanner Process - Wallet 0x886b739ba73c1ccae826cb11c8d28e4750c68a89
 * PM2 独立启动进程
 * @updated 2026-03-28T19:30:00.000Z
 * @lifecycle 已部署
 */

// 加载环境变量
require('../config/env-loader');

const Scanner = require('../core/Scanner');
const logger = require('../utils/logger');

const WALLET_ADDRESS = '0x886b739ba73c1ccae826cb11c8d28e4750c68a89';
const WALLET_ADDRESS_UPPER = WALLET_ADDRESS.replace('0x', '').toUpperCase();

// 创建 Scanner 实例
const scanner = new Scanner(
  WALLET_ADDRESS,
  `PROTECTED_WALLET_${WALLET_ADDRESS_UPPER}_ENCRYPTED_PRIVATE_KEY`
);

// 启动 Scanner
scanner.start().catch(error => {
  logger.error('Scanner 启动失败', {
    wallet: WALLET_ADDRESS,
    error: error.message
  });
  process.exit(1);
});

// 监听退出信号
process.on('SIGINT', async () => {
  logger.info(`Scanner [${WALLET_ADDRESS}] 收到停止信号...`);
  await scanner.stop();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  logger.info(`Scanner [${WALLET_ADDRESS}] 收到终止信号...`);
  await scanner.stop();
  process.exit(0);
});

// 全局错误处理
process.on('unhandledRejection', (reason) => {
  logger.error(`Scanner [${WALLET_ADDRESS}] 未处理的 Promise rejection`, {
    reason: reason?.message || reason
  });
});

process.on('uncaughtException', (error) => {
  logger.error(`Scanner [${WALLET_ADDRESS}] 未捕获的异常`, {
    error: error.message,
    stack: error.stack
  });
});
