/**
 * 日志清理脚本
 * 定期清理过期的交易记录、通知历史、报警记录和日志文件
 * @updated 2026-03-27T00:00:00.000Z
 * @lifecycle 已部署
 */

const path = require('path');
const fs = require('fs').promises;
const logger = require('../utils/logger');
const jsonStorage = require('../storage/json-storage');

class LogCleaner {
  constructor() {
    this.config = {
      // 日志保留天数
      retentionDays: {
        transactions: parseInt(process.env.LOG_RETENTION_TRANSACTIONS) || 90,        // 交易记录: 90 天
        notifications: parseInt(process.env.LOG_RETENTION_NOTIFICATIONS) || 30,         // 通知历史: 30 天
        alerts: parseInt(process.env.LOG_RETENTION_ALERTS) || 90,                     // 报警记录: 90 天
        logs: parseInt(process.env.LOG_RETENTION_LOGS) || 7,                         // 日志文件: 7 天
      },

      // 归档配置
      archive: {
        enabled: process.env.LOG_ARCHIVE_ENABLED === 'true' || true,
        maxSize: parseInt(process.env.LOG_ARCHIVE_MAX_SIZE) || (10 * 1024 * 1024), // 10 MB
      },

      // 清理时间 (每天 3:00)
      cleanupHour: parseInt(process.env.LOG_CLEANUP_HOUR) || 3
    };
  }

  /**
   * 启动日志清理器
   */
  start() {
    this.scheduleCleanup();
    logger.info('日志清理器已启动', {
      cleanupHour: this.config.cleanupHour,
      retentionDays: this.config.retentionDays
    });
  }

  /**
   * 安排定时清理
   */
  scheduleCleanup() {
    const now = new Date();
    const nextCleanup = new Date();

    nextCleanup.setHours(this.config.cleanupHour, 0, 0, 0);
    if (nextCleanup <= now) {
      nextCleanup.setDate(nextCleanup.getDate() + 1);
    }

    const delay = nextCleanup.getTime() - now.getTime();
    logger.info(`下一次日志清理: ${nextCleanup.toISOString()}`);

    setTimeout(async () => {
      await this.performCleanup();
      this.scheduleCleanup();
    }, delay);
  }

  /**
   * 执行清理
   */
  async performCleanup() {
    logger.info('开始执行日志清理...');

    try {
      // 清理交易记录
      await this.cleanTransactions();

      // 清理通知历史
      await this.cleanNotifications();

      // 清理报警记录
      await this.cleanAlerts();

      // 清理日志文件
      await this.cleanLogFiles();

      // 清理归档
      if (this.config.archive.enabled) {
        await this.cleanArchives();
      }

      logger.info('日志清理完成');

    } catch (error) {
      logger.error(`日志清理失败: ${error.message}`, { error });
    }
  }

  /**
   * 清理交易记录
   */
  async cleanTransactions() {
    try {
      const transactions = await jsonStorage.getAllTransactions();
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - this.config.retentionDays.transactions);

      const filtered = transactions.filter(tx => {
        const txDate = new Date(tx.createdAt || tx.timestamp);
        return txDate > cutoffDate;
      });

      if (transactions.length !== filtered.length) {
        // 保存过滤后的记录
        const fs = require('fs').promises;
        const transactionFile = process.env.TRANSACTION_JSON_FILE || './cache/transactions.json';
        await fs.writeFile(transactionFile, JSON.stringify(filtered, null, 2), 'utf8');

        logger.info(`清理交易记录: ${transactions.length - filtered.length} 条`);
      }
    } catch (error) {
      logger.error(`清理交易记录失败: ${error.message}`);
    }
  }

  /**
   * 清理通知历史
   */
  async cleanNotifications() {
    try {
      const history = await jsonStorage.getNotificationHistory();
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - this.config.retentionDays.notifications);

      const filtered = history.filter(notif => {
        const notifDate = new Date(notif.sentAt || notif.createdAt);
        return notifDate > cutoffDate;
      });

      if (history.length !== filtered.length) {
        const fs = require('fs').promises;
        await fs.writeFile('./cache/telegram-history.json', JSON.stringify(filtered, null, 2), 'utf8');

        logger.info(`清理通知历史: ${history.length - filtered.length} 条`);
      }
    } catch (error) {
      logger.error(`清理通知历史失败: ${error.message}`);
    }
  }

  /**
   * 清理报警记录
   */
  async cleanAlerts() {
    try {
      const alerts = await jsonStorage.getGasAlerts();
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - this.config.retentionDays.alerts);

      let cleanedCount = 0;
      for (const [key, alert] of Object.entries(alerts)) {
        const alertDate = new Date(alert.timestamp);
        if (alertDate <= cutoffDate) {
          delete alerts[key];
          cleanedCount++;
        }
      }

      if (cleanedCount > 0) {
        await jsonStorage.saveGasAlerts(alerts);
        logger.info(`清理报警记录: ${cleanedCount} 条`);
      }
    } catch (error) {
      logger.error(`清理报警记录失败: ${error.message}`);
    }
  }

  /**
   * 清理日志文件
   */
  async cleanLogFiles() {
    try {
      const logsDir = path.join(__dirname, '../logs');
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - this.config.retentionDays.logs);

      // 日志行数限制
      const maxLogLines = parseInt(process.env.MAX_LOG_LINES) || 1000;

      try {
        const files = await fs.readdir(logsDir);

        for (const file of files) {
          const filePath = path.join(logsDir, file);
          const stats = await fs.stat(filePath);
          const fileDate = stats.mtime;

          // 删除过期日志文件
          if (fileDate < cutoffDate && file.endsWith('.log')) {
            await fs.unlink(filePath);
            logger.info(`删除过期日志文件: ${file}`);
            continue;
          }

          // 截断过大的日志文件（保留最后 maxLogLines 行）
          if (file.endsWith('.log')) {
            await this.truncateLogFile(filePath, maxLogLines);
          }
        }
      } catch (error) {
        if (error.code !== 'ENOENT') {
          throw error;
        }
        // logs 目录不存在,忽略
      }
    } catch (error) {
      logger.error(`清理日志文件失败: ${error.message}`);
    }
  }

  /**
   * 截断日志文件，保留最后 N 行
   * @param {string} filePath - 日志文件路径
   * @param {number} maxLines - 最大行数
   */
  async truncateLogFile(filePath, maxLines) {
    try {
      const fs = require('fs');
      
      // 读取文件所有行
      const content = await fs.promises.readFile(filePath, 'utf8');
      const lines = content.split('\n');
      
      // 如果行数不超过限制，不需要截断
      if (lines.length <= maxLines) {
        return;
      }
      
      // 保留最后 maxLines 行
      const truncatedLines = lines.slice(-maxLines);
      const truncatedContent = truncatedLines.join('\n');
      
      // 写回文件
      await fs.promises.writeFile(filePath, truncatedContent, 'utf8');
      
      logger.info(`截断日志文件: ${path.basename(filePath)} (${lines.length} -> ${truncatedLines.length} 行)`);
    } catch (error) {
      logger.error(`截断日志文件失败: ${filePath}`, { error: error.message });
    }
  }

  /**
   * 清理归档
   */
  async cleanArchives() {
    try {
      const archiveDir = path.join(__dirname, '../logs/archive');
      const maxSize = this.config.archive.maxSize;

      try {
        const files = await fs.readdir(archiveDir);
        let totalSize = 0;

        // 计算总大小
        for (const file of files) {
          const filePath = path.join(archiveDir, file);
          const stats = await fs.stat(filePath);
          totalSize += stats.size;
        }

        // 如果超过最大大小,删除最旧的文件
        if (totalSize > maxSize) {
          const fileStats = await Promise.all(
            files.map(async file => {
              const filePath = path.join(archiveDir, file);
              const stats = await fs.stat(filePath);
              return { file, mtime: stats.mtime, size: stats.size };
            })
          );

          fileStats.sort((a, b) => a.mtime - b.mtime);

          for (const { file, size } of fileStats) {
            const filePath = path.join(archiveDir, file);
            await fs.unlink(filePath);
            totalSize -= size;

            logger.info(`删除归档文件: ${file}`);

            if (totalSize <= maxSize) {
              break;
            }
          }
        }
      } catch (error) {
        if (error.code !== 'ENOENT') {
          throw error;
        }
        // archive 目录不存在,忽略
      }
    } catch (error) {
      logger.error(`清理归档失败: ${error.message}`);
    }
  }

  /**
   * 立即执行清理 (用于测试)
   */
  async cleanupNow() {
    logger.info('立即执行日志清理...');
    await this.performCleanup();
  }
}

// 如果作为主模块运行（直接通过 node 或 PM2 启动）
if (require.main === module) {
  const cleaner = new LogCleaner();

  // 启动日志清理器
  cleaner.start();

  // 监听退出信号
  process.on('SIGINT', async () => {
    console.log('收到停止信号...');
    process.exit(0);
  });

  process.on('SIGTERM', async () => {
    console.log('收到终止信号...');
    process.exit(0);
  });
}

module.exports = LogCleaner;
