/**
 * Scanner 模板（优化版）
 * 每 4 秒扫描一次被保护钱包的指定代币余额
 * 达到阈值时触发 transfer.js
 *
 * 使用方法：
 * 1. 复制此文件为 scanner<地址后4位>.js
 * 2. 修改 WALLET_ADDRESS 为被保护钱包地址
 * 3. 修改 WALLET_PRIVATE_KEY_ENV 为环境变量名
 *
 * 优化内容（v3.0.10）：
 * - 简化监控代币：只监控 wkeyDAO2
 * - 固定扫描间隔为 4 秒
 * - 移除停止/重启 API（通过 PM2 管理）
 * - P0修复：添加私钥格式验证
 * - P0修复：修复BNB余额阈值计算逻辑
 * - P1修复：删除重复的Promise错误处理
 * - P1修复：添加交易确认逻辑
 * - P2修复：使用传入的privateKeyEnvKey参数
 * @updated 2026-04-03T20:20:00.000Z
 * @lifecycle 已部署
 * @author alexiadai
 */

// 加载环境变量
require('../config/env-loader');

const blockchain = require('../utils/blockchain');
const logger = require('../utils/logger');
const constants = require('../config/constants');
const transfer = require('./Transfer');
const Encryption = require('../utils/encryption');

// 创建加密实例
const encryption = new Encryption();

class Scanner {
  constructor(walletAddress, privateKeyEnvKey) {
    this.walletAddress = walletAddress;
    this.privateKeyEnvKey = privateKeyEnvKey;
    this.isRunning = false;
    this.intervalId = null;
  }

  /**
   * 启动扫描
   */
  async start() {
    // P2修复：先检查是否已经在运行
    if (this.isRunning) {
      console.log(`Scanner [${this.walletAddress}] 已在运行`);
      return;
    }

    console.log(`Scanner [${this.walletAddress}] 启动中...`);

    // 强制清除旧的定时器
    if (this.intervalId) {
      clearTimeout(this.intervalId);
      this.intervalId = null;
    }

    this.isRunning = true;

    // 固定扫描间隔为 4 秒
    const scanInterval = 4000;

    // 立即执行一次扫描
    await this.scan();

    // 设置定时扫描（递归 setTimeout 确保扫描结束后再等待）
    this.scheduleNextScan(scanInterval);

    console.log(`Scanner [${this.walletAddress}] 已启动，扫描间隔: ${scanInterval}ms (4秒)`);
  }

  /**
   * 安排下一次扫描
   * @param {number} scanInterval - 扫描间隔（毫秒）
   */
  scheduleNextScan(scanInterval) {
    if (!this.isRunning) return;

    // 清除旧的定时器
    if (this.intervalId) {
      clearTimeout(this.intervalId);
    }

    this.intervalId = setTimeout(async () => {
      if (!this.isRunning) return;

      await this.scan();

      // 扫描结束后再次安排下一次扫描（使用固定间隔）
      this.scheduleNextScan(scanInterval);
    }, scanInterval);
  }

  /**
   * 停止扫描
   */
  async stop() {
    console.log(`Scanner [${this.walletAddress}] 停止中...`);
    this.isRunning = false;

    // 无论 isRunning 状态如何，都清除 intervalId
    if (this.intervalId) {
      clearTimeout(this.intervalId);
      this.intervalId = null;
    }

    console.log(`Scanner [${this.walletAddress}] 已停止`);
  }

  /**
   * 执行扫描
   */
  async scan() {
    try {
      // P2修复：使用传入的 privateKeyEnvKey 参数，而非动态计算
      const encryptedPrivateKey = process.env[this.privateKeyEnvKey];

      if (!encryptedPrivateKey) {
        console.error(`Scanner [${this.walletAddress}] 未在环境变量中找到加密私钥: ${this.privateKeyEnvKey}`);
        return;
      }

      // 解密私钥
      const privateKey = encryption.decryptPrivateKey(encryptedPrivateKey);
      if (!privateKey) {
        console.error(`Scanner [${this.walletAddress}] 私钥解密失败`);
        return;
      }

      // P0修复：验证私钥格式
      if (!privateKey.startsWith('0x') || privateKey.length !== 66) {
        throw new Error(`Scanner [${this.walletAddress}] 私钥格式无效: 长度应为66字符（含0x前缀），实际长度: ${privateKey.length}`);
      }

      // 只监控 wkeyDAO2（优化版）
      // 注释：wkeyDAO 已移除监控，仅保留 wkeyDAO2
      const tokenNames = ['WKEYDAO2'];
      // const tokenNames = ['WKEYDAO', 'WKEYDAO2'];

      // 扫描每个代币的余额
      for (const tokenName of tokenNames) {
        // 检查代币转账是否启用
        if (!constants.isTransferEnabled(tokenName)) {
          continue;
        }

        // 检查余额并触发转账
        await this.checkAndTransfer(tokenName, privateKey);
      }

    } catch (error) {
      console.error(`Scanner [${this.walletAddress}] 扫描失败: ${error.message}`);
      logger.error(`Scanner [${this.walletAddress}] 扫描失败`, {
        error: error.message
      });
    }
  }

  /**
   * 检查余额并触发转账
   * @param {string} tokenName - 代币名称
   * @param {string} privateKey - 发送方私钥
   */
  async checkAndTransfer(tokenName, privateKey) {
    try {
      let balance;

      // 获取余额
      if (tokenName === 'BNB') {
        balance = await blockchain.getBNBBalance(this.walletAddress);
      } else {
        const tokenAddress = constants.getTokenAddress(tokenName);
        balance = await blockchain.getTokenBalance(this.walletAddress, tokenAddress);
      }

      // 获取转账阈值
      const threshold = constants.getTransferThreshold(tokenName);

      // 计算实际可转账金额（BNB 需要扣除 gas 费）
      let transferAmount = balance;
      if (tokenName === 'BNB') {
        // 估算 gas 费（21,000 gas * gas price）
        const provider = await blockchain.getProvider();
        const feeData = await provider.getFeeData();
        const gasPrice = feeData.gasPrice;
        const estimatedGasCost = BigInt(constants.GAS_CONFIG.BNB_GAS_LIMIT) * BigInt(gasPrice);

        // 实际可转账金额 = 余额 - 估算的 gas 费
        const estimatedTransferAmount = BigInt(balance) - estimatedGasCost;

        // 如果估算的 gas 费大于余额，无法转账
        if (estimatedTransferAmount <= 0) {
          const formattedBalance = blockchain.formatBalance(balance);
          console.log(`Scanner [${this.walletAddress}] BNB 余额不足以支付 gas 费: ${formattedBalance}`);
          return;
        }

        // P0修复：额外扣除阈值缓冲，确保转账后余额不低于阈值
        transferAmount = (estimatedTransferAmount - BigInt(threshold)).toString();
      }

      // 比较余额和阈值
      if (BigInt(balance) > BigInt(threshold)) {
        console.log(`Scanner [${this.walletAddress}] ${tokenName} 余额超过阈值`, {
          balance,
          threshold,
          transferAmount: tokenName === 'BNB' ? transferAmount : balance
        });

        logger.info(`${tokenName} 余额超过阈值`, {
          wallet: this.walletAddress,
          token: tokenName,
          balance,
          threshold
        });

        // 触发转账（BNB 使用扣除 gas 后的金额）
        await this.triggerTransfer(tokenName, privateKey, transferAmount);

      } else {
        // 余额未超过阈值 - 不输出日志
      }

    } catch (error) {
      console.error(`Scanner [${this.walletAddress}] 检查 ${tokenName} 余额失败: ${error.message}`);
      logger.error(`检查 ${tokenName} 余额失败`, {
        wallet: this.walletAddress,
        token: tokenName,
        error: error.message
      });
    }
  }

  /**
   * 触发转账（异步执行）
   * @param {string} tokenName - 代币名称
   * @param {string} privateKey - 发送方私钥
   * @param {string} amount - 金额（wei 格式）
   */
  async triggerTransfer(tokenName, privateKey, amount) {
    try {
      // 从环境变量获取安全钱包地址
      const safeWalletAddress = process.env.SAFE_WALLET;
      if (!safeWalletAddress) {
        throw new Error('安全钱包地址未配置（环境变量 SAFE_WALLET）');
      }

      console.log(`Scanner [${this.walletAddress}] 触发 ${tokenName} 转账...`);

      // P1修复：异步执行转账并等待确认（不阻塞扫描循环）
      // 2026-06-21 修复：result.receipt 不存在，改为 result.success 判断
      transfer.executeTransfer({
        fromAddress: this.walletAddress,
        fromPrivateKey: privateKey,
        toAddress: safeWalletAddress,
        tokenName,
        amount
      }).then(result => {
        // 修正：executeTransfer 返回 { txHash, success, ... } 无 receipt 字段
        if (result && result.success && result.txHash) {
          console.log(`Scanner [${this.walletAddress}] 转账完成并已确认`, {
            txHash: result.txHash
          });
          logger.info(`${tokenName} 转账成功`, {
            wallet: this.walletAddress,
            token: tokenName,
            txHash: result.txHash
          });
        } else {
          throw new Error(`Scanner [${this.walletAddress}] 交易未确认或失败: ${result?.note || '未知原因'}`);
        }
      }).catch(error => {
        console.error(`Scanner [${this.walletAddress}] 转账失败: ${error.message}`);
        logger.error(`转账失败`, {
          wallet: this.walletAddress,
          token: tokenName,
          error: error.message
        });
      });

    } catch (error) {
      console.error(`Scanner [${this.walletAddress}] 触发转账失败: ${error.message}`);
      logger.error(`触发转账失败`, {
        wallet: this.walletAddress,
        token: tokenName,
        error: error.message
      });
    }
  }

  /**
   * 获取状态
   * @returns {Object} 状态信息
   */
  getStatus() {
    return {
      walletAddress: this.walletAddress,
      isRunning: this.isRunning,
      scanInterval: 4000 // 固定为 4 秒
    };
  }

  /**
   * 重启
   */
  async restart() {
    await this.stop();
    await this.start();
  }
}

// 导出类
module.exports = Scanner;
