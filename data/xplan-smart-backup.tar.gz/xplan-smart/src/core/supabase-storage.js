/**
 * Supabase 存储
 * 使用 Supabase 作为交易记录的云数据库存储
 * @updated 2026-03-27T00:00:00.000Z
 * @lifecycle 已部署
 */

const { createClient } = require('@supabase/supabase-js');
const Encryption = require('../utils/encryption');

class SupabaseStorage {
  constructor() {
    // 从环境变量获取配置
    this.supabaseUrl = process.env.SUPABASE_URL;
    this.transactionsTable = process.env.SUPABASE_TRANSACTIONS_TABLE || 'transactions';
    this.encryption = new Encryption();

    // 初始化 Supabase 客户端
    if (!this.supabaseUrl) {
      console.warn('未配置 Supabase URL，Supabase 存储功能将不可用');
      this.client = null;
      return;
    }

    // 获取 Supabase 匿名密钥（支持加密存储）
    const encryptedSupabaseKey = process.env.SUPABASE_ANON_KEY_ENCRYPTED || process.env.SUPABASE_ANON_KEY;

    if (!encryptedSupabaseKey) {
      console.warn('未配置 Supabase 匿名密钥，Supabase 存储功能将不可用');
      this.client = null;
      return;
    }

    // 尝试解密密钥（如果是加密格式）
    let supabaseKey;
    try {
      // Base64 解码
      const jsonStr = Buffer.from(encryptedSupabaseKey, 'base64').toString('utf8');
      const encryptedData = JSON.parse(jsonStr);
      // 解密
      supabaseKey = encryption.decrypt(encryptedData);
      console.log('Supabase 密钥解密成功');
    } catch (error) {
      // 如果解密失败，可能是明文格式，直接使用
      supabaseKey = encryptedSupabaseKey;
      console.log('Supabase 密钥使用明文格式（建议加密存储）');
    }

    this.supabaseKey = supabaseKey;
    this.client = createClient(this.supabaseUrl, this.supabaseKey);
  }

  /**
   * 检查是否可用
   * @returns {boolean} 是否可用
   */
  isAvailable() {
    return this.client !== null;
  }

  // ==================== 交易记录相关 ====================

  /**
   * 获取所有交易记录
   * @returns {Promise<Array>} 交易记录数组
   */
  async getAllTransactions() {
    if (!this.isAvailable()) return [];

    const { data, error } = await this.client
      .from(this.transactionsTable)
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('获取交易记录失败:', error);
      return [];
    }

    return this.transformTransactions(data);
  }

  /**
   * 添加交易记录
   * @param {Object} transaction - 交易记录
   * @returns {Promise<Object>} 添加的交易记录
   */
  async addTransaction(transaction) {
    if (!this.isAvailable()) return null;

    const newTransaction = {
      tx_hash: transaction.txHash,
      token_name: transaction.tokenName,
      amount: transaction.amount,
      from_address: transaction.from,
      to_address: transaction.to,
      gas_used: transaction.gasUsed || null,
      success: transaction.success,
      note: transaction.note || '',
      created_at: new Date().toISOString()
    };

    const { data, error } = await this.client
      .from(this.transactionsTable)
      .insert([newTransaction])
      .select()
      .single();

    if (error) {
      console.error('添加交易记录失败:', error);
      return null;
    }

    return this.transformTransaction(data);
  }

  /**
   * 按代币类型获取交易记录
   * @param {string} tokenName - 代币名称
   * @returns {Promise<Array>} 交易记录数组
   */
  async getTransactionsByToken(tokenName) {
    if (!this.isAvailable()) return [];

    const { data, error } = await this.client
      .from(this.transactionsTable)
      .select('*')
      .eq('token_name', tokenName)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('获取交易记录失败:', error);
      return [];
    }

    return this.transformTransactions(data);
  }

  /**
   * 按时间范围获取交易记录
   * @param {Date} startDate - 开始日期
   * @param {Date} endDate - 结束日期
   * @returns {Promise<Array>} 交易记录数组
   */
  async getTransactionsByDateRange(startDate, endDate) {
    if (!this.isAvailable()) return [];

    const { data, error } = await this.client
      .from(this.transactionsTable)
      .select('*')
      .gte('created_at', startDate.toISOString())
      .lte('created_at', endDate.toISOString())
      .order('created_at', { ascending: false });

    if (error) {
      console.error('获取交易记录失败:', error);
      return [];
    }

    return this.transformTransactions(data);
  }

  /**
   * 获取交易统计
   * @returns {Promise<Object>} 统计数据
   */
  async getTransactionStats() {
    if (!this.isAvailable()) {
      return this.getEmptyStats();
    }

    const { data, error } = await this.client
      .from(this.transactionsTable)
      .select('*');

    if (error) {
      console.error('获取交易统计失败:', error);
      return this.getEmptyStats();
    }

    const stats = this.getEmptyStats();
    stats.totalTransactions = data.length;

    data.forEach(tx => {
      // 按代币统计金额
      if (!stats.totalAmountByToken[tx.token_name]) {
        stats.totalAmountByToken[tx.token_name] = '0';
      }
      stats.totalAmountByToken[tx.token_name] = (
        BigInt(stats.totalAmountByToken[tx.token_name]) + BigInt(tx.amount)
      ).toString();

      // 统计成功/失败
      if (tx.success) {
        stats.successCount++;
      } else {
        stats.failedCount++;
      }

      // 统计 Gas 消耗
      if (tx.gas_used) {
        stats.totalGasUsed += parseInt(tx.gas_used);
      }
    });

    // 计算成功率
    stats.successRate = stats.totalTransactions > 0
      ? (stats.successCount / stats.totalTransactions * 100).toFixed(2)
      : '0.00';

    return stats;
  }

  /**
   * 获取空统计对象
   * @returns {Object} 空统计对象
   */
  getEmptyStats() {
    return {
      totalTransactions: 0,
      totalAmountByToken: {},
      successCount: 0,
      failedCount: 0,
      totalGasUsed: 0,
      successRate: '0.00'
    };
  }

  /**
   * 转换 Supabase 交易记录格式为内部格式
   * @param {Object} tx - Supabase 交易记录
   * @returns {Object} 转换后的交易记录
   */
  transformTransaction(tx) {
    return {
      id: tx.id,
      txHash: tx.tx_hash,
      tokenName: tx.token_name,
      amount: tx.amount,
      from: tx.from_address,
      to: tx.to_address,
      gasUsed: tx.gas_used,
      success: tx.success,
      note: tx.note,
      createdAt: tx.created_at
    };
  }

  /**
   * 批量转换交易记录
   * @param {Array} transactions - Supabase 交易记录数组
   * @returns {Array} 转换后的交易记录数组
   */
  transformTransactions(transactions) {
    return transactions.map(tx => this.transformTransaction(tx));
  }

  // ==================== 连接测试 ====================

  /**
   * 测试连接
   * @returns {Promise<boolean>} 是否连接成功
   */
  async testConnection() {
    if (!this.isAvailable()) return false;

    try {
      const { error } = await this.client
        .from(this.transactionsTable)
        .select('id')
        .limit(1);

      return !error;
    } catch (error) {
      console.error('Supabase 连接测试失败:', error);
      return false;
    }
  }
}

// 导出单例
module.exports = new SupabaseStorage();
