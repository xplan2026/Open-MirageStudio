/**
 * BScanner - 监控被保护钱包的 BNB 余额
 * 当余额超过阈值（固定为 0.0006 BNB）时触发转账到安全钱包
 * 注意：此扫描器不执行 Gas 补充逻辑
 * @updated 2026-04-03T20:20:00.000Z
 * @lifecycle 已部署
 */

// 加载环境变量
require('../config/env-loader');

const blockchain = require('../utils/blockchain');
const logger = require('../utils/logger');
const Encryption = require('../utils/encryption');
const encryption = new Encryption();

/**
 * BNB 转账阈值（固定为 0.0006 BNB）
 * 注意：这是常量，不从环境变量读取
 */
const BNB_TRANSFER_THRESHOLD = '600000000000000'; // 0.0006 BNB (wei 格式)

class BScanner {
  constructor(walletAddress, privateKeyEnvKey) {
    this.walletAddress = walletAddress;
    this.privateKeyEnvKey = privateKeyEnvKey;
    this.isRunning = false;
    this.intervalId = null;
  }

  /**
   * 启动扫描
   */
  async start() {
    // P2修复：先检查是否已经在运行
    if (this.isRunning) {
      console.log(`BScanner [${this.walletAddress}] 已在运行`);
      return;
    }

    console.log(`BScanner [${this.walletAddress}] 启动中...`);

    // P0修复：启动时验证私钥是否可用
    const encryptedPrivateKey = process.env[this.privateKeyEnvKey];
    if (!encryptedPrivateKey) {
      throw new Error(`BScanner [${this.walletAddress}] 未在环境变量中找到加密私钥: ${this.privateKeyEnvKey}`);
    }

    const privateKey = encryption.decryptPrivateKey(encryptedPrivateKey);
    if (!privateKey) {
      throw new Error(`BScanner [${this.walletAddress}] 私钥解密失败: ${this.privateKeyEnvKey}`);
    }

    // 强制清除旧的定时器
    if (this.intervalId) {
      clearTimeout(this.intervalId);
      this.intervalId = null;
    }

    this.isRunning = true;

    // 固定扫描间隔为 20 秒
    const scanInterval = 20000;

    // 立即执行一次扫描
    await this.scan();

    // 设置定时扫描（递归 setTimeout 确保扫描结束后再等待）
    this.scheduleNextScan(scanInterval);

    console.log(`BScanner [${this.walletAddress}] 已启动，扫描间隔: ${scanInterval}ms (20秒)`);
    console.log(`BScanner [${this.walletAddress}] BNB 转账阈值: ${blockchain.formatBalance(BNB_TRANSFER_THRESHOLD)} (0.006 BNB)`);
  }

  /**
   * 安排下一次扫描
   * @param {number} scanInterval - 扫描间隔（毫秒）
   */
  scheduleNextScan(scanInterval) {
    if (!this.isRunning) return;

    // 清除旧的定时器
    if (this.intervalId) {
      clearTimeout(this.intervalId);
    }

    this.intervalId = setTimeout(async () => {
      if (!this.isRunning) return;

      await this.scan();

      // 扫描结束后再次安排下一次扫描（使用固定间隔）
      this.scheduleNextScan(scanInterval);
    }, scanInterval);
  }

  /**
   * 停止扫描
   */
  async stop() {
    console.log(`BScanner [${this.walletAddress}] 停止中...`);
    this.isRunning = false;

    // 无论 isRunning 状态如何，都清除 intervalId
    if (this.intervalId) {
      clearTimeout(this.intervalId);
      this.intervalId = null;
    }

    console.log(`BScanner [${this.walletAddress}] 已停止`);
  }

  /**
   * 执行扫描
   */
  async scan() {
    try {
      // 从环境变量获取加密私钥（使用构造函数传入的 privateKeyEnvKey）
      const encryptedPrivateKey = process.env[this.privateKeyEnvKey];

      if (!encryptedPrivateKey) {
        console.error(`BScanner [${this.walletAddress}] 未在环境变量中找到加密私钥: ${this.privateKeyEnvKey}`);
        return;
      }

      // 解密私钥
      const privateKey = encryption.decryptPrivateKey(encryptedPrivateKey);
      if (!privateKey) {
        console.error(`BScanner [${this.walletAddress}] 私钥解密失败`);
        return;
      }

      // 检查 BNB 余额并触发转账
      await this.checkAndTransferBNB(privateKey);

    } catch (error) {
      console.error(`BScanner [${this.walletAddress}] 扫描失败: ${error.message}`);
      logger.error(`BScanner [${this.walletAddress}] 扫描失败`, {
        error: error.message
      });
    }
  }

  /**
   * 检查 BNB 余额并触发转账
   * 注意：不执行 Gas 补充逻辑
   * @param {string} privateKey - 发送方私钥
   */
  async checkAndTransferBNB(privateKey) {
    try {
      // 获取 BNB 余额
      const balance = await blockchain.getBNBBalance(this.walletAddress);

      // 估算 gas 费（21,000 gas * gas price）
      const provider = await blockchain.getProvider();
      const feeData = await provider.getFeeData();
      const gasPrice = feeData.gasPrice;
      const estimatedGasCost = BigInt(21000) * BigInt(gasPrice);

      // 实际可转账金额 = 余额 - 估算的 gas 费
      const estimatedTransferAmount = BigInt(balance) - estimatedGasCost;

      // 如果估算的 gas 费大于余额，无法转账
      if (estimatedTransferAmount <= 0) {
        // 余额未超过阈值 - 不输出日志
        return;
      }

      // P0修复：比较可转账金额和固定阈值（0.006 BNB）
      if (estimatedTransferAmount > BigInt(BNB_TRANSFER_THRESHOLD)) {
        // P0修复：转账金额 = 可转账金额 - 阈值（保留阈值金额在钱包中）
        const transferAmount = (estimatedTransferAmount - BigInt(BNB_TRANSFER_THRESHOLD)).toString();

        console.log(`BScanner [${this.walletAddress}] BNB 余额超过阈值`, {
          balance: blockchain.formatBalance(balance),
          threshold: blockchain.formatBalance(BNB_TRANSFER_THRESHOLD),
          transferAmount: blockchain.formatBalance(transferAmount),
          estimatedTransferAmount: blockchain.formatBalance(estimatedTransferAmount.toString())
        });

        logger.info(`BNB 余额超过阈值`, {
          wallet: this.walletAddress,
          balance,
          threshold: BNB_TRANSFER_THRESHOLD,
          transferAmount
        });

        // 触发转账（不执行 Gas 补充逻辑）
        await this.triggerTransfer(privateKey, transferAmount);

      } else {
        // 余额未超过阈值 - 不输出日志
      }

    } catch (error) {
      console.error(`BScanner [${this.walletAddress}] 检查 BNB 余额失败: ${error.message}`);
      logger.error(`检查 BNB 余额失败`, {
        wallet: this.walletAddress,
        error: error.message
      });
    }
  }

  /**
   * 触发转账（异步执行）
   * 注意：不执行 Gas 补充逻辑
   * @param {string} privateKey - 发送方私钥
   * @param {string} amount - 金额（wei 格式）
   */
  async triggerTransfer(privateKey, amount) {
    try {
      // 从环境变量获取安全钱包地址
      const safeWalletAddress = process.env.SAFE_WALLET;
      if (!safeWalletAddress) {
        throw new Error('安全钱包地址未配置（环境变量 SAFE_WALLET）');
      }

      console.log(`BScanner [${this.walletAddress}] 触发 BNB 转账...`);

      // P1修复：异步执行转账（不阻塞扫描循环），并等待交易确认
      // 注意：此处不调用 Transfer.executeTransfer（避免 Gas 补充逻辑）
      // 直接调用 blockchain.sendBNB
      blockchain.sendBNB(
        privateKey,
        safeWalletAddress,
        amount,
        { gasLimit: 21000 }
      ).then(txHash => {
        console.log(`BScanner [${this.walletAddress}] 交易已发送: ${txHash}`);
        logger.info(`BNB 交易已发送`, {
          wallet: this.walletAddress,
          txHash,
          amount
        });

        // 等待交易确认
        return blockchain.waitForTransaction(txHash, 1);
      }).then(receipt => {
        if (receipt && receipt.status === 1) {
          console.log(`BScanner [${this.walletAddress}] 转账成功: ${receipt.transactionHash}`);
          logger.info(`BNB 转账成功`, {
            wallet: this.walletAddress,
            txHash: receipt.transactionHash,
            amount
          });
        } else {
          console.error(`BScanner [${this.walletAddress}] 交易失败: ${receipt?.transactionHash || 'unknown'}`);
          logger.error(`BNB 交易失败`, {
            wallet: this.walletAddress,
            txHash: receipt?.transactionHash,
            status: receipt?.status
          });
        }
      }).catch(error => {
        console.error(`BScanner [${this.walletAddress}] 转账失败: ${error.message}`);
        logger.error(`BNB 转账失败`, {
          wallet: this.walletAddress,
          error: error.message
        });
      });

    } catch (error) {
      console.error(`BScanner [${this.walletAddress}] 触发转账失败: ${error.message}`);
      logger.error(`触发转账失败`, {
        wallet: this.walletAddress,
        error: error.message
      });
    }
  }

  /**
   * 获取状态
   * @returns {Object} 状态信息
   */
  getStatus() {
    return {
      walletAddress: this.walletAddress,
      isRunning: this.isRunning,
      scanInterval: 4000, // 固定为 4 秒
      transferThreshold: BNB_TRANSFER_THRESHOLD // 固定阈值 0.006 BNB
    };
  }

  /**
   * 重启
   */
  async restart() {
    await this.stop();
    await this.start();
  }
}

// 导出类
module.exports = BScanner;
