/**
 * 转账扩展
 * 被 scanner 触发后执行代币转账
 * @updated 2026-03-27T12:00:00.000Z
 * @lifecycle 已部署
 */

const blockchain = require('../utils/blockchain');
const logger = require('../utils/logger');
const Encryption = require('../utils/encryption');
const encryption = new Encryption();
const jsonStorage = require('../storage/json-storage');
const constants = require('../config/constants');
const gasAlert = require('./GasAlert');

class Transfer {
  constructor() {
    // Gas 补充金额（0.0005 BNB）
    this.refillAmount = constants.GAS_CONFIG.REFILL_AMOUNT;
    this.encryption = new Encryption();
  }

  /**
   * 执行转账
   * @param {Object} params - 转账参数
   * @returns {Promise<Object>} 转账结果
   */
  async executeTransfer(params) {
    const {
      fromAddress, // 发送方地址（被保护钱包）
      fromPrivateKey, // 发送方私钥
      toAddress, // 接收方地址（安全钱包）
      tokenName, // 代币名称（USDT, BNB, WKEYDAO）
      amount // 金额（wei 格式）
    } = params;

    logger.info(`开始转账: ${tokenName} ${amount} wei`, {
      from: fromAddress,
      to: toAddress
    });

    let txHash;
    let gasUsed = '0';
    let success = false;
    let note = '';

    try {
      // 获取代币信息
      const tokenInfo = constants.getTokenInfo(tokenName);
      if (!tokenInfo) {
        throw new Error(`未知代币: ${tokenName}`);
      }

      // 第一次尝试转账
      if (tokenName === 'BNB') {
        txHash = await this.transferBNB(fromPrivateKey, toAddress, amount);
      } else {
        txHash = await this.transferToken(fromPrivateKey, tokenInfo.address, toAddress, amount);
      }

      // 等待交易确认
      const receipt = await blockchain.waitForTransaction(txHash);
      gasUsed = receipt.gasUsed.toString();

      logger.info(`转账成功: ${txHash}`, {
        from: fromAddress,
        to: toAddress,
        token: tokenName,
        amount,
        gasUsed
      });

      success = true;

    } catch (error) {
      logger.error(`转账失败: ${error.message}`, {
        from: fromAddress,
        to: toAddress,
        token: tokenName,
        amount,
        error: error.message
      });

      // 检查是否为 Gas 不足错误
      if (this.isGasInsufficientError(error)) {
        // 检查被保护钱包是否需要补充 Gas
        const shouldRefill = await gasAlert.shouldRefillGas(fromAddress);

        if (shouldRefill) {
          note = 'Gas不足，尝试补充';
          const refillSuccess = await this.refillGas(fromAddress);

          if (refillSuccess) {
            // Gas 补充成功，重试转账（只重试 1 次）
            note = 'Gas补充成功，重试转账';

            // 对于 BNB，需要重新计算可转账金额
            let retryAmount = amount;
            if (tokenName === 'BNB') {
              const provider = await blockchain.getProvider();
              const feeData = await provider.getFeeData();
              const gasPrice = feeData.gasPrice;
              const estimatedGasCost = BigInt(constants.GAS_CONFIG.BNB_GAS_LIMIT) * BigInt(gasPrice);

              // 重新查询余额并计算
              const newBalance = await blockchain.getBNBBalance(fromAddress);
              retryAmount = (BigInt(newBalance) - estimatedGasCost).toString();

              if (BigInt(retryAmount) <= 0n) {
                note = 'Gas补充后余额仍不足以支付gas费';
                logger.warn(note);
              }
            }

            // 只有金额有效时才重试（只重试 1 次）
            if (BigInt(retryAmount) > 0n) {
              try {
                if (tokenName === 'BNB') {
                  txHash = await this.transferBNB(fromPrivateKey, toAddress, retryAmount);
                } else {
                  txHash = await this.transferToken(fromPrivateKey, constants.getTokenAddress(tokenName), toAddress, amount);
                }

                const receipt = await blockchain.waitForTransaction(txHash);
                gasUsed = receipt.gasUsed.toString();

                logger.info(`重试转账成功: ${txHash}`, {
                  from: fromAddress,
                  to: toAddress,
                  token: tokenName,
                  amount: retryAmount,
                  gasUsed
                });

                success = true;

              } catch (retryError) {
                note = `Gas补充后重试失败: ${retryError.message}`;
                logger.error(`重试转账失败: ${retryError.message}`);
              }
            }
          } else {
            note = '补充gas费失败';
          }
        } else {
          note = '被保护钱包Gas余额充足，但转账仍失败（其他原因）';
          logger.warn(note);
        }
      } else {
        // 非 Gas 不足错误，只重试 1 次（可能是网络原因）
        try {
          note = '网络错误，重试 1 次';
          logger.info(note);

          if (tokenName === 'BNB') {
            txHash = await this.transferBNB(fromPrivateKey, toAddress, amount);
          } else {
            txHash = await this.transferToken(fromPrivateKey, constants.getTokenAddress(tokenName), toAddress, amount);
          }

          const receipt = await blockchain.waitForTransaction(txHash);
          gasUsed = receipt.gasUsed.toString();

          logger.info(`重试转账成功: ${txHash}`, {
            from: fromAddress,
            to: toAddress,
            token: tokenName,
            amount,
            gasUsed
          });

          success = true;
          note = '重试成功';

        } catch (retryError) {
          note = `重试失败: ${retryError.message}`;
          logger.error(`重试转账失败: ${retryError.message}`);
        }
      }
    }

    // 保存交易记录
    const transaction = {
      txHash: txHash || '',
      tokenName,
      amount,
      from: fromAddress,
      to: toAddress,
      gasUsed,
      success,
      note
    };

    await this.saveTransaction(transaction);

    return transaction;
  }

  /**
   * 转账 BNB
   * @param {string} privateKey - 发送方私钥
   * @param {string} toAddress - 接收方地址
   * @param {string} amount - 金额（wei 格式）
   * @returns {Promise<string>} 交易哈希
   */
  async transferBNB(privateKey, toAddress, amount) {
    return await blockchain.sendBNB(
      privateKey,
      toAddress,
      amount,
      { gasLimit: constants.GAS_CONFIG.BNB_GAS_LIMIT }
    );
  }

  /**
   * 转账 ERC20 代币
   * @param {string} privateKey - 发送方私钥
   * @param {string} tokenAddress - 代币合约地址
   * @param {string} toAddress - 接收方地址
   * @param {string} amount - 金额（wei 格式）
   * @returns {Promise<string>} 交易哈希
   */
  async transferToken(privateKey, tokenAddress, toAddress, amount) {
    return await blockchain.sendToken(
      privateKey,
      tokenAddress,
      toAddress,
      amount,
      { gasLimit: constants.GAS_CONFIG.ERC20_GAS_LIMIT }
    );
  }

  /**
   * 判断是否为 Gas 不足错误
   * @param {Error} error - 错误对象
   * @returns {boolean} 是否为 Gas 不足错误
   */
  isGasInsufficientError(error) {
    const message = error.message?.toLowerCase() || '';
    return (
      message.includes('insufficient funds') ||
      message.includes('gas required exceeds allowance') ||
      message.includes('gas') ||
      message.includes('insufficient balance')
    );
  }

  /**
   * 补充 Gas
   * @param {string} toAddress - 接收方地址（被保护钱包）
   * @returns {Promise<boolean>} 是否补充成功
   */
  async refillGas(toAddress) {
    logger.info(`开始补充 Gas: ${toAddress}`, {
      amount: this.refillAmount
    });

    try {
      // 从环境变量获取安全钱包加密私钥
      const encryptedPrivateKey = process.env.SAFE_WALLET_ENCRYPTED_PRIVATE_KEY;
      if (!encryptedPrivateKey) {
        throw new Error('安全钱包加密私钥未配置');
      }

      // 解密私钥
      const safePrivateKey = encryption.decryptPrivateKey(encryptedPrivateKey);

      // 补充 Gas
      const txHash = await blockchain.refillGas(safePrivateKey, toAddress, this.refillAmount);

      // 等待交易确认
      await blockchain.waitForTransaction(txHash);

      logger.info(`Gas 补充成功: ${txHash}`, {
        to: toAddress,
        amount: this.refillAmount
      });

      // 通知 Gas 报警扩展（重置失败计数）
      await gasAlert.recordRefillSuccess(toAddress);

      return true;

    } catch (error) {
      logger.error(`Gas 补充失败: ${error.message}`, {
        to: toAddress
      });

      // 通知 Gas 报警扩展（记录失败）
      await gasAlert.recordRefillFailure(toAddress, error.message);

      return false;
    }
  }

  /**
   * 保存交易记录
   * @param {Object} transaction - 交易记录
   */
  async saveTransaction(transaction) {
    try {
      // 根据存储类型选择保存方式
      const storageType = process.env.TRANSACTION_STORAGE_TYPE || 'json';

      if (storageType === 'supabase') {
        const supabaseStorage = require('./supabase-storage');
        if (supabaseStorage.isAvailable()) {
          await supabaseStorage.addTransaction(transaction);
        }
      }

      // 始终保存到 JSON 文件
      await jsonStorage.addTransaction(transaction);

    } catch (error) {
      logger.error(`保存交易记录失败: ${error.message}`);
    }
  }
}

// 导出单例
module.exports = new Transfer();
