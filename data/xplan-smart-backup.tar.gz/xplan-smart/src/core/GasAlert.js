/**
 * Gas 报警扩展
 * 独立扩展，实现两个独立的报警逻辑：
 * 1. 定时检查安全钱包 BNB 余额（每天 12:00）
 * 2. 监听 Gas 补充失败（失败 3 次触发警报）
 * @updated 2026-04-03T20:20:00.000Z
 * @lifecycle 已部署
 */

// 加载环境变量
require('../config/env-loader');

const blockchain = require('../utils/blockchain');
const logger = require('../utils/logger');
const jsonStorage = require('../storage/json-storage');

class GasAlert {
  constructor() {
    this.isRunning = false;
    this.checkIntervalId = null;

    // 补充失败计数器（key: walletAddress, value: count）
    this.refillFailureCount = new Map();

    // 报警配置
    this.config = {
      // 提前预防阈值（BNB），默认 0.001
      preventThreshold: process.env.GAS_ALERT_PREVENT_THRESHOLD
        ? blockchain.parseAmount(process.env.GAS_ALERT_PREVENT_THRESHOLD, 18)
        : blockchain.parseAmount('0.001', 18),

      // 被保护钱包最小 Gas（BNB），默认 0.0002
      protectedMinGas: process.env.PROTECTED_WALLET_MIN_GAS
        ? blockchain.parseAmount(process.env.PROTECTED_WALLET_MIN_GAS, 18)
        : blockchain.parseAmount('0.0002', 18),

      // Gas 补充失败最大次数
      maxRefillFailures: parseInt(process.env.MAX_REFILL_RETRIES) || 3,

      // 提前预防警报间隔（小时），避免重复提醒，默认 24 小时
      preventAlertInterval: parseInt(process.env.PREVENT_ALERT_INTERVAL) || 24 * 60 * 60 * 1000,

      // 定时检查时间（小时），默认 12:00
      checkHour: parseInt(process.env.GAS_ALERT_CHECK_HOUR) || 12
    };
  }

  /**
   * 启动 Gas 报警
   */
  async start() {
    if (this.isRunning) {
      logger.warn('Gas 报警已在运行');
      return { success: false, message: 'Gas 报警已在运行' };
    }

    logger.info('启动 Gas 报警扩展...', this.config);

    this.isRunning = true;

    // 启动定时检查
    await this.scheduleCheck();

    logger.info('Gas 报警扩展已启动', {
      checkHour: this.config.checkHour,
      preventThreshold: blockchain.formatBalance(this.config.preventThreshold),
      protectedMinGas: blockchain.formatBalance(this.config.protectedMinGas),
      maxRefillFailures: this.config.maxRefillFailures
    });

    return { success: true, message: 'Gas 报警扩展已启动' };
  }

  /**
   * 停止 Gas 报警
   */
  async stop() {
    if (!this.isRunning) {
      return { success: false, message: 'Gas 报警未运行' };
    }

    logger.info('停止 Gas 报警扩展...');

    if (this.checkIntervalId) {
      clearTimeout(this.checkIntervalId);
      this.checkIntervalId = null;
    }

    this.isRunning = false;

    return { success: true, message: 'Gas 报警扩展已停止' };
  }

  /**
   * 安排定时检查（修复跨月问题）
   * P1修复：使用时间戳计算而不是 Date 对象的 setDate
   */
  async scheduleCheck() {
    if (!this.isRunning) return;

    const now = new Date();
    const currentTimestamp = now.getTime();
    
    // 今天 checkHour 点的时间戳
    const todayCheckTimestamp = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate(),
      this.config.checkHour,
      0,
      0
    ).getTime();

    // 如果今天的检查时间已过，设置为明天的同一时间
    // 否则设置为今天的检查时间
    const nextCheckTimestamp = todayCheckTimestamp <= currentTimestamp 
      ? todayCheckTimestamp + 24 * 60 * 60 * 1000  // 明天
      : todayCheckTimestamp;  // 今天

    const delay = nextCheckTimestamp - currentTimestamp;

    logger.info(`下一次定时检查: ${new Date(nextCheckTimestamp).toISOString()}`);

    this.checkIntervalId = setTimeout(async () => {
      if (!this.isRunning) return;

      // 执行定时检查
      await this.performScheduledCheck();

      // 安排下一次检查（24 小时后）
      this.scheduleCheck();
    }, delay);
  }

  /**
   * 执行定时检查（每天 12:00）
   */
  async performScheduledCheck() {
    try {
      logger.info('开始定时检查安全钱包 BNB 余额...');

      // 从环境变量获取安全钱包地址
      const safeWalletAddress = process.env.SAFE_WALLET;
      if (!safeWalletAddress) {
        logger.warn('安全钱包地址未配置（环境变量 SAFE_WALLET），跳过检查');
        return;
      }

      // 检查安全钱包 BNB 余额
      const balance = await blockchain.getBNBBalance(safeWalletAddress);
      const threshold = this.config.preventThreshold;

      logger.info(`安全钱包 BNB 余额: ${blockchain.formatBalance(balance)} BNB`, {
        threshold: blockchain.formatBalance(threshold)
      });

      // 判断是否低于阈值
      if (BigInt(balance) < BigInt(threshold)) {
        // 检查是否应该发送警报（避免重复）
        const shouldAlert = await jsonStorage.shouldSendAlert(
          safeWalletAddress,
          'SAFE_WALLET_LOW_BNB',
          this.config.preventAlertInterval
        );

        if (shouldAlert) {
          const message = `【提前预防警报】安全钱包 BNB 余额不足！当前: ${blockchain.formatBalance(balance)} BNB，建议阈值: ${blockchain.formatBalance(threshold)} BNB。请及时补充，避免 Gas 补充失败导致资产风险。`;

          await this.sendAlert('PREVENT', safeWalletAddress, 'SAFE_WALLET_LOW_BNB', message);
          logger.warn(message);
        } else {
          logger.info('提前预防警报已发送，跳过重复提醒');
        }
      } else {
        logger.info('安全钱包 BNB 余额正常');
      }

    } catch (error) {
      logger.error(`定时检查失败: ${error.message}`, { error: error.stack });
    }
  }

  /**
   * 检查被保护钱包是否需要补充 Gas
   * @param {string} walletAddress - 被保护钱包地址
   * @returns {Promise<boolean>} 是否需要补充
   */
  async shouldRefillGas(walletAddress) {
    try {
      const balance = await blockchain.getBNBBalance(walletAddress);
      const minGas = this.config.protectedMinGas;

      logger.info(`检查被保护钱包 Gas 余额: ${blockchain.formatBalance(balance)} BNB`, {
        walletAddress,
        minGas: blockchain.formatBalance(minGas)
      });

      // 余额 > 0.0008 BNB，不需要补充
      if (BigInt(balance) > BigInt(minGas)) {
        logger.info(`被保护钱包 Gas 余额充足，无需补充`, {
          walletAddress,
          balance: blockchain.formatBalance(balance)
        });
        return false;
      }

      // 余额 <= 0.0008 BNB，需要补充
      logger.info(`被保护钱包 Gas 余额不足，需要补充`, {
        walletAddress,
        balance: blockchain.formatBalance(balance)
      });
      return true;

    } catch (error) {
      logger.error(`检查被保护钱包 Gas 余额失败: ${error.message}`, {
        walletAddress
      });
      // 检查失败，保守起见返回 true（允许补充）
      return true;
    }
  }

  /**
   * 记录 Gas 补充失败
   * @param {string} walletAddress - 被保护钱包地址
   * @param {string} reason - 失败原因
   */
  async recordRefillFailure(walletAddress, reason) {
    const currentCount = this.refillFailureCount.get(walletAddress) || 0;
    const newCount = currentCount + 1;
    this.refillFailureCount.set(walletAddress, newCount);

    logger.warn(`Gas 补充失败计数: ${walletAddress}`, {
      count: newCount,
      max: this.config.maxRefillFailures,
      reason
    });

    // 达到最大失败次数，触发紧急警报
    if (newCount >= this.config.maxRefillFailures) {
      const message = `【紧急警报】Gas 补充连续失败 ${newCount} 次！被保护钱包: ${walletAddress}，最后失败原因: ${reason}。资产有被盗风险，请立即处理！`;

      await this.sendAlert('EMERGENCY', walletAddress, 'GAS_REFILL_FAILED', message);
      logger.error(message);

      // 重置计数器（避免重复报警）
      this.refillFailureCount.delete(walletAddress);
    }
  }

  /**
   * 记录 Gas 补充成功
   * @param {string} walletAddress - 被保护钱包地址
   */
  async recordRefillSuccess(walletAddress) {
    // 重置失败计数器
    this.refillFailureCount.delete(walletAddress);

    logger.info(`Gas 补充成功，重置失败计数: ${walletAddress}`);
  }

  /**
   * 发送警报
   * @param {string} type - 警报类型（PREVENT / EMERGENCY）
   * @param {string} walletAddress - 钱包地址
   * @param {string} alertKey - 警报键
   * @param {string} message - 警报消息
   */
  async sendAlert(type, walletAddress, alertKey, message) {
    try {
      // 保存警报记录
      await jsonStorage.addGasAlert(walletAddress, alertKey, message);

      // 记录日志（用户可以通过 PM2 日志或 API 读取）
      const logMethod = type === 'EMERGENCY' ? logger.error : logger.warn;
      logMethod(message, {
        type,
        walletAddress,
        alertKey,
        timestamp: new Date().toISOString()
      });

      // 精简版：不发送到 Telegram，仅记录日志

    } catch (error) {
      logger.error(`发送警报失败: ${error.message}`, {
        type,
        walletAddress
      });
    }
  }

  /**
   * 获取报警状态
   * @returns {Object} 报警状态
   */
  getStatus() {
    return {
      isRunning: this.isRunning,
      config: {
        checkHour: this.config.checkHour,
        preventThreshold: blockchain.formatBalance(this.config.preventThreshold),
        protectedMinGas: blockchain.formatBalance(this.config.protectedMinGas),
        maxRefillFailures: this.config.maxRefillFailures
      },
      failureCounts: Object.fromEntries(this.refillFailureCount)
    };
  }
}

// 导出单例
module.exports = new GasAlert();

// 如果作为主模块运行（直接通过 node 或 PM2 启动）
if (require.main === module) {
  const instance = module.exports;

  // 启动 Gas 报警
  instance.start().catch(error => {
    console.error('Gas 报警启动失败:', error);
    process.exit(1);
  });

  // 监听退出信号
  process.on('SIGINT', async () => {
    console.log('收到停止信号...');
    await instance.stop();
    process.exit(0);
  });

  process.on('SIGTERM', async () => {
    console.log('收到终止信号...');
    await instance.stop();
    process.exit(0);
  });
}

