/**
 * 交易队列管理器
 * 负责追踪待确认交易，提供重试机制
 * @updated 2026-03-28T12:00:00.000Z
 * @lifecycle 已部署
 */

const logger = require('../utils/logger');

class TransactionQueue {
  constructor(maxPending = 10, maxRetries = 3) {
    this.pendingTransactions = new Map(); // 待确认交易: txId -> { metadata, retries, executeFn }
    this.maxPending = maxPending;
    this.maxRetries = maxRetries;
    this.isProcessing = false;
  }

  /**
   * 添加交易到队列
   * @param {string} txId - 交易ID
   * @param {Function} executeFn - 执行交易的函数
   * @param {Object} metadata - 交易元数据
   * @returns {Promise<string>} 交易哈希
   */
  async addTransaction(txId, executeFn, metadata = {}) {
    // 检查是否已存在
    if (this.pendingTransactions.has(txId)) {
      console.warn(`交易 ${txId} 已存在于队列中`);
      return null;
    }

    // 检查队列容量
    if (this.pendingTransactions.size >= this.maxPending) {
      console.error(`交易队列已满，最大容量: ${this.maxPending}`);
      throw new Error('交易队列已满');
    }

    // 添加到队列
    this.pendingTransactions.set(txId, {
      metadata,
      retries: 0,
      executeFn,
      startTime: Date.now()
    });

    console.log(`交易已添加到队列: ${txId}`, metadata);
    logger.info('交易已添加到队列', { txId, ...metadata });

    // 执行交易
    return this._executeTransaction(txId);
  }

  /**
   * 执行交易（带重试）
   * @private
   */
  async _executeTransaction(txId) {
    const tx = this.pendingTransactions.get(txId);
    if (!tx) {
      console.error(`交易 ${txId} 不存在于队列中`);
      return null;
    }

    try {
      // 执行交易
      const txHash = await tx.executeFn();

      // 成功：从队列中移除
      this.pendingTransactions.delete(txId);

      console.log(`交易执行成功: ${txId}, txHash: ${txHash}`);
      logger.info('交易执行成功', { txId, txHash, ...tx.metadata });

      return txHash;

    } catch (error) {
      console.error(`交易执行失败: ${txId}`, error);
      logger.error('交易执行失败', {
        txId,
        error: error.message,
        retry: tx.retries,
        ...tx.metadata
      });

      // 检查重试次数
      if (tx.retries < this.maxRetries) {
        tx.retries++;

        // 计算退避时间：指数退避 (2^retry 秒)
        const backoffMs = Math.min(1000 * Math.pow(2, tx.retries), 30000);

        console.log(`将在 ${backoffMs}ms 后重试交易: ${txId} (第 ${tx.retries} 次重试)`);
        logger.info('交易重试计划', {
          txId,
          retry: tx.retries,
          maxRetries: this.maxRetries,
          backoffMs,
          ...tx.metadata
        });

        // 延迟重试
        await new Promise(resolve => setTimeout(resolve, backoffMs));
        return this._executeTransaction(txId);

      } else {
        // 超过最大重试次数，从队列中移除
        this.pendingTransactions.delete(txId);

        console.error(`交易 ${txId} 超过最大重试次数，已放弃`);
        logger.error('交易超过最大重试次数', {
          txId,
          maxRetries: this.maxRetries,
          ...tx.metadata
        });

        throw new Error(`交易失败，超过最大重试次数: ${error.message}`);
      }
    }
  }

  /**
   * 获取队列状态
   */
  getStatus() {
    const transactions = Array.from(this.pendingTransactions.entries()).map(([txId, tx]) => ({
      txId,
      metadata: tx.metadata,
      retries: tx.retries,
      elapsedMs: Date.now() - tx.startTime
    }));

    return {
      pendingCount: this.pendingTransactions.size,
      maxPending: this.maxPending,
      maxRetries: this.maxRetries,
      transactions
    };
  }

  /**
   * 清空队列
   */
  clear() {
    const count = this.pendingTransactions.size;
    this.pendingTransactions.clear();
    console.log(`交易队列已清空，共 ${count} 个交易`);
    logger.info('交易队列已清空', { count });
  }
}

module.exports = TransactionQueue;
