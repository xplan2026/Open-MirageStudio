/**
 * USDT Scanner - 监控被保护钱包的 USDT 余额
 * 当余额超过阈值时触发转账到安全钱包
 * @updated 2026-04-03T20:20:00.000Z
 * @lifecycle 已部署
 */

const blockchain = require('../utils/blockchain');
const logger = require('../utils/logger');
const constants = require('../config/constants');
const jsonStorage = require('../storage/json-storage');
const Transfer = require('./Transfer');

class USDTScanner {
  constructor(walletAddress, privateKeyEnvKey) {
    this.walletAddress = walletAddress;
    this.privateKeyEnvKey = privateKeyEnvKey;
    this.isRunning = false;
    this.intervalId = null;
  }

  /**
   * 启动扫描
   */
  async start() {
    console.log(`USDT Scanner [${this.walletAddress}] 启动中...`);

    // P0修复：启动时验证私钥是否可用
    const encryptedPrivateKey = process.env[this.privateKeyEnvKey];
    if (!encryptedPrivateKey) {
      throw new Error(`USDT Scanner [${this.walletAddress}] 未在环境变量中找到加密私钥: ${this.privateKeyEnvKey}`);
    }

    const Encryption = require('../utils/encryption');
    const encryption = new Encryption();
    const privateKey = encryption.decryptPrivateKey(encryptedPrivateKey);
    if (!privateKey) {
      throw new Error(`USDT Scanner [${this.walletAddress}] 私钥解密失败: ${this.privateKeyEnvKey}`);
    }

    this.isRunning = true;

    // 固定扫描间隔为 20 秒
    const scanInterval = 20000;

    // 立即执行一次扫描
    await this.scan();

    // 设置定时扫描（递归 setTimeout 确保扫描结束后再等待）
    this.scheduleNextScan(scanInterval);

    console.log(`USDT Scanner [${this.walletAddress}] 已启动，扫描间隔: ${scanInterval}ms (20秒)`);
  }

  /**
   * 安排下一次扫描
   * @param {number} scanInterval - 扫描间隔（毫秒）
   */
  scheduleNextScan(scanInterval) {
    if (!this.isRunning) return;

    // 清除旧的定时器
    if (this.intervalId) {
      clearTimeout(this.intervalId);
    }

    this.intervalId = setTimeout(async () => {
      if (!this.isRunning) return;

      await this.scan();

      // 扫描结束后再次安排下一次扫描（使用固定间隔）
      this.scheduleNextScan(scanInterval);
    }, scanInterval);
  }

  /**
   * 停止扫描
   */
  async stop() {
    console.log(`USDT Scanner [${this.walletAddress}] 停止中...`);
    this.isRunning = false;

    // 无论 isRunning 状态如何，都清除 intervalId
    if (this.intervalId) {
      clearTimeout(this.intervalId);
      this.intervalId = null;
    }

    console.log(`USDT Scanner [${this.walletAddress}] 已停止`);
  }

  /**
   * 执行扫描
   */
  async scan() {
    try {
      // 从环境变量获取加密私钥
      const encryptedPrivateKey = process.env[this.privateKeyEnvKey];

      if (!encryptedPrivateKey) {
        console.error(`USDT Scanner [${this.walletAddress}] 未在环境变量中找到加密私钥: ${this.privateKeyEnvKey}`);
        return;
      }

      // 解密私钥
      const Encryption = require('../utils/encryption');
      const encryption = new Encryption();
      const privateKey = encryption.decryptPrivateKey(encryptedPrivateKey);
      if (!privateKey) {
        console.error(`USDT Scanner [${this.walletAddress}] 私钥解密失败`);
        return;
      }

      // 获取 USDT 余额
      const tokenName = 'USDT';
      const tokenInfo = constants.getTokenInfo(tokenName);
      if (!tokenInfo) {
        throw new Error(`未知代币: ${tokenName}`);
      }

      const balance = await blockchain.getTokenBalance(
        this.walletAddress,
        tokenInfo.address
      );

      console.log(`USDT Scanner [${this.walletAddress}] USDT 余额: ${blockchain.formatBalance(balance)}`);

      // 获取转账阈值
      const threshold = constants.getTransferThreshold('USDT');

      // P0修复：检查余额是否超过阈值
      if (BigInt(balance) > BigInt(threshold)) {
        // P0修复：检查 BNB 余额是否足够支付 gas
        const bnbBalance = await blockchain.getBNBBalance(this.walletAddress);
        const provider = await blockchain.getProvider();
        const feeData = await provider.getFeeData();
        const gasPrice = feeData.gasPrice;
        const estimatedGasCost = BigInt(60000) * BigInt(gasPrice); // ERC20 转账约 60,000 gas

        if (BigInt(bnbBalance) < estimatedGasCost) {
          console.warn(`USDT Scanner [${this.walletAddress}] BNB 余额不足，无法转账 USDT (BNB: ${blockchain.formatBalance(bnbBalance)}, 需要: ${blockchain.formatBalance(estimatedGasCost.toString())})`);
          logger.warn('BNB 余额不足，无法转账 USDT', {
            wallet: this.walletAddress,
            bnbBalance,
            estimatedGasCost: estimatedGasCost.toString()
          });
          return;
        }

        const transferAmount = balance;

        console.log(`USDT Scanner [${this.walletAddress}] USDT 余额超过阈值`, {
          balance: blockchain.formatBalance(balance),
          threshold: blockchain.formatBalance(threshold),
          transferAmount: blockchain.formatBalance(transferAmount)
        });

        logger.info('USDT 余额超过阈值', {
          wallet: this.walletAddress,
          balance,
          threshold,
          transferAmount
        });

        // 触发转账（不执行 Gas 补充逻辑）
        await this.triggerTransfer(privateKey, tokenName, transferAmount);

      } else {
        // 余额未超过阈值
        console.log(`USDT Scanner [${this.walletAddress}] USDT 余额未超过阈值`);
      }

    } catch (error) {
      console.error(`USDT Scanner [${this.walletAddress}] 扫描失败: ${error.message}`);
      logger.error('USDT Scanner 扫描失败', {
        wallet: this.walletAddress,
        error: error.message
      });
    }
  }

  /**
   * 触发转账（异步执行）
   * 注意：不执行 Gas 补充逻辑
   * @param {string} privateKey - 发送方私钥
   * @param {string} tokenName - 代币名称
   * @param {string} amount - 金额（wei 格式）
   */
  async triggerTransfer(privateKey, tokenName, amount) {
    try {
      // 从环境变量获取安全钱包地址
      const safeWalletAddress = process.env.SAFE_WALLET;
      if (!safeWalletAddress) {
        throw new Error('安全钱包地址未配置（环境变量 SAFE_WALLET）');
      }

      console.log(`USDT Scanner [${this.walletAddress}] 触发 USDT 转账...`);

      // P1修复：异步执行转账（不阻塞扫描循环），并等待交易确认
      // 注意：此处不调用 Transfer.executeTransfer（避免 Gas 补充逻辑）
      // 直接调用 blockchain.transferToken
      blockchain.transferToken(
        privateKey,
        constants.getTokenAddress(tokenName),
        safeWalletAddress,
        amount
      ).then(txHash => {
        console.log(`USDT Scanner [${this.walletAddress}] 交易已发送: ${txHash}`);
        logger.info('USDT 交易已发送', {
          wallet: this.walletAddress,
          txHash,
          tokenName,
          amount
        });

        // 等待交易确认
        return blockchain.waitForTransaction(txHash, 1);
      }).then(receipt => {
        if (receipt && receipt.status === 1) {
          console.log(`USDT Scanner [${this.walletAddress}] 转账成功: ${receipt.transactionHash}`);
          logger.info('USDT 转账成功', {
            wallet: this.walletAddress,
            txHash: receipt.transactionHash,
            tokenName,
            amount
          });
        } else {
          console.error(`USDT Scanner [${this.walletAddress}] 交易失败: ${receipt?.transactionHash || 'unknown'}`);
          logger.error('USDT 交易失败', {
            wallet: this.walletAddress,
            txHash: receipt?.transactionHash,
            status: receipt?.status
          });
        }
      }).catch(error => {
        console.error(`USDT Scanner [${this.walletAddress}] 转账失败: ${error.message}`);
        logger.error('USDT 转账失败', {
          wallet: this.walletAddress,
          error: error.message
        });
      });

    } catch (error) {
      console.error(`USDT Scanner [${this.walletAddress}] 触发转账失败: ${error.message}`);
      logger.error('USDT Scanner 触发转账失败', {
        wallet: this.walletAddress,
        error: error.message
      });
    }
  }

  /**
   * 获取状态
   * @returns {Object} 状态信息
   */
  getStatus() {
    return {
      walletAddress: this.walletAddress,
      isRunning: this.isRunning,
      scanInterval: 20000, // 修复：返回正确的扫描间隔 20 秒
      tokenName: 'USDT',
      threshold: constants.getTransferThreshold('USDT')
    };
  }

  /**
   * 重启
   */
  async restart() {
    await this.stop();
    await this.start();
  }
}

module.exports = USDTScanner;
