/**
 * 常量定义
 * 项目中使用的常量和配置
 * @updated 2026-03-28T13:00:00.000Z
 * @lifecycle 已部署
 */

class Constants {
  constructor() {
    // ==================== 区块链相关 ====================

    // BSC 主网 Chain ID
    this.CHAIN_ID = 56;

    // 代币地址
    this.TOKEN_ADDRESSES = {
      USDT: process.env.USDT_ADDRESS || '0x55d398326f99059fF775485246999027B3197955',
      WKEYDAO2: process.env.WKEYDAO2_ADDRESS || '0xe0a281deff5c9d8d67af09d39340e134ac81b82e'
    };

    // 代币信息
    this.TOKEN_INFO = {
      USDT: {
        name: 'USDT',
        symbol: 'USDT',
        decimals: 18,
        address: this.TOKEN_ADDRESSES.USDT
      },
      WKEYDAO2: {
        name: 'wkeyDAO2',
        symbol: 'WKEY2',
        decimals: 9,
        address: this.TOKEN_ADDRESSES.WKEYDAO2
      },
      BNB: {
        name: 'BNB',
        symbol: 'BNB',
        decimals: 18,
        address: null // BNB 是原生代币
      }
    };

    // ==================== 转账配置 ====================

    // 默认 Gas 配置
    this.GAS_CONFIG = {
      // Gas 价格倍数
      MULTIPLIER: parseFloat(process.env.MONITOR_GAS_PRICE_MULTIPLIER) || 1.1,

      // BNB 转账 Gas 限制
      BNB_GAS_LIMIT: 21000,

      // ERC20 代币转账 Gas 限制
      ERC20_GAS_LIMIT: 60000,

      // Gas 补充金额（wei），默认 0.0005 BNB
      REFILL_AMOUNT: '500000000000000'
    };

    // 转账阈值（wei）
    this.TRANSFER_THRESHOLDS = {
      USDT: '0', // USDT 只要 > 0 就转账
      BNB: process.env.BNB_TRANSFER_THRESHOLD
        ? this.parseAmount(process.env.BNB_TRANSFER_THRESHOLD, 18)
        : '1000000000000', // 默认 0.000001 BNB
      WKEYDAO2: '0' // wkeyDAO2 只要 > 0 就转账
    };

    // 转账开关
    this.TRANSFER_ENABLED = {
      USDT: process.env.USDT_TRANSFER_ENABLED !== 'false',
      BNB: process.env.BNB_TRANSFER_ENABLED !== 'false',
      WKEYDAO2: process.env.WKEYDAO2_TRANSFER_ENABLED !== 'false'
    };

    // ==================== 监控配置 ====================

    // 默认监控配置
    this.MONITOR_CONFIG = {
      // 扫描间隔（毫秒），默认 3 秒
      SCAN_INTERVAL: 3000,

      // 最大重试次数
      MAX_RETRIES: parseInt(process.env.MONITOR_MAX_RETRIES) || 3,

      // 检查超时（毫秒）
      TIMEOUT: 30000
    };

    // ==================== API 响应 ====================

    // HTTP 状态码
    this.HTTP_STATUS = {
      OK: 200,
      CREATED: 201,
      BAD_REQUEST: 400,
      UNAUTHORIZED: 401,
      FORBIDDEN: 403,
      NOT_FOUND: 404,
      CONFLICT: 409,
      INTERNAL_ERROR: 500
    };

    // 错误消息
    this.ERROR_MESSAGES = {
      UNAUTHORIZED: '未授权访问',
      INVALID_TOKEN: '无效的令牌',
      EXPIRED_TOKEN: '令牌已过期',
      FORBIDDEN: '权限不足',
      NOT_FOUND: '资源未找到',
      INVALID_PARAMS: '参数无效',
      INTERNAL_ERROR: '服务器内部错误',
      WALLET_NOT_IN_WHITELIST: '钱包地址不在白名单中',
      INSUFFICIENT_BALANCE: '余额不足',
      TRANSACTION_FAILED: '交易失败',
      RPC_ERROR: 'RPC 节点错误',
      ENCRYPTION_ERROR: '加密/解密失败'
    };

    // ==================== 存储配置 ====================

    // 存储类型
    this.STORAGE_TYPES = {
      JSON: 'json',
      SUPABASE: 'supabase'
    };

    // 当前存储类型
    this.STORAGE_TYPE = process.env.TRANSACTION_STORAGE_TYPE || this.STORAGE_TYPES.JSON;

    // ==================== 地址格式化 ====================

    // 地址显示格式
    this.ADDRESS_DISPLAY = {
      PREFIX_LENGTH: 4, // 前缀长度
      SUFFIX_LENGTH: 4, // 后缀长度
      SEPARATOR: '...' // 分隔符
    };

    // ==================== 文件路径 ====================

    // 文件路径
    this.FILE_PATHS = {
      TRANSACTION_JSON: process.env.TRANSACTION_JSON_FILE || './cache/transactions.json',
      WALLET_KEYS: './storage/wallet-keys.json',
      CONFIG: './cache/config.json',
      LOGS: './cache/logs'
    };

    // ==================== 其他常量 ====================

    // 默认值
    this.DEFAULTS = {
      SCAN_INTERVAL: 3000,
      MAX_RETRIES: 3,
      GAS_MULTIPLIER: 1.1
    };
  }

  /**
   * 解析金额为 wei
   * @param {string|number} amount - 金额
   * @param {number} decimals - 小数位数
   * @returns {string} wei 格式的金额
   */
  parseAmount(amount, decimals = 18) {
    const ethers = require('ethers');
    return ethers.utils.parseUnits(String(amount), decimals).toString();
  }

  /**
   * 格式化地址显示
   * @param {string} address - 完整地址
   * @returns {string} 格式化后的地址
   */
  formatAddress(address) {
    if (!address || address.length < 8) return address;

    return `${address.slice(0, this.ADDRESS_DISPLAY.PREFIX_LENGTH)}${this.ADDRESS_DISPLAY.SEPARATOR}${address.slice(-this.ADDRESS_DISPLAY.SUFFIX_LENGTH)}`;
  }

  /**
   * 获取代币信息
   * @param {string} tokenName - 代币名称
   * @returns {Object} 代币信息
   */
  getTokenInfo(tokenName) {
    return this.TOKEN_INFO[tokenName] || null;
  }

  /**
   * 获取代币地址
   * @param {string} tokenName - 代币名称
   * @returns {string} 代币地址
   */
  getTokenAddress(tokenName) {
    return this.TOKEN_ADDRESSES[tokenName] || null;
  }

  /**
   * 获取转账阈值
   * @param {string} tokenName - 代币名称
   * @returns {string} 阈值（wei 格式）
   */
  getTransferThreshold(tokenName) {
    return this.TRANSFER_THRESHOLDS[tokenName] || '0';
  }

  /**
   * 检查转账是否启用
   * @param {string} tokenName - 代币名称
   * @returns {boolean} 是否启用
   */
  isTransferEnabled(tokenName) {
    return this.TRANSFER_ENABLED[tokenName] !== false;
  }

  /**
   * 获取所有代币名称
   * @returns {Array} 代币名称数组
   */
  getAllTokenNames() {
    return Object.keys(this.TOKEN_INFO);
  }
}

// 导出单例
module.exports = new Constants();
