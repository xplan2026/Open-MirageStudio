/**
 * 环境变量加载
 * 加载和验证环境变量配置
 * @updated 2026-03-25T14:30:00.000Z
 * @lifecycle 已部署
 */

// 加载环境变量 - 根据 NODE_ENV 加载对应的 .env 文件
const path = require('path');
const fs = require('fs');

// 先设置 NODE_ENV 默认值（防止未设置时出错）
if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = 'production';
}

console.log(`[EnvLoader] NODE_ENV = ${process.env.NODE_ENV}, cwd = ${process.cwd()}`);

// 尝试多个路径加载 .env 文件
const possiblePaths = [
  path.resolve(process.cwd(), `.env${process.env.NODE_ENV === 'production' ? '.production' : ''}`),
  path.resolve(process.cwd(), `.env`)
];

let envPath = null;
for (const p of possiblePaths) {
  if (fs.existsSync(p)) {
    envPath = p;
    console.log(`[EnvLoader] 加载环境变量文件: ${p}`);
    break;
  }
}

if (envPath) {
  require('dotenv').config({ path: envPath });
  console.log(`[EnvLoader] 环境变量已加载，ENCRYPTION_KEY: ${process.env.ENCRYPTION_KEY ? 'OK' : 'NOT FOUND'}`);
} else {
  console.warn('[EnvLoader] 未找到 .env 或 .env.production 文件');
  console.log('[EnvLoader] 搜索的路径:');
  possiblePaths.forEach(p => console.log(`  - ${p}`));
}

class EnvLoader {
  constructor() {
    // 已加载的环境变量
    this.loaded = false;
    this.errors = [];

    // 设置默认值（立即执行，不依赖其他检查）
    this.setDefaults();
  }

  /**
   * 加载环境变量
   * @returns {Object} 加载结果
   */
  load() {
    if (this.loaded) {
      return { success: true, errors: this.errors };
    }

    // 验证必需的环境变量
    this.validateRequired();

    // 验证格式
    this.validateFormats();

    // 设置默认值（已在构造函数中执行）

    this.loaded = true;

    return {
      success: this.errors.length === 0,
      errors: this.errors
    };
  }

  /**
   * 验证必需的环境变量
   */
  validateRequired() {
    const required = {
      // 基础服务
      PORT: '服务端口',
      FRONTEND_PORT: '前端服务端口',

      // 钱包配置
      PROTECTED_WALLETS: '被保护钱包列表',
      SAFE_WALLET: '安全钱包地址',

      // BSC 配置
      BSC_RPC_URL: 'BSC RPC URL',
      USDT_ADDRESS: 'USDT 代币地址',
      WKEYDAO_ADDRESSES: 'WKEYDAO 代币地址',
      WKEYDAO2_ADDRESS: 'WKEYDAO2 代币地址',

      // 加密配置
      ENCRYPTION_KEY: '加密密钥',

      // 认证配置
      JWT_SECRET: 'JWT 密钥'
    };

    for (const [key, desc] of Object.entries(required)) {
      if (!process.env[key]) {
        this.errors.push({
          type: 'missing',
          key,
          message: `缺少必需的环境变量: ${desc} (${key})`
        });
      }
    }
  }

  /**
   * 验证环境变量格式
   */
  validateFormats() {
    // 验证钱包地址格式
    this.validateWalletAddresses();

    // 验证私钥格式
    this.validatePrivateKeys();

    // 验证 RPC URL 格式
    this.validateRPCUrls();

    // 验证加密密钥格式
    this.validateEncryptionKey();

    // 验证端口
    this.validatePorts();

    // 验证数值
    this.validateNumbers();
  }

  /**
   * 验证钱包地址格式
   */
  validateWalletAddresses() {
    const walletFields = [
      { key: 'PROTECTED_WALLETS', required: true },
      { key: 'SAFE_WALLET', required: true },
      { key: 'USDT_ADDRESS', required: true },
      { key: 'WKEYDAO_ADDRESSES', required: true },
      { key: 'WKEYDAO2_ADDRESS', required: false }
    ];

    for (const field of walletFields) {
      const value = process.env[field.key];
      if (!value) continue;

      const addresses = value.split(',');
      for (const addr of addresses) {
        if (!this.isValidAddress(addr.trim())) {
          this.errors.push({
            type: 'format',
            key: field.key,
            message: `无效的钱包地址格式: ${addr}`
          });
        }
      }
    }
  }

  /**
   * 验证私钥格式
   */
  validatePrivateKeys() {
    const privateKeyFields = [
      'SAFE_WALLET_PRIVATE_KEY',
      'ENCRYPTION_KEY'
    ];

    for (const key of privateKeyFields) {
      const value = process.env[key];
      if (!value) continue;

      if (key === 'ENCRYPTION_KEY') {
        // 加密密钥必须是 64 字符的十六进制字符串
        if (value.length !== 64) {
          this.errors.push({
            type: 'format',
            key,
            message: `ENCRYPTION_KEY 必须是 64 字符的十六进制字符串`
          });
        }
        if (!/^[0-9a-fA-F]{64}$/.test(value)) {
          this.errors.push({
            type: 'format',
            key,
            message: `ENCRYPTION_KEY 必须是有效的十六进制字符串`
          });
        }
      }
    }
  }

  /**
   * 验证 RPC URL 格式
   */
  validateRPCUrls() {
    const urlFields = ['BSC_RPC_URL', 'BSC_MAINNET_RPC_URL'];

    for (const key of urlFields) {
      const value = process.env[key];
      if (!value) continue;

      if (!this.isValidUrl(value)) {
        this.errors.push({
          type: 'format',
          key,
          message: `无效的 URL 格式: ${value}`
        });
      }
    }
  }

  /**
   * 验证加密密钥
   */
  validateEncryptionKey() {
    // 已在 validatePrivateKeys 中验证
  }

  /**
   * 验证端口
   */
  validatePorts() {
    const portFields = ['FRONTEND_PORT'];

    for (const key of portFields) {
      const value = process.env[key];
      if (!value) continue;

      const port = parseInt(value);
      if (isNaN(port) || port < 1 || port > 65535) {
        this.errors.push({
          type: 'format',
          key,
          message: `无效的端口号: ${value}`
        });
      }
    }
  }

  /**
   * 验证数值
   */
  validateNumbers() {
    const numberFields = [
      { key: 'MONITOR_CHECK_INTERVAL', default: 5000 },
      { key: 'MONITOR_MAX_RETRIES', default: 3 },
      { key: 'MONITOR_GAS_PRICE_MULTIPLIER', default: 1.1 },
      { key: 'REALTIME_LOG_BUFFER_SIZE', default: 1000 }
    ];

    for (const field of numberFields) {
      const value = process.env[field.key];
      if (!value) continue;

      const num = parseFloat(value);
      if (isNaN(num) || num < 0) {
        this.errors.push({
          type: 'format',
          key: field.key,
          message: `无效的数值: ${value}`
        });
      }
    }
  }

  /**
   * 验证地址格式
   * @param {string} address - 钱包地址
   * @returns {boolean} 是否有效
   */
  isValidAddress(address) {
    if (!address) return false;
    return /^0x[a-fA-F0-9]{40}$/.test(address);
  }

  /**
   * 验证 URL 格式
   * @param {string} url - URL
   * @returns {boolean} 是否有效
   */
  isValidUrl(url) {
    if (!url) return false;
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * 设置默认值
   */
  setDefaults() {
    const defaults = {
      FRONTEND_PORT: '5656',
      FRONTEND_HOST: '0.0.0.0',
      MONITOR_CHECK_INTERVAL: '5000',
      MONITOR_MAX_RETRIES: '3',
      MONITOR_GAS_PRICE_MULTIPLIER: '1.1',
      REALTIME_LOG_BUFFER_SIZE: '1000',
      TRANSACTION_STORAGE_TYPE: 'json',
      NODE_ENV: 'development'
    };

    for (const [key, value] of Object.entries(defaults)) {
      if (!process.env[key]) {
        process.env[key] = value;
      }
    }
  }

  /**
   * 获取环境变量值
   * @param {string} key - 环境变量键
   * @param {any} defaultValue - 默认值
   * @returns {any} 环境变量值
   */
  get(key, defaultValue = null) {
    return process.env[key] || defaultValue;
  }

  /**
   * 获取布尔值
   * @param {string} key - 环境变量键
   * @param {boolean} defaultValue - 默认值
   * @returns {boolean} 布尔值
   */
  getBoolean(key, defaultValue = false) {
    const value = process.env[key];
    if (value === undefined) return defaultValue;
    return value === 'true' || value === '1';
  }

  /**
   * 获取数字值
   * @param {string} key - 环境变量键
   * @param {number} defaultValue - 默认值
   * @returns {number} 数字值
   */
  getNumber(key, defaultValue = 0) {
    const value = process.env[key];
    if (value === undefined) return defaultValue;
    const num = parseFloat(value);
    return isNaN(num) ? defaultValue : num;
  }

  /**
   * 获取数组值
   * @param {string} key - 环境变量键
   * @param {string} separator - 分隔符
   * @returns {Array} 数组值
   */
  getArray(key, separator = ',') {
    const value = process.env[key];
    if (!value) return [];
    return value.split(separator).map(item => item.trim()).filter(item => item);
  }

  /**
   * 检查是否开发环境
   * @returns {boolean} 是否开发环境
   */
  isDev() {
    return process.env.NODE_ENV !== 'production';
  }

  /**
   * 检查是否生产环境
   * @returns {boolean} 是否生产环境
   */
  isProd() {
    return process.env.NODE_ENV === 'production';
  }

  /**
   * 打印配置摘要
   */
  printSummary() {
    console.log('='.repeat(50));
    console.log('环境变量加载摘要');
    console.log('='.repeat(50));
    console.log(`环境: ${this.isDev() ? '开发' : '生产'}`);
    console.log(`前端端口: ${this.get('FRONTEND_PORT')}`);
    console.log(`被保护钱包数量: ${this.getArray('PROTECTED_WALLETS').length}`);
    console.log(`存储类型: ${this.get('TRANSACTION_STORAGE_TYPE')}`);
    console.log(`扫描间隔: ${this.getNumber('MONITOR_CHECK_INTERVAL')}ms`);
    console.log('='.repeat(50));
  }
}

// 导出单例
module.exports = new EnvLoader();
