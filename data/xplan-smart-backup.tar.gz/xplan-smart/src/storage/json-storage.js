/**
 * JSON 文件存储
 * 交易记录和配置信息的 JSON 文件存储实现
 * @updated 2026-03-27T00:01:00.000Z
 * @lifecycle 已部署
 */

const fs = require('fs').promises;
const path = require('path');

class JsonStorage {
  constructor() {
    // 配置文件路径
    this.transactionFile = process.env.TRANSACTION_JSON_FILE || './cache/transactions.json';
    this.configFile = './cache/config.json';

    // Telegram 和通知相关文件
    this.telegramBindingsFile = './cache/telegram-bindings.json';
    this.telegramHistoryFile = './cache/telegram-history.json';
    this.notificationQueueFile = './cache/notification-queue.json';

    // 确保目录存在
    this.ensureDirectories();
  }

  /**
   * 确保目录存在
   */
  async ensureDirectories() {
    const dirs = [
      path.dirname(this.transactionFile),
      path.dirname(this.configFile),
      path.dirname(this.telegramBindingsFile),
      path.dirname(this.telegramHistoryFile),
      path.dirname(this.notificationQueueFile)
    ];

    for (const dir of dirs) {
      try {
        await fs.mkdir(dir, { recursive: true });
      } catch (error) {
        // 目录已存在，忽略
      }
    }
  }

  /**
   * 读取 JSON 文件
   * @param {string} filePath - 文件路径
   * @returns {Promise<Object>} JSON 数据
   */
  async readJsonFile(filePath) {
    try {
      const data = await fs.readFile(filePath, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      if (error.code === 'ENOENT') {
        return null; // 文件不存在
      }
      if (error instanceof SyntaxError) {
        console.error(`JSON 解析失败: ${filePath}`, error.message);
        // 异步备份，不阻塞
        setImmediate(() => this.backupCorruptedFile(filePath, error));
        return null;
      }
      console.error(`读取文件失败: ${filePath}`, error);
      return null; // 所有文件错误都返回 null，避免崩溃
    }
  }

  /**
   * 写入 JSON 文件
   * @param {string} filePath - 文件路径
   * @param {Object} data - JSON 数据
   */
  async writeJsonFile(filePath, data) {
    try {
      const jsonStr = JSON.stringify(data, null, 2);
      await fs.writeFile(filePath, jsonStr, 'utf8');
    } catch (error) {
      console.error(`写入文件失败: ${filePath}`, error);
      // 不抛出异常，避免崩溃
      return false;
    }
    return true;
  }

  /**
   * 备份损坏的 JSON 文件
   * @param {string} filePath - 文件路径
   * @param {Error} error - 错误对象
   */
  async backupCorruptedFile(filePath, error) {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupPath = `${filePath}.corrupted.${timestamp}.bak`;
      await fs.copyFile(filePath, backupPath);
      console.log(`已备份损坏的文件到: ${backupPath}`);

      // 记录到日志
      const logger = require('../utils/logger');
      logger.error('JSON 文件损坏已备份', {
        filePath,
        backupPath,
        error: error.message
      });

      // 清理过期的备份文件（保留最近 10 个）
      await this.cleanOldBackups(filePath);
    } catch (backupError) {
      console.error(`备份损坏文件失败: ${filePath}`, backupError);
    }
  }

  /**
   * 清理旧的备份文件
   * @param {string} originalFilePath - 原始文件路径
   */
  async cleanOldBackups(originalFilePath) {
    try {
      const dir = path.dirname(originalFilePath);
      const baseName = path.basename(originalFilePath);
      const files = await fs.readdir(dir);

      // 查找所有备份文件
      const backups = files
        .filter(f => f.startsWith(`${baseName}.corrupted.`) && f.endsWith('.bak'))
        .map(f => ({
          name: f,
          path: path.join(dir, f),
          mtime: (require('fs').statSync(path.join(dir, f))).mtime
        }))
        .sort((a, b) => b.mtime - a.mtime); // 按修改时间降序

      // 保留最近的 10 个，删除其余的
      if (backups.length > 10) {
        const toDelete = backups.slice(10);
        for (const backup of toDelete) {
          await fs.unlink(backup.path);
          console.log(`已删除过期备份: ${backup.name}`);
        }
      }
    } catch (error) {
      console.error('清理旧备份文件失败:', error);
    }
  }

  // ==================== 交易记录相关 ====================

  /**
   * 获取所有交易记录
   * @returns {Promise<Array>} 交易记录数组
   */
  async getAllTransactions() {
    const data = await this.readJsonFile(this.transactionFile);
    return data || [];
  }

  /**
   * 添加交易记录
   * @param {Object} transaction - 交易记录
   * @returns {Promise<Object>} 添加的交易记录
   */
  async addTransaction(transaction) {
    const transactions = await this.getAllTransactions();

    // 脱敏处理钱包地址
    const sanitizedTransaction = { ...transaction };
    if (sanitizedTransaction.from) {
      sanitizedTransaction.from = this.formatAddress(sanitizedTransaction.from);
    }
    if (sanitizedTransaction.to) {
      sanitizedTransaction.to = this.formatAddress(sanitizedTransaction.to);
    }
    if (sanitizedTransaction.fromAddress) {
      sanitizedTransaction.fromAddress = this.formatAddress(sanitizedTransaction.fromAddress);
    }
    if (sanitizedTransaction.toAddress) {
      sanitizedTransaction.toAddress = this.formatAddress(sanitizedTransaction.toAddress);
    }

    const newTransaction = {
      id: Date.now().toString(),
      ...sanitizedTransaction,
      createdAt: new Date().toISOString()
    };

    transactions.unshift(newTransaction);
    await this.writeJsonFile(this.transactionFile, transactions);

    return newTransaction;
  }

  /**
   * 格式化地址（脱敏）
   * @param {string} address - 完整地址
   * @returns {string} 脱敏后的地址
   */
  formatAddress(address) {
    if (!address || address.length < 8) return address;
    return `${address.slice(0, 4)}...${address.slice(-4)}`;
  }

  /**
   * 按代币类型获取交易记录
   * @param {string} tokenName - 代币名称（USDT, BNB, wkeyDAO）
   * @returns {Promise<Array>} 交易记录数组
   */
  async getTransactionsByToken(tokenName) {
    const transactions = await this.getAllTransactions();
    return transactions.filter(tx => tx.tokenName === tokenName);
  }

  /**
   * 按时间范围获取交易记录
   * @param {Date} startDate - 开始日期
   * @param {Date} endDate - 结束日期
   * @returns {Promise<Array>} 交易记录数组
   */
  async getTransactionsByDateRange(startDate, endDate) {
    const transactions = await this.getAllTransactions();
    const start = startDate.getTime();
    const end = endDate.getTime();

    return transactions.filter(tx => {
      const txDate = new Date(tx.createdAt).getTime();
      return txDate >= start && txDate <= end;
    });
  }

  /**
   * 获取交易统计
   * @returns {Promise<Object>} 统计数据
   */
  async getTransactionStats() {
    const transactions = await this.getAllTransactions();

    const stats = {
      totalTransactions: transactions.length,
      totalAmountByToken: {},
      successCount: 0,
      failedCount: 0,
      totalGasUsed: 0
    };

    transactions.forEach(tx => {
      // 按代币统计金额
      if (!stats.totalAmountByToken[tx.tokenName]) {
        stats.totalAmountByToken[tx.tokenName] = '0';
      }
      stats.totalAmountByToken[tx.tokenName] = (
        BigInt(stats.totalAmountByToken[tx.tokenName]) + BigInt(tx.amount)
      ).toString();

      // 统计成功/失败
      if (tx.success) {
        stats.successCount++;
      } else {
        stats.failedCount++;
      }

      // 统计 Gas 消耗
      if (tx.gasUsed) {
        stats.totalGasUsed += parseInt(tx.gasUsed);
      }
    });

    // 计算成功率
    stats.successRate = stats.totalTransactions > 0
      ? (stats.successCount / stats.totalTransactions * 100).toFixed(2)
      : '0.00';

    return stats;
  }

  // ==================== 配置相关 ====================

  /**
   * 获取配置
   * @returns {Promise<Object>} 配置对象
   */
  async getConfig() {
    return await this.readJsonFile(this.configFile) || {};
  }

  /**
   * 保存配置
   * @param {Object} config - 配置对象
   */
  async saveConfig(config) {
    await this.writeJsonFile(this.configFile, config);
  }

  /**
   * 获取扫描间隔
   * @returns {Promise<number>} 扫描间隔（毫秒）
   */
  async getScanInterval() {
    const config = await this.getConfig();
    return config.scanInterval || 10000; // 默认 10 秒
  }

  /**
   * 设置扫描间隔
   * @param {number} interval - 扫描间隔（毫秒）
   */
  async setScanInterval(interval) {
    const config = await this.getConfig();
    config.scanInterval = interval;
    await this.saveConfig(config);
  }

  /**
   * 获取最大重试次数
   * @returns {Promise<number>} 最大重试次数
   */
  async getMaxRetries() {
    const config = await this.getConfig();
    return config.maxRetries || 3;
  }

  /**
   * 设置最大重试次数
   * @param {number} retries - 最大重试次数
   */
  async setMaxRetries(retries) {
    const config = await this.getConfig();
    config.maxRetries = retries;
    await this.saveConfig(config);
  }

  /**
   * 获取 Gas 价格倍数
   * @returns {Promise<number>} Gas 价格倍数
   */
  async getGasMultiplier() {
    const config = await this.getConfig();
    return config.gasMultiplier || 1.1;
  }

  /**
   * 设置 Gas 价格倍数
   * @param {number} multiplier - Gas 价格倍数
   */
  async setGasMultiplier(multiplier) {
    const config = await this.getConfig();
    config.gasMultiplier = multiplier;
    await this.saveConfig(config);
  }

  /**
   * 获取代币白名单
   * @returns {Promise<Array>} 代币白名单
   */
  async getTokenWhitelist() {
    const config = await this.getConfig();
    return config.tokenWhitelist || [];
  }

  /**
   * 设置代币白名单
   * @param {Array} whitelist - 代币白名单
   */
  async setTokenWhitelist(whitelist) {
    const config = await this.getConfig();
    config.tokenWhitelist = whitelist;
    await this.saveConfig(config);
  }

  // ==================== Gas 不足警报相关 ====================

  /**
   * 获取 Gas 不足警报记录
   * @returns {Promise<Object>} 警报记录
   */
  async getGasAlerts() {
    const config = await this.getConfig();
    return config.gasAlerts || {};
  }

  /**
   * 保存 Gas 不足警报记录
   * @param {Object} alerts - 警报记录
   */
  async saveGasAlerts(alerts) {
    const config = await this.getConfig();
    config.gasAlerts = alerts;
    await this.saveConfig(config);
  }

  /**
   * 添加 Gas 不足警报
   * @param {string} walletAddress - 钱包地址
   * @param {string} tokenName - 代币名称
   * @param {string} reason - 失败原因
   */
  async addGasAlert(walletAddress, tokenName, reason) {
    const alerts = await this.getGasAlerts();
    const alertKey = `${walletAddress}_${tokenName}`;

    alerts[alertKey] = {
      walletAddress,
      tokenName,
      reason,
      timestamp: new Date().toISOString(),
      notified: false
    };

    await this.saveGasAlerts(alerts);
  }

  /**
   * 检查是否应该发送警报（避免重复警报）
   * @param {string} walletAddress - 钱包地址
   * @param {string} tokenName - 代币名称
   * @param {number} intervalMs - 警报间隔（毫秒）
   * @returns {Promise<boolean>} 是否应该发送警报
   */
  async shouldSendAlert(walletAddress, tokenName, intervalMs) {
    const alerts = await this.getGasAlerts();
    const alertKey = `${walletAddress}_${tokenName}`;
    const alert = alerts[alertKey];

    if (!alert) {
      return true; // 没有记录，应该发送
    }

    const lastAlertTime = new Date(alert.timestamp).getTime();
    const currentTime = Date.now();

    // 检查是否超过警报间隔
    return (currentTime - lastAlertTime) > intervalMs;
  }

  /**
   * 清除 Gas 不足警报
   * @param {string} walletAddress - 钱包地址
   * @param {string} tokenName - 代币名称（可选，不传则清除该钱包所有警报）
   */
  async clearGasAlert(walletAddress, tokenName = null) {
    const alerts = await this.getGasAlerts();

    if (tokenName) {
      // 清除特定代币的警报
      const alertKey = `${walletAddress}_${tokenName}`;
      delete alerts[alertKey];
    } else {
      // 清除该钱包的所有警报
      Object.keys(alerts).forEach(key => {
        if (key.startsWith(walletAddress + '_')) {
          delete alerts[key];
        }
      });
    }

    await this.saveGasAlerts(alerts);
  }

  // ==================== Telegram 绑定相关 ====================

  /**
   * 获取 Telegram 绑定
   * @param {string} walletAddress - 钱包地址
   * @returns {Promise<Object|null>} 绑定对象
   */
  async getTelegramBinding(walletAddress) {
    const bindings = await this.getAllTelegramBindings();
    return bindings[walletAddress] || null;
  }

  /**
   * 获取所有 Telegram 绑定
   * @returns {Promise<Object>} 绑定对象映射
   */
  async getAllTelegramBindings() {
    const data = await this.readJsonFile('./cache/telegram-bindings.json');
    return data || {};
  }

  /**
   * 保存 Telegram 绑定
   * @param {Object} binding - 绑定对象
   */
  async saveTelegramBinding(binding) {
    const bindings = await this.getAllTelegramBindings();
    bindings[binding.walletAddress] = binding;
    await this.writeJsonFile('./cache/telegram-bindings.json', bindings);
  }

  /**
   * 删除 Telegram 绑定
   * @param {string} walletAddress - 钱包地址
   */
  async deleteTelegramBinding(walletAddress) {
    const bindings = await this.getAllTelegramBindings();
    delete bindings[walletAddress];
    await this.writeJsonFile('./cache/telegram-bindings.json', bindings);
  }

  // ==================== 通知历史相关 ====================

  /**
   * 获取通知历史
   * @returns {Promise<Array>} 通知历史数组
   */
  async getNotificationHistory() {
    const data = await this.readJsonFile('./cache/telegram-history.json');
    return data || [];
  }

  /**
   * 保存通知历史
   * @param {Array} history - 通知历史数组
   */
  async saveNotificationHistory(history) {
    await this.writeJsonFile('./cache/telegram-history.json', history);
  }

  /**
   * 添加通知历史记录
   * @param {Object} notification - 通知对象
   */
  async addNotificationHistory(notification) {
    const history = await this.getNotificationHistory();

    const newNotification = {
      id: notification.id || Date.now().toString(),
      ...notification,
      sentAt: notification.sentAt || new Date().toISOString()
    };

    history.unshift(newNotification);

    // 只保留最近 1000 条记录
    if (history.length > 1000) {
      history.splice(1000);
    }

    await this.saveNotificationHistory(history);
  }

  // ==================== 消息队列相关 ====================

  /**
   * 加载消息队列
   * @returns {Promise<Array>} 消息队列数组
   */
  async loadNotificationQueue() {
    const data = await this.readJsonFile('./cache/notification-queue.json');
    return data || [];
  }

  /**
   * 保存消息队列
   * @param {Array} queue - 消息队列数组
   */
  async saveNotificationQueue(queue) {
    await this.writeJsonFile('./cache/notification-queue.json', queue);
  }
}

// 导出单例
module.exports = new JsonStorage();
