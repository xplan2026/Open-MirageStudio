-- ==========================================
-- X-Project Supabase 数据库初始化脚本
-- ==========================================
-- 版本: 1.0
-- 创建日期: 2025-02-23
-- 说明: 创建交易记录和余额追踪所需的表
-- ==========================================

-- 启用必要的扩展
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ==========================================
-- 1. 交易记录表 (transactions)
-- ==========================================

-- 创建表（如果不存在）
-- 先确保表存在
CREATE TABLE IF NOT EXISTS transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  token_name TEXT NOT NULL CHECK (token_name IN ('USDT', 'BNB', 'wkeyDAO')),
  amount TEXT NOT NULL,
  from_address TEXT NOT NULL,
  to_address TEXT,
  tx_hash TEXT,
  success BOOLEAN NOT NULL,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 添加 gas_used 列（用于已有表的兼容性）
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS gas_used TEXT;

-- 创建索引以优化查询性能
CREATE INDEX IF NOT EXISTS idx_transactions_created_at ON transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_token_name ON transactions(token_name);
CREATE INDEX IF NOT EXISTS idx_transactions_success ON transactions(success);
CREATE INDEX IF NOT EXISTS idx_transactions_from_address ON transactions(from_address);
CREATE INDEX IF NOT EXISTS idx_transactions_to_address ON transactions(to_address);
-- 组合索引优化常见查询：按来源地址和代币查询
CREATE INDEX IF NOT EXISTS idx_transactions_from_token ON transactions(from_address, token_name);
-- 组合索引优化常见查询：按目标地址和代币查询
CREATE INDEX IF NOT EXISTS idx_transactions_to_token ON transactions(to_address, token_name);

-- 添加注释
COMMENT ON TABLE transactions IS 'X-Plan 交易记录表，存储所有代币转账记录';
COMMENT ON COLUMN transactions.id IS '主键，UUID 格式';
COMMENT ON COLUMN transactions.token_name IS '代币名称: USDT, BNB, wkeyDAO';
COMMENT ON COLUMN transactions.amount IS '交易金额（字符串格式以避免精度问题）';
COMMENT ON COLUMN transactions.from_address IS '来源钱包地址';
COMMENT ON COLUMN transactions.to_address IS '目标钱包地址（失败交易为空）';
COMMENT ON COLUMN transactions.tx_hash IS '区块链交易哈希（失败交易为空）';
COMMENT ON COLUMN transactions.success IS '交易是否成功';
COMMENT ON COLUMN transactions.note IS '备注信息';
COMMENT ON COLUMN transactions.gas_used IS '实际消耗的 Gas（字符串格式）';
COMMENT ON COLUMN transactions.created_at IS '记录创建时间（UTC）';

-- ==========================================
-- 2. 余额快照表 (balances)
-- ==========================================
CREATE TABLE IF NOT EXISTS balances (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  wallet_address TEXT NOT NULL,
  token_symbol TEXT NOT NULL CHECK (token_symbol IN ('USDT', 'BNB', 'wkeyDAO')),
  balance TEXT NOT NULL,
  timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 创建索引以优化查询性能
CREATE INDEX IF NOT EXISTS idx_balances_wallet_address ON balances(wallet_address);
CREATE INDEX IF NOT EXISTS idx_balances_token_symbol ON balances(token_symbol);
CREATE INDEX IF NOT EXISTS idx_balances_timestamp ON balances(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_balances_wallet_token_time ON balances(wallet_address, token_symbol, timestamp DESC);

-- 添加注释
COMMENT ON TABLE balances IS '钱包余额快照表，用于历史余额追踪';
COMMENT ON COLUMN balances.id IS '主键，UUID 格式';
COMMENT ON COLUMN balances.wallet_address IS '钱包地址';
COMMENT ON COLUMN balances.token_symbol IS '代币符号: USDT, BNB, wkeyDAO';
COMMENT ON COLUMN balances.balance IS '余额（字符串格式）';
COMMENT ON COLUMN balances.timestamp IS '记录时间（UTC）';

-- ==========================================
-- 3. 监控配置表 (monitor_config) - 可选
-- ==========================================

-- 先创建基础表（如果没有 description 列的旧版本）
CREATE TABLE IF NOT EXISTS monitor_config (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 添加 description 列（如果不存在）
ALTER TABLE monitor_config ADD COLUMN IF NOT EXISTS description TEXT;

-- 插入默认配置（使用单条 INSERT 语句，避免逻辑混乱）
INSERT INTO monitor_config (key, value, description) VALUES
  ('monitor_check_interval', '5000', '监控检查间隔（毫秒）'),
  ('monitor_max_retries', '3', '监控最大重试次数'),
  ('monitor_min_transfer_amount', '1000000000000000', '最小转账金额（wei）'),
  ('monitor_gas_multiplier', '1.1', 'Gas 费用倍数'),
  ('usdt_transfer_enabled', 'true', 'USDT 转账功能开关'),
  ('usdt_transfer_threshold', '0', 'USDT 转账阈值'),
  ('usdt_transfer_gas_limit', '60000', 'USDT 转账 Gas 限制'),
  ('bnb_transfer_enabled', 'true', 'BNB 转账功能开关'),
  ('bnb_transfer_threshold', '0.0005', 'BNB 转账阈值'),
  ('bnb_transfer_gas_limit', '21000', 'BNB 转账 Gas 限制'),
  ('whitelist_management_enabled', 'true', '白名单代币管理功能开关')
ON CONFLICT (key) DO UPDATE SET
  value = EXCLUDED.value,
  description = EXCLUDED.description;

-- 添加注释
COMMENT ON TABLE monitor_config IS '监控配置表，存储动态配置项';
COMMENT ON COLUMN monitor_config.key IS '配置键名';
COMMENT ON COLUMN monitor_config.value IS '配置值';
COMMENT ON COLUMN monitor_config.updated_at IS '最后更新时间';

-- ==========================================
-- 4. 创建视图用于常用查询
-- ==========================================

-- 交易汇总视图
CREATE OR REPLACE VIEW transaction_summary AS
SELECT
  token_name,
  COUNT(*) as total_transactions,
  SUM(CASE WHEN success THEN 1 ELSE 0 END) as successful_transactions,
  SUM(CASE WHEN success THEN 0 ELSE 1 END) as failed_transactions,
  ROUND(SUM(CASE WHEN success THEN CAST(amount AS NUMERIC) ELSE 0 END), 2) as total_amount
FROM transactions
GROUP BY token_name;

COMMENT ON VIEW transaction_summary IS '交易汇总视图，按代币统计';

-- 最新余额视图
CREATE OR REPLACE VIEW latest_balances AS
SELECT DISTINCT ON (wallet_address, token_symbol)
  wallet_address,
  token_symbol,
  balance,
  timestamp
FROM balances
ORDER BY wallet_address, token_symbol, timestamp DESC;

COMMENT ON VIEW latest_balances IS '最新余额视图，每个钱包每种代币的最新余额';

-- ==========================================
-- 5. 触发器：自动更新配置更新时间
-- ==========================================

CREATE OR REPLACE FUNCTION update_config_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 删除已存在的触发器（如果存在）
DROP TRIGGER IF EXISTS trigger_update_config_timestamp ON monitor_config;

-- 创建触发器
CREATE TRIGGER trigger_update_config_timestamp
  BEFORE UPDATE ON monitor_config
  FOR EACH ROW
  EXECUTE FUNCTION update_config_timestamp();

-- ==========================================
-- 6. Row Level Security (RLS) 策略
-- ==========================================

-- 为 transactions 表启用 RLS
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- 删除已存在的策略（如果存在）
DROP POLICY IF EXISTS "Enable read access for all users" ON transactions;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON transactions;

-- 创建策略
CREATE POLICY "Enable read access for all users" ON transactions
  FOR SELECT USING (true);

CREATE POLICY "Enable insert for authenticated users" ON transactions
  FOR INSERT WITH CHECK (true);

-- 为 balances 表启用 RLS
ALTER TABLE balances ENABLE ROW LEVEL SECURITY;

-- 删除已存在的策略（如果存在）
DROP POLICY IF EXISTS "Enable read access for all users" ON balances;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON balances;

-- 创建策略
CREATE POLICY "Enable read access for all users" ON balances
  FOR SELECT USING (true);

CREATE POLICY "Enable insert for authenticated users" ON balances
  FOR INSERT WITH CHECK (true);

-- 为 monitor_config 表启用 RLS
ALTER TABLE monitor_config ENABLE ROW LEVEL SECURITY;

-- 删除已存在的策略（如果存在）
DROP POLICY IF EXISTS "Enable read access for all users" ON monitor_config;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON monitor_config;

-- 创建策略
CREATE POLICY "Enable read access for all users" ON monitor_config
  FOR SELECT USING (true);

CREATE POLICY "Enable update for authenticated users" ON monitor_config
  FOR UPDATE USING (true);

-- ==========================================
-- 7. 实用函数
-- ==========================================

-- 删除已存在的函数（如果存在）
DROP FUNCTION IF EXISTS get_transaction_stats(TEXT, TIMESTAMPTZ, TIMESTAMPTZ);

-- 获取指定时间范围内的交易统计
CREATE FUNCTION get_transaction_stats(
  p_token_name TEXT DEFAULT NULL,
  p_start_date TIMESTAMPTZ DEFAULT NULL,
  p_end_date TIMESTAMPTZ DEFAULT NULL
)
RETURNS TABLE (
  token_name TEXT,
  total_count BIGINT,
  success_count BIGINT,
  failed_count BIGINT,
  success_rate NUMERIC,
  total_amount NUMERIC,
  total_gas NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    t.token_name,
    COUNT(*)::BIGINT as total_count,
    SUM(CASE WHEN t.success THEN 1 ELSE 0 END)::BIGINT as success_count,
    SUM(CASE WHEN NOT t.success THEN 1 ELSE 0 END)::BIGINT as failed_count,
    ROUND(
      CASE
        WHEN COUNT(*) > 0 THEN
          (SUM(CASE WHEN t.success THEN 1 ELSE 0 END)::NUMERIC / COUNT(*)) * 100
        ELSE
          0
      END,
      2
    ) as success_rate,
    ROUND(
      SUM(CASE WHEN t.success THEN CAST(t.amount AS NUMERIC) ELSE 0 END),
      2
    ) as total_amount,
    ROUND(
      SUM(CASE WHEN t.gas_used IS NOT NULL THEN CAST(t.gas_used AS NUMERIC) ELSE 0 END),
      4
    ) as total_gas
  FROM transactions t
  WHERE
    (p_token_name IS NULL OR t.token_name = p_token_name)
    AND (p_start_date IS NULL OR t.created_at >= p_start_date)
    AND (p_end_date IS NULL OR t.created_at <= p_end_date)
  GROUP BY t.token_name;
END;
$$ LANGUAGE plpgsql;

-- 删除已存在的函数（如果存在）
DROP FUNCTION IF EXISTS get_wallet_balance_history(TEXT, TEXT, INTEGER);

-- 获取指定钱包的余额历史
CREATE FUNCTION get_wallet_balance_history(
  p_wallet_address TEXT,
  p_token_symbol TEXT,
  p_days INTEGER DEFAULT 7
)
RETURNS TABLE (
  record_timestamp TIMESTAMPTZ,
  balance TEXT
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    b.timestamp as record_timestamp,
    b.balance
  FROM balances b
  WHERE
    b.wallet_address = p_wallet_address
    AND b.token_symbol = p_token_symbol
    AND b.timestamp >= NOW() - (p_days || ' days')::INTERVAL
  ORDER BY b.timestamp DESC;
END;
$$ LANGUAGE plpgsql;

-- ==========================================
-- 8. 清理任务（可选）
-- ==========================================

-- 删除已存在的函数（如果存在）
DROP FUNCTION IF EXISTS cleanup_old_transactions(INTEGER);

-- 创建清理旧数据的函数
CREATE FUNCTION cleanup_old_transactions(p_days_to_keep INTEGER DEFAULT 90)
RETURNS INTEGER AS $$
DECLARE
  deleted_count INTEGER;
BEGIN
  DELETE FROM transactions
  WHERE created_at < NOW() - (p_days_to_keep || ' days')::INTERVAL;

  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION cleanup_old_transactions IS '清理指定天数前的交易记录';

-- 删除已存在的函数（如果存在）
DROP FUNCTION IF EXISTS cleanup_old_balances(INTEGER);

-- 创建清理旧余额记录的函数
CREATE FUNCTION cleanup_old_balances(p_days_to_keep INTEGER DEFAULT 7)
RETURNS INTEGER AS $$
DECLARE
  deleted_count INTEGER;
BEGIN
  -- 获取每个钱包和代币的最新记录时间
  WITH latest_records AS (
    SELECT DISTINCT ON (wallet_address, token_symbol) timestamp
    FROM balances
    ORDER BY wallet_address, token_symbol, timestamp DESC
  )
  -- 删除非最新记录且超出保留天数的记录
  DELETE FROM balances
  WHERE timestamp < NOW() - (p_days_to_keep || ' days')::INTERVAL
    AND timestamp NOT IN (SELECT timestamp FROM latest_records);

  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION cleanup_old_balances IS '清理指定天数前的余额记录，保留每条最新记录';

-- ==========================================
-- 完成提示
-- ==========================================
-- 注意：Supabase SQL Editor 不支持 RAISE NOTICE
-- 脚本执行成功即表示初始化完成
-- 已创建的表:
--   - transactions (交易记录)
--   - balances (余额快照)
--   - monitor_config (监控配置)
-- 已创建的视图:
--   - transaction_summary (交易汇总)
--   - latest_balances (最新余额)
-- 已创建的函数:
--   - get_transaction_stats() (获取交易统计)
--   - get_wallet_balance_history() (获取余额历史)
--   - cleanup_old_transactions() (清理旧交易记录)
--   - cleanup_old_balances() (清理旧余额记录)
-- 下一步:
--   1. 在 .env 文件中配置 Supabase 凭据
--   2. 设置 TRANSACTION_STORAGE_TYPE=supabase
--   3. 重启应用以应用更改
