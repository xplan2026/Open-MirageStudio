-- Supabase Admin Logs 表创建脚本
-- V3.0.0: 用于记录数据中台管理操作日志

-- 创建 admin_logs 表
CREATE TABLE IF NOT EXISTS admin_logs (
  id TEXT PRIMARY KEY,
  admin_address TEXT NOT NULL,
  action TEXT NOT NULL,
  details JSONB,
  ip TEXT,
  user_agent TEXT,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  success BOOLEAN DEFAULT true
);

-- 创建索引以提高查询性能
CREATE INDEX IF NOT EXISTS idx_admin_logs_address ON admin_logs(admin_address);
CREATE INDEX IF NOT EXISTS idx_admin_logs_timestamp ON admin_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_admin_logs_action ON admin_logs(action);
CREATE INDEX IF NOT EXISTS idx_admin_logs_success ON admin_logs(success);

-- 添加注释
COMMENT ON TABLE admin_logs IS '数据中台管理操作审计日志';
COMMENT ON COLUMN admin_logs.id IS '日志唯一标识符 (UUID)';
COMMENT ON COLUMN admin_logs.admin_address IS '管理员钱包地址';
COMMENT ON COLUMN admin_logs.action IS '操作类型 (LOGIN_METAMASK, LOGOUT, ADD_WHITELIST, REMOVE_WHITELIST 等)';
COMMENT ON COLUMN admin_logs.details IS '操作详情 (JSON 格式)';
COMMENT ON COLUMN admin_logs.ip IS '客户端 IP 地址';
COMMENT ON COLUMN admin_logs.user_agent IS '客户端 User-Agent';
COMMENT ON COLUMN admin_logs.timestamp IS '操作时间戳';
COMMENT ON COLUMN admin_logs.success IS '操作是否成功';

-- 启用 Row Level Security (RLS)
ALTER TABLE admin_logs ENABLE ROW LEVEL SECURITY;

-- 允许读取日志（用于审计）
CREATE POLICY "Allow read access" ON admin_logs
  FOR SELECT
  USING (true);

-- 注意：插入权限由 Supabase Service Role Key 控制
-- 不允许普通用户通过 Anon Key 插入日志
